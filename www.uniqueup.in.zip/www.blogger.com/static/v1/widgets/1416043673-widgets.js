(function () {
  var aa = "&action=",
    ba = ".wikipedia.org",
    ca = "CSSStyleDeclaration",
    da = "Clobbering detected",
    ea = "Edge",
    fa = "Element",
    ha = "GET",
    ia = "Node",
    ja = "SPAN",
    ka = "STYLE",
    la = "SW_READER_LIST_",
    ma = "SW_READER_LIST_CLOSED_",
    na = "Share this post",
    oa = "Symbol.iterator",
    pa = "_blank",
    qa = "about:invalid#zClosurez",
    ra = "about:invalid#zSoyz",
    sa = "attributes",
    ta = "block",
    ua = "click",
    va = "collapsed",
    wa = "collapsible",
    xa = "comment-editor",
    ya = "commentId",
    za = "complete",
    Aa = "contact-form-email",
    Ba = "contact-form-email-message",
    Ca = "contact-form-error-message",
    Da = "contact-form-error-message-with-border",
    Ea = "contact-form-name",
    Fa = "contact-form-submit",
    Ga = "contact-form-success-message",
    Ha = "contact-form-success-message-with-border",
    Ia = "data-height",
    Ja = "data-sanitizer-",
    Ka = "data-viewurl",
    La = "displayModeFull",
    Ma = "displayModeLayout",
    Na = "displayModeNone",
    l = "div",
    Oa = "dropdown-toggle",
    Pa = "error",
    Qa = "expanded",
    Ra = "followers-grid",
    m = "function",
    Sa = "getAttribute",
    Ta = "getElementsByTagName",
    Ua = "getPropertyValue",
    Va = "hasAttribute",
    Wa = "hidden",
    Xa = "https:",
    Ya = "layout-widget-description",
    Za = "layout-widget-title",
    $a = "max-height: 0;",
    ab = "msMatchesSelector",
    bb = "namespaceURI",
    p = "none",
    cb = "number",
    q = "object",
    db = "prerender",
    eb = "ready",
    fb = "removeAttribute",
    gb = "rotate(-45deg)",
    hb = "setAttribute",
    ib = "status-message",
    jb = "status-message-inner",
    r = "string",
    kb = "style",
    lb = "success",
    mb = "text/javascript",
    nb = "thread-collapsed",
    ob = "thread-expanded",
    pb = "title",
    qb = "toggle",
    rb = "visible",
    sb = "wikipedia-search-input",
    tb = "wikipedia-search-more",
    ub = "wikipedia-search-results",
    vb = "wikipedia-search-results-header",
    t;
  function wb(a) {
    var b = 0;
    return function () {
      return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
    };
  }
  var xb =
    typeof Object.defineProperties == m
      ? Object.defineProperty
      : function (a, b, c) {
          if (a == Array.prototype || a == Object.prototype) return a;
          a[b] = c.value;
          return a;
        };
  function yb(a) {
    a = [
      q == typeof globalThis && globalThis,
      a,
      q == typeof window && window,
      q == typeof self && self,
      q == typeof global && global,
    ];
    for (var b = 0; b < a.length; ++b) {
      var c = a[b];
      if (c && c.Math == Math) return c;
    }
    throw Error("Cannot find global object");
  }
  var zb = yb(this);
  function Ab(a, b) {
    if (b)
      a: {
        var c = zb;
        a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
          var e = a[d];
          if (!(e in c)) break a;
          c = c[e];
        }
        a = a[a.length - 1];
        d = c[a];
        b = b(d);
        b != d &&
          null != b &&
          xb(c, a, { configurable: !0, writable: !0, value: b });
      }
  }
  Ab("Symbol", function (a) {
    function b(f) {
      if (this instanceof b) throw new TypeError("Symbol is not a constructor");
      return new c(d + (f || "") + "_" + e++, f);
    }
    function c(f, g) {
      this.C = f;
      xb(this, "description", { configurable: !0, writable: !0, value: g });
    }
    if (a) return a;
    c.prototype.toString = function () {
      return this.C;
    };
    var d = "jscomp_symbol_" + ((1e9 * Math.random()) >>> 0) + "_",
      e = 0;
    return b;
  });
  Ab(oa, function (a) {
    if (a) return a;
    a = Symbol(oa);
    for (
      var b =
          "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(
            " "
          ),
        c = 0;
      c < b.length;
      c++
    ) {
      var d = zb[b[c]];
      typeof d === m &&
        typeof d.prototype[a] != m &&
        xb(d.prototype, a, {
          configurable: !0,
          writable: !0,
          value: function () {
            return Bb(wb(this));
          },
        });
    }
    return a;
  });
  function Bb(a) {
    a = { next: a };
    a[Symbol.iterator] = function () {
      return this;
    };
    return a;
  }
  function Cb(a) {
    var b =
      "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
    return b ? b.call(a) : { next: wb(a) };
  }
  var Db =
      typeof Object.create == m
        ? Object.create
        : function (a) {
            function b() {}
            b.prototype = a;
            return new b();
          },
    Eb;
  if (typeof Object.setPrototypeOf == m) Eb = Object.setPrototypeOf;
  else {
    var Fb;
    a: {
      var Gb = { a: !0 },
        Hb = {};
      try {
        Hb.__proto__ = Gb;
        Fb = Hb.a;
        break a;
      } catch (a) {}
      Fb = !1;
    }
    Eb = Fb
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var Ib = Eb;
  function v(a, b) {
    a.prototype = Db(b.prototype);
    a.prototype.constructor = a;
    if (Ib) Ib(a, b);
    else
      for (var c in b)
        if ("prototype" != c)
          if (Object.defineProperties) {
            var d = Object.getOwnPropertyDescriptor(b, c);
            d && Object.defineProperty(a, c, d);
          } else a[c] = b[c];
    a.O = b.prototype;
  }
  function Jb(a, b) {
    return Object.prototype.hasOwnProperty.call(a, b);
  }
  var Kb =
    typeof Object.assign == m
      ? Object.assign
      : function (a, b) {
          for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d) for (var e in d) Jb(d, e) && (a[e] = d[e]);
          }
          return a;
        };
  Ab("Object.assign", function (a) {
    return a || Kb;
  });
  Ab("WeakMap", function (a) {
    function b(k) {
      this.ga = (h += Math.random() + 1).toString();
      if (k) {
        k = Cb(k);
        for (var n; !(n = k.next()).done; ) (n = n.value), this.set(n[0], n[1]);
      }
    }
    function c() {}
    function d(k) {
      var n = typeof k;
      return (n === q && null !== k) || n === m;
    }
    function e(k) {
      if (!Jb(k, g)) {
        var n = new c();
        xb(k, g, { value: n });
      }
    }
    function f(k) {
      var n = Object[k];
      n &&
        (Object[k] = function (u) {
          if (u instanceof c) return u;
          Object.isExtensible(u) && e(u);
          return n(u);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var k = Object.seal({}),
            n = Object.seal({}),
            u = new a([
              [k, 2],
              [n, 3],
            ]);
          if (2 != u.get(k) || 3 != u.get(n)) return !1;
          u.delete(k);
          u.set(n, 4);
          return !u.has(k) && 4 == u.get(n);
        } catch (w) {
          return !1;
        }
      })()
    )
      return a;
    var g = "$jscomp_hidden_" + Math.random();
    f("freeze");
    f("preventExtensions");
    f("seal");
    var h = 0;
    b.prototype.set = function (k, n) {
      if (!d(k)) throw Error("Invalid WeakMap key");
      e(k);
      if (!Jb(k, g)) throw Error("WeakMap key fail: " + k);
      k[g][this.ga] = n;
      return this;
    };
    b.prototype.get = function (k) {
      return d(k) && Jb(k, g) ? k[g][this.ga] : void 0;
    };
    b.prototype.has = function (k) {
      return d(k) && Jb(k, g) && Jb(k[g], this.ga);
    };
    b.prototype.delete = function (k) {
      return d(k) && Jb(k, g) && Jb(k[g], this.ga) ? delete k[g][this.ga] : !1;
    };
    return b;
  });
  Ab("Map", function (a) {
    function b() {
      var h = {};
      return (h.qa = h.next = h.head = h);
    }
    function c(h, k) {
      var n = h.C;
      return Bb(function () {
        if (n) {
          for (; n.head != h.C; ) n = n.qa;
          for (; n.next != n.head; )
            return (n = n.next), { done: !1, value: k(n) };
          n = null;
        }
        return { done: !0, value: void 0 };
      });
    }
    function d(h, k) {
      var n = k && typeof k;
      n == q || n == m
        ? f.has(k)
          ? (n = f.get(k))
          : ((n = "" + ++g), f.set(k, n))
        : (n = "p_" + k);
      var u = h.D[n];
      if (u && Jb(h.D, n))
        for (h = 0; h < u.length; h++) {
          var w = u[h];
          if ((k !== k && w.key !== w.key) || k === w.key)
            return { id: n, list: u, index: h, aa: w };
        }
      return { id: n, list: u, index: -1, aa: void 0 };
    }
    function e(h) {
      this.D = {};
      this.C = b();
      this.size = 0;
      if (h) {
        h = Cb(h);
        for (var k; !(k = h.next()).done; ) (k = k.value), this.set(k[0], k[1]);
      }
    }
    if (
      (function () {
        if (
          !a ||
          typeof a != m ||
          !a.prototype.entries ||
          typeof Object.seal != m
        )
          return !1;
        try {
          var h = Object.seal({ x: 4 }),
            k = new a(Cb([[h, "s"]]));
          if (
            "s" != k.get(h) ||
            1 != k.size ||
            k.get({ x: 4 }) ||
            k.set({ x: 4 }, "t") != k ||
            2 != k.size
          )
            return !1;
          var n = k.entries(),
            u = n.next();
          if (u.done || u.value[0] != h || "s" != u.value[1]) return !1;
          u = n.next();
          return u.done ||
            4 != u.value[0].x ||
            "t" != u.value[1] ||
            !n.next().done
            ? !1
            : !0;
        } catch (w) {
          return !1;
        }
      })()
    )
      return a;
    var f = new WeakMap();
    e.prototype.set = function (h, k) {
      h = 0 === h ? 0 : h;
      var n = d(this, h);
      n.list || (n.list = this.D[n.id] = []);
      n.aa
        ? (n.aa.value = k)
        : ((n.aa = {
            next: this.C,
            qa: this.C.qa,
            head: this.C,
            key: h,
            value: k,
          }),
          n.list.push(n.aa),
          (this.C.qa.next = n.aa),
          (this.C.qa = n.aa),
          this.size++);
      return this;
    };
    e.prototype.delete = function (h) {
      h = d(this, h);
      return h.aa && h.list
        ? (h.list.splice(h.index, 1),
          h.list.length || delete this.D[h.id],
          (h.aa.qa.next = h.aa.next),
          (h.aa.next.qa = h.aa.qa),
          (h.aa.head = null),
          this.size--,
          !0)
        : !1;
    };
    e.prototype.clear = function () {
      this.D = {};
      this.C = this.C.qa = b();
      this.size = 0;
    };
    e.prototype.has = function (h) {
      return !!d(this, h).aa;
    };
    e.prototype.get = function (h) {
      return (h = d(this, h).aa) && h.value;
    };
    e.prototype.entries = function () {
      return c(this, function (h) {
        return [h.key, h.value];
      });
    };
    e.prototype.keys = function () {
      return c(this, function (h) {
        return h.key;
      });
    };
    e.prototype.values = function () {
      return c(this, function (h) {
        return h.value;
      });
    };
    e.prototype.forEach = function (h, k) {
      for (var n = this.entries(), u; !(u = n.next()).done; )
        (u = u.value), h.call(k, u[1], u[0], this);
    };
    e.prototype[Symbol.iterator] = e.prototype.entries;
    var g = 0;
    return e;
  });
  function Lb(a, b, c) {
    if (null == a)
      throw new TypeError(
        "The 'this' value for String.prototype." +
          c +
          " must not be null or undefined"
      );
    if (b instanceof RegExp)
      throw new TypeError(
        "First argument to String.prototype." +
          c +
          " must not be a regular expression"
      );
    return a + "";
  }
  Ab("String.prototype.endsWith", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Lb(this, b, "endsWith");
          b += "";
          void 0 === c && (c = d.length);
          c = Math.max(0, Math.min(c | 0, d.length));
          for (var e = b.length; 0 < e && 0 < c; )
            if (d[--c] != b[--e]) return !1;
          return 0 >= e;
        };
  });
  Ab("Array.prototype.find", function (a) {
    return a
      ? a
      : function (b, c) {
          a: {
            var d = this;
            d instanceof String && (d = String(d));
            for (var e = d.length, f = 0; f < e; f++) {
              var g = d[f];
              if (b.call(c, g, f, d)) {
                b = g;
                break a;
              }
            }
            b = void 0;
          }
          return b;
        };
  });
  Ab("Set", function (a) {
    function b(c) {
      this.C = new Map();
      if (c) {
        c = Cb(c);
        for (var d; !(d = c.next()).done; ) this.add(d.value);
      }
      this.size = this.C.size;
    }
    if (
      (function () {
        if (
          !a ||
          typeof a != m ||
          !a.prototype.entries ||
          typeof Object.seal != m
        )
          return !1;
        try {
          var c = Object.seal({ x: 4 }),
            d = new a(Cb([c]));
          if (
            !d.has(c) ||
            1 != d.size ||
            d.add(c) != d ||
            1 != d.size ||
            d.add({ x: 4 }) != d ||
            2 != d.size
          )
            return !1;
          var e = d.entries(),
            f = e.next();
          if (f.done || f.value[0] != c || f.value[1] != c) return !1;
          f = e.next();
          return f.done ||
            f.value[0] == c ||
            4 != f.value[0].x ||
            f.value[1] != f.value[0]
            ? !1
            : e.next().done;
        } catch (g) {
          return !1;
        }
      })()
    )
      return a;
    b.prototype.add = function (c) {
      c = 0 === c ? 0 : c;
      this.C.set(c, c);
      this.size = this.C.size;
      return this;
    };
    b.prototype.delete = function (c) {
      c = this.C.delete(c);
      this.size = this.C.size;
      return c;
    };
    b.prototype.clear = function () {
      this.C.clear();
      this.size = 0;
    };
    b.prototype.has = function (c) {
      return this.C.has(c);
    };
    b.prototype.entries = function () {
      return this.C.entries();
    };
    b.prototype.values = function () {
      return this.C.values();
    };
    b.prototype.keys = b.prototype.values;
    b.prototype[Symbol.iterator] = b.prototype.values;
    b.prototype.forEach = function (c, d) {
      var e = this;
      this.C.forEach(function (f) {
        return c.call(d, f, f, e);
      });
    };
    return b;
  });
  function Mb(a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1,
      e = {
        next: function () {
          if (!d && c < a.length) {
            var f = c++;
            return { value: b(f, a[f]), done: !1 };
          }
          d = !0;
          return { done: !0, value: void 0 };
        },
      };
    e[Symbol.iterator] = function () {
      return e;
    };
    return e;
  }
  Ab("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return Mb(this, function (b) {
            return b;
          });
        };
  });
  Ab("String.prototype.startsWith", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Lb(this, b, "startsWith");
          b += "";
          var e = d.length,
            f = b.length;
          c = Math.max(0, Math.min(c | 0, d.length));
          for (var g = 0; g < f && c < e; ) if (d[c++] != b[g++]) return !1;
          return g >= f;
        };
  });
  Ab("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return Mb(this, function (b, c) {
            return c;
          });
        };
  });
  Ab("Array.from", function (a) {
    return a
      ? a
      : function (b, c, d) {
          c =
            null != c
              ? c
              : function (h) {
                  return h;
                };
          var e = [],
            f =
              "undefined" != typeof Symbol &&
              Symbol.iterator &&
              b[Symbol.iterator];
          if (typeof f == m) {
            b = f.call(b);
            for (var g = 0; !(f = b.next()).done; )
              e.push(c.call(d, f.value, g++));
          } else
            for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
          return e;
        };
  });
  window.jstiming && window.jstiming.load.tick("widgetJsStart");
  function Nb() {
    window.jstiming.load.tick("ol");
  }
  function Ob(a, b) {
    a.addEventListener
      ? a.addEventListener("load", b, !1)
      : a.attachEvent("onload", b);
  }
  function Pb(a, b) {
    return a.className && -1 != a.className.indexOf(b)
      ? a
      : a.parentNode
      ? Pb(a.parentNode, b)
      : null;
  }
  function Qb() {
    window.jstiming.load.tick("prt");
    window.tickAboveFold && window.tickAboveFold(this);
  }
  window.BLOG_attachCsiOnload = function (a, b) {
    if (window.jstiming) {
      window.jstiming.load.tick("widgetJsEnd");
      window.jstiming.load.tick("prt");
      window.jstiming.load.name = a + "blogspot";
      a = document.getElementsByTagName("img");
      for (var c = 0; c < a.length; c++)
        a[c].complete
          ? null != Pb(a[c], "post") && Qb.apply(a[c])
          : null != Pb(a[c], "post") && Ob(a[c], Qb);
      Ob(window, Nb);
      a = function () {
        for (
          var d = {},
            e = window.blogger_blog_id,
            f = [
              "google_blogger_adsense_experiment_id",
              "blogger_csi_e",
              "blogger_templates_experiment_id",
              "blogger_active_experiments",
            ],
            g = [],
            h = f.length,
            k = 0;
          k < h;
          k++
        ) {
          var n = f[k];
          n in window && g.push(window[n]);
        }
        e && (d.blogId = e);
        0 < g.length && (d.e = g.join(","));
        e =
          (document.location.protocol == Xa ? Xa : "http:") +
          "//csi.gstatic.com/csi";
        window.jstiming.report(window.jstiming.load, d, b || e);
      };
      window.addEventListener
        ? window.addEventListener("beforeunload", a, !1)
        : window.attachEvent("onbeforeunload", a);
    }
  }; /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var Rb = Rb || {},
    x = this || self;
  function Sb(a) {
    a.xa = void 0;
    a.Za = function () {
      return a.xa ? a.xa : (a.xa = new a());
    };
  }
  function Tb(a) {
    var b = typeof a;
    b = b != q ? b : a ? (Array.isArray(a) ? "array" : b) : "null";
    return "array" == b || (b == q && typeof a.length == cb);
  }
  function Ub(a) {
    var b = typeof a;
    return (b == q && null != a) || b == m;
  }
  var Vb = "closure_uid_" + ((1e9 * Math.random()) >>> 0),
    Wb = 0;
  function Xb(a, b, c) {
    return a.call.apply(a.bind, arguments);
  }
  function Yb(a, b, c) {
    if (!a) throw Error();
    if (2 < arguments.length) {
      var d = Array.prototype.slice.call(arguments, 2);
      return function () {
        var e = Array.prototype.slice.call(arguments);
        Array.prototype.unshift.apply(e, d);
        return a.apply(b, e);
      };
    }
    return function () {
      return a.apply(b, arguments);
    };
  }
  function y(a, b, c) {
    Function.prototype.bind &&
    -1 != Function.prototype.bind.toString().indexOf("native code")
      ? (y = Xb)
      : (y = Yb);
    return y.apply(null, arguments);
  }
  function Zb(a, b) {
    var c = Array.prototype.slice.call(arguments, 1);
    return function () {
      var d = c.slice();
      d.push.apply(d, arguments);
      return a.apply(this, d);
    };
  }
  function z(a, b) {
    a = a.split(".");
    var c = x;
    a[0] in c ||
      "undefined" == typeof c.execScript ||
      c.execScript("var " + a[0]);
    for (var d; a.length && (d = a.shift()); )
      a.length || void 0 === b
        ? c[d] && c[d] !== Object.prototype[d]
          ? (c = c[d])
          : (c = c[d] = {})
        : (c[d] = b);
  }
  function A(a, b) {
    function c() {}
    c.prototype = b.prototype;
    a.O = b.prototype;
    a.prototype = new c();
    a.prototype.constructor = a;
    a.Md = function (d, e, f) {
      for (
        var g = Array(arguments.length - 2), h = 2;
        h < arguments.length;
        h++
      )
        g[h - 2] = arguments[h];
      return b.prototype[e].apply(d, g);
    };
  }
  function $b(a) {
    return a;
  } /*

 SPDX-License-Identifier: Apache-2.0
*/
  var ac = {};
  function bc(a, b) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, bc);
    else {
      var c = Error().stack;
      c && (this.stack = c);
    }
    a && (this.message = String(a));
    void 0 !== b && (this.cause = b);
  }
  A(bc, Error);
  bc.prototype.name = "CustomError";
  var cc;
  function dc(a, b) {
    a = a.split("%s");
    for (var c = "", d = a.length - 1, e = 0; e < d; e++)
      c += a[e] + (e < b.length ? b[e] : "%s");
    bc.call(this, c + a[d]);
  }
  A(dc, bc);
  dc.prototype.name = "AssertionError";
  var ec = Array.prototype.indexOf
      ? function (a, b) {
          return Array.prototype.indexOf.call(a, b, void 0);
        }
      : function (a, b) {
          if (typeof a === r)
            return typeof b !== r || 1 != b.length ? -1 : a.indexOf(b, 0);
          for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
          return -1;
        },
    fc = Array.prototype.forEach
      ? function (a, b, c) {
          Array.prototype.forEach.call(a, b, c);
        }
      : function (a, b, c) {
          for (
            var d = a.length, e = typeof a === r ? a.split("") : a, f = 0;
            f < d;
            f++
          )
            f in e && b.call(c, e[f], f, a);
        },
    gc = Array.prototype.map
      ? function (a, b) {
          return Array.prototype.map.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length,
              d = Array(c),
              e = typeof a === r ? a.split("") : a,
              f = 0;
            f < c;
            f++
          )
            f in e && (d[f] = b.call(void 0, e[f], f, a));
          return d;
        },
    hc = Array.prototype.some
      ? function (a, b) {
          return Array.prototype.some.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length, d = typeof a === r ? a.split("") : a, e = 0;
            e < c;
            e++
          )
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
          return !1;
        },
    ic = Array.prototype.every
      ? function (a, b) {
          return Array.prototype.every.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length, d = typeof a === r ? a.split("") : a, e = 0;
            e < c;
            e++
          )
            if (e in d && !b.call(void 0, d[e], e, a)) return !1;
          return !0;
        };
  function jc(a, b) {
    return 0 <= ec(a, b);
  }
  function kc(a) {
    if (!Array.isArray(a)) for (var b = a.length - 1; 0 <= b; b--) delete a[b];
    a.length = 0;
  }
  function lc(a, b) {
    b = ec(a, b);
    var c;
    (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
    return c;
  }
  function mc(a) {
    return Array.prototype.concat.apply([], arguments);
  }
  function nc(a) {
    var b = a.length;
    if (0 < b) {
      for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
      return c;
    }
    return [];
  }
  function oc(a) {
    if (!arguments.length) return [];
    for (var b = [], c = arguments[0].length, d = 1; d < arguments.length; d++)
      arguments[d].length < c && (c = arguments[d].length);
    for (d = 0; d < c; d++) {
      for (var e = [], f = 0; f < arguments.length; f++)
        e.push(arguments[f][d]);
      b.push(e);
    }
    return b;
  }
  function pc(a, b) {
    return mc.apply([], gc(a, b));
  }
  function qc(a, b, c) {
    for (var d in a) b.call(c, a[d], d, a);
  }
  function rc(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = a[d];
    return b;
  }
  function sc(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = d;
    return b;
  }
  function tc(a, b) {
    for (var c in a) if (a[c] == b) return !0;
    return !1;
  }
  function uc(a) {
    for (var b in a) return !1;
    return !0;
  }
  function vc(a) {
    var b = {},
      c;
    for (c in a) b[c] = a[c];
    return b;
  }
  var wc =
    "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(
      " "
    );
  function xc(a, b) {
    for (var c, d, e = 1; e < arguments.length; e++) {
      d = arguments[e];
      for (c in d) a[c] = d[c];
      for (var f = 0; f < wc.length; f++)
        (c = wc[f]),
          Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c]);
    }
  }
  var yc = {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    command: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0,
  };
  var zc;
  function Ac() {
    if (void 0 === zc) {
      var a = null,
        b = x.trustedTypes;
      if (b && b.createPolicy) {
        try {
          a = b.createPolicy("goog#html", {
            createHTML: $b,
            createScript: $b,
            createScriptURL: $b,
          });
        } catch (c) {
          x.console && x.console.error(c.message);
        }
        zc = a;
      } else zc = a;
    }
    return zc;
  }
  function Bc(a, b) {
    this.C = (a === Cc && b) || "";
    this.D = Dc;
  }
  Bc.prototype.ma = !0;
  Bc.prototype.ja = function () {
    return this.C;
  };
  function Ec(a) {
    return a instanceof Bc && a.constructor === Bc && a.D === Dc
      ? a.C
      : "type_error:Const";
  }
  var Dc = {},
    Cc = {};
  var Fc = {};
  function Gc(a, b) {
    this.C = b === Fc ? a : "";
    this.ma = !0;
  }
  Gc.prototype.toString = function () {
    return this.C.toString();
  };
  Gc.prototype.ja = function () {
    return this.C.toString();
  };
  function Hc(a, b) {
    this.C = b === Ic ? a : "";
  }
  Hc.prototype.toString = function () {
    return this.C + "";
  };
  Hc.prototype.ma = !0;
  Hc.prototype.ja = function () {
    return this.C.toString();
  };
  function Jc(a) {
    return a instanceof Hc && a.constructor === Hc
      ? a.C
      : "type_error:TrustedResourceUrl";
  }
  var Kc = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
    Ic = {};
  function Lc(a) {
    var b = Ac();
    a = b ? b.createScriptURL(a) : a;
    return new Hc(a, Ic);
  }
  function Mc(a, b, c) {
    if (null == c) return b;
    if (typeof c === r) return c ? a + encodeURIComponent(c) : "";
    for (var d in c)
      if (Object.prototype.hasOwnProperty.call(c, d)) {
        var e = c[d];
        e = Array.isArray(e) ? e : [e];
        for (var f = 0; f < e.length; f++) {
          var g = e[f];
          null != g &&
            (b || (b = a),
            (b +=
              (b.length > a.length ? "&" : "") +
              encodeURIComponent(d) +
              "=" +
              encodeURIComponent(String(g))));
        }
      }
    return b;
  }
  function Nc(a, b) {
    return 0 == a.lastIndexOf(b, 0);
  }
  var B = String.prototype.trim
    ? function (a) {
        return a.trim();
      }
    : function (a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1];
      };
  function Oc(a) {
    if (!Pc.test(a)) return a;
    -1 != a.indexOf("&") && (a = a.replace(Qc, "&amp;"));
    -1 != a.indexOf("<") && (a = a.replace(Rc, "&lt;"));
    -1 != a.indexOf(">") && (a = a.replace(Sc, "&gt;"));
    -1 != a.indexOf('"') && (a = a.replace(Tc, "&quot;"));
    -1 != a.indexOf("'") && (a = a.replace(Uc, "&#39;"));
    -1 != a.indexOf("\x00") && (a = a.replace(Vc, "&#0;"));
    return a;
  }
  var Qc = /&/g,
    Rc = /</g,
    Sc = />/g,
    Tc = /"/g,
    Uc = /'/g,
    Vc = /\x00/g,
    Pc = /[\x00&<>"']/;
  function Wc(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
  }
  function C(a, b) {
    this.C = b === Xc ? a : "";
  }
  C.prototype.toString = function () {
    return this.C.toString();
  };
  C.prototype.ma = !0;
  C.prototype.ja = function () {
    return this.C.toString();
  };
  function Yc(a) {
    return a instanceof C && a.constructor === C ? a.C : "type_error:SafeUrl";
  }
  var Zc = /^data:(.*);base64,[a-z0-9+\/]+=*$/i,
    $c = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;
  function ad(a) {
    a instanceof C ||
      ((a = typeof a == q && a.ma ? a.ja() : String(a)),
      $c.test(a)
        ? (a = new C(a, Xc))
        : ((a = String(a).replace(/(%0A|%0D)/g, "")),
          (a = a.match(Zc) ? new C(a, Xc) : null)));
    return a || bd;
  }
  var Xc = {},
    bd = new C(qa, Xc);
  var cd = {};
  function dd(a, b) {
    this.C = b === cd ? a : "";
    this.ma = !0;
  }
  dd.prototype.ja = function () {
    return this.C;
  };
  dd.prototype.toString = function () {
    return this.C.toString();
  };
  function ed(a) {
    return a instanceof dd && a.constructor === dd
      ? a.C
      : "type_error:SafeStyle";
  }
  function fd(a) {
    var b = "",
      c;
    for (c in a)
      if (Object.prototype.hasOwnProperty.call(a, c)) {
        if (!/^[-_a-zA-Z0-9]+$/.test(c))
          throw Error("Name allows only [-_a-zA-Z0-9], got: " + c);
        var d = a[c];
        null != d &&
          ((d = Array.isArray(d) ? d.map(gd).join(" ") : gd(d)),
          (b += c + ":" + d + ";"));
      }
    return b ? new dd(b, cd) : hd;
  }
  var hd = new dd("", cd);
  function gd(a) {
    if (a instanceof C)
      return (
        'url("' + Yc(a).replace(/</g, "%3c").replace(/[\\"]/g, "\\$&") + '")'
      );
    if (a instanceof Bc) a = Ec(a);
    else {
      a = String(a);
      var b = a.replace(id, "$1").replace(id, "$1").replace(jd, "url");
      if (kd.test(b)) {
        if ((b = !ld.test(a))) {
          for (var c = (b = !0), d = 0; d < a.length; d++) {
            var e = a.charAt(d);
            "'" == e && c ? (b = !b) : '"' == e && b && (c = !c);
          }
          b = b && c && md(a);
        }
        a = b ? nd(a) : "zClosurez";
      } else a = "zClosurez";
    }
    if (/[{;}]/.test(a))
      throw new dc("Value does not allow [{;}], got: %s.", [a]);
    return a;
  }
  function md(a) {
    for (var b = !0, c = /^[-_a-zA-Z0-9]$/, d = 0; d < a.length; d++) {
      var e = a.charAt(d);
      if ("]" == e) {
        if (b) return !1;
        b = !0;
      } else if ("[" == e) {
        if (!b) return !1;
        b = !1;
      } else if (!b && !c.test(e)) return !1;
    }
    return b;
  }
  var kd = RegExp("^[-,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$"),
    jd = RegExp(
      "\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))",
      "g"
    ),
    id = RegExp(
      "\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)",
      "g"
    ),
    ld = /\/\*/;
  function nd(a) {
    return a.replace(jd, function (b, c, d, e) {
      var f = "";
      d = d.replace(/^(['"])(.*)\1$/, function (g, h, k) {
        f = h;
        return k;
      });
      b = ad(d).ja();
      return c + f + b + f + e;
    });
  }
  var od = {};
  function pd(a, b) {
    this.C = b === od ? a : "";
    this.ma = !0;
  }
  pd.prototype.toString = function () {
    return this.C.toString();
  };
  function qd(a) {
    function b(d) {
      Array.isArray(d) ? d.forEach(b) : (c += rd(d));
    }
    var c = "";
    Array.prototype.forEach.call(arguments, b);
    return new pd(c, od);
  }
  pd.prototype.ja = function () {
    return this.C;
  };
  function rd(a) {
    return a instanceof pd && a.constructor === pd
      ? a.C
      : "type_error:SafeStyleSheet";
  }
  var sd = new pd("", od);
  function td() {
    var a = x.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  function E(a) {
    return -1 != td().indexOf(a);
  }
  function ud() {
    return E("Trident") || E("MSIE");
  }
  function vd() {
    return (
      E("Safari") &&
      !(
        wd() ||
        E("Coast") ||
        E("Opera") ||
        E(ea) ||
        E("Edg/") ||
        E("OPR") ||
        E("Firefox") ||
        E("FxiOS") ||
        E("Silk") ||
        E("Android")
      )
    );
  }
  function wd() {
    return ((E("Chrome") || E("CriOS")) && !E(ea)) || E("Silk");
  }
  function xd() {
    return (
      E("Android") &&
      !(wd() || E("Firefox") || E("FxiOS") || E("Opera") || E("Silk"))
    );
  }
  function yd() {
    var a = td();
    if (ud()) {
      var b = /rv: *([\d\.]*)/.exec(a);
      if (b && b[1]) a = b[1];
      else {
        b = "";
        var c = /MSIE +([\d\.]+)/.exec(a);
        if (c && c[1])
          if (((a = /Trident\/(\d.\d)/.exec(a)), "7.0" == c[1]))
            if (a && a[1])
              switch (a[1]) {
                case "4.0":
                  b = "8.0";
                  break;
                case "5.0":
                  b = "9.0";
                  break;
                case "6.0":
                  b = "10.0";
                  break;
                case "7.0":
                  b = "11.0";
              }
            else b = "7.0";
          else b = c[1];
        a = b;
      }
    } else a = "";
    if ("" === a) return NaN;
    a = a.split(".");
    return 0 === a.length ? NaN : Number(a[0]);
  }
  var zd = {};
  function Ad(a, b) {
    this.C = b === zd ? a : "";
    this.ma = !0;
  }
  Ad.prototype.ja = function () {
    return this.C.toString();
  };
  Ad.prototype.toString = function () {
    return this.C.toString();
  };
  function Bd(a) {
    return a instanceof Ad && a.constructor === Ad
      ? a.C
      : "type_error:SafeHtml";
  }
  function Cd(a) {
    return a instanceof Ad
      ? a
      : F(Oc(typeof a == q && a.ma ? a.ja() : String(a)));
  }
  function Dd(a) {
    if (!Ed.test("body")) throw Error("");
    if ("BODY" in Fd) throw Error("");
    var b = {},
      c = "";
    if (b)
      for (f in b)
        if (Object.prototype.hasOwnProperty.call(b, f)) {
          if (!Ed.test(f)) throw Error("");
          var d = b[f];
          if (null != d) {
            var e = f;
            if (d instanceof Bc) d = Ec(d);
            else if (e.toLowerCase() == kb) {
              if (!Ub(d)) throw Error("");
              d instanceof dd || (d = fd(d));
              d = ed(d);
            } else {
              if (/^on/i.test(e)) throw Error("");
              if (e.toLowerCase() in Gd)
                if (d instanceof Hc) d = Jc(d).toString();
                else if (d instanceof C) d = Yc(d);
                else if (typeof d === r) d = ad(d).ja();
                else throw Error("");
            }
            d.ma && (d = d.ja());
            e = e + '="' + Oc(String(d)) + '"';
            c += " " + e;
          }
        }
    var f = "<body" + c;
    null == a ? (a = []) : Array.isArray(a) || (a = [a]);
    !0 === yc.body
      ? (f += ">")
      : ((a = Hd(a)), (f += ">" + Bd(a).toString() + "</body>"));
    return F(f);
  }
  function Id(a) {
    function b(e) {
      Array.isArray(e) ? e.forEach(b) : ((e = Cd(e)), d.push(Bd(e).toString()));
    }
    var c = Cd(Jd),
      d = [];
    a.forEach(b);
    return F(d.join(Bd(c).toString()));
  }
  function Hd(a) {
    return Id(Array.prototype.slice.call(arguments));
  }
  function F(a) {
    var b = Ac();
    a = b ? b.createHTML(a) : a;
    return new Ad(a, zd);
  }
  var Ed = /^[a-zA-Z0-9-]+$/,
    Gd = {
      action: !0,
      cite: !0,
      data: !0,
      formaction: !0,
      href: !0,
      manifest: !0,
      poster: !0,
      src: !0,
    },
    Fd = {
      APPLET: !0,
      BASE: !0,
      EMBED: !0,
      IFRAME: !0,
      LINK: !0,
      MATH: !0,
      META: !0,
      OBJECT: !0,
      SCRIPT: !0,
      STYLE: !0,
      SVG: !0,
      TEMPLATE: !0,
    },
    Kd = F("<!DOCTYPE html>"),
    Jd = new Ad((x.trustedTypes && x.trustedTypes.emptyHTML) || "", zd),
    Ld = F("<br>");
  function Md(a) {
    var b = { nonce: Nd() };
    b = void 0 === b ? {} : b;
    a = (
      a instanceof Gc && a.constructor === Gc ? a.C : "type_error:SafeScript"
    ).toString();
    var c = "<script";
    b.id && (c += ' id="' + Od(b.id) + '"');
    b.nonce && (c += ' nonce="' + Od(b.nonce) + '"');
    b.type && (c += ' type="' + Od(b.type) + '"');
    return F(c + (">" + a + "\x3c/script>"));
  }
  function Od(a) {
    return a
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
  }
  function Pd(a, b) {
    if (void 0 !== a.tagName) {
      if ("script" === a.tagName.toLowerCase())
        throw Error("Use setTextContent with a SafeScript.");
      if (a.tagName.toLowerCase() === kb)
        throw Error("Use setTextContent with a SafeStyleSheet.");
    }
    a.innerHTML = Bd(b);
  }
  function Qd(a) {
    var b = document.createElement("template");
    if (!("content" in b)) {
      b = F("<html><body>" + a);
      b = new DOMParser().parseFromString(Bd(b), "text/html");
      for (a = b.createDocumentFragment(); 0 < b.body.childNodes.length; )
        a.appendChild(b.body.firstChild);
      return a;
    }
    a = F(a);
    Pd(b, a);
    return b.content;
  }
  function Rd(a) {
    a = a.nodeName;
    return typeof a === r ? a : "FORM";
  }
  function Sd(a) {
    a = a.nodeType;
    return a === Node.ELEMENT_NODE || typeof a !== cb;
  }
  function Td(a, b, c, d) {
    this.D = a;
    this.C = b;
    this.F = c;
    this.G = d;
  }
  var Ud = new Td(
    new Set([
      "ARTICLE",
      "SECTION",
      "NAV",
      "ASIDE",
      "H1",
      "H2",
      "H3",
      "H4",
      "H5",
      "H6",
      "HEADER",
      "FOOTER",
      "ADDRESS",
      "P",
      "HR",
      "PRE",
      "BLOCKQUOTE",
      "OL",
      "UL",
      "LH",
      "LI",
      "DL",
      "DT",
      "DD",
      "FIGURE",
      "FIGCAPTION",
      "MAIN",
      "DIV",
      "EM",
      "STRONG",
      "SMALL",
      "S",
      "CITE",
      "Q",
      "DFN",
      "ABBR",
      "RUBY",
      "RB",
      "RT",
      "RTC",
      "RP",
      "DATA",
      "TIME",
      "CODE",
      "VAR",
      "SAMP",
      "KBD",
      "SUB",
      "SUP",
      "I",
      "B",
      "U",
      "MARK",
      "BDI",
      "BDO",
      ja,
      "BR",
      "WBR",
      "INS",
      "DEL",
      "PICTURE",
      "PARAM",
      "TRACK",
      "MAP",
      "TABLE",
      "CAPTION",
      "COLGROUP",
      "COL",
      "TBODY",
      "THEAD",
      "TFOOT",
      "TR",
      "TD",
      "TH",
      "SELECT",
      "DATALIST",
      "OPTGROUP",
      "OPTION",
      "OUTPUT",
      "PROGRESS",
      "METER",
      "FIELDSET",
      "LEGEND",
      "DETAILS",
      "SUMMARY",
      "MENU",
      "DIALOG",
      "SLOT",
      "CANVAS",
      "FONT",
      "CENTER",
    ]),
    new Map([
      ["A", new Map([["href", { W: 2 }]])],
      ["AREA", new Map([["href", { W: 2 }]])],
      [
        "LINK",
        new Map([
          [
            "href",
            {
              W: 2,
              conditions: new Map([
                [
                  "rel",
                  new Set([
                    "alternate",
                    "author",
                    "bookmark",
                    "canonical",
                    "cite",
                    "help",
                    "icon",
                    "license",
                    "next",
                    "prefetch",
                    "dns-prefetch",
                    db,
                    "preconnect",
                    "preload",
                    "prev",
                    "search",
                    "subresource",
                  ]),
                ],
              ]),
            },
          ],
        ]),
      ],
      ["SOURCE", new Map([["src", { W: 2 }]])],
      ["IMG", new Map([["src", { W: 2 }]])],
      ["VIDEO", new Map([["src", { W: 2 }]])],
      ["AUDIO", new Map([["src", { W: 2 }]])],
    ]),
    new Set([
      pb,
      "aria-atomic",
      "aria-autocomplete",
      "aria-busy",
      "aria-checked",
      "aria-current",
      "aria-disabled",
      "aria-dropeffect",
      "aria-expanded",
      "aria-haspopup",
      "aria-hidden",
      "aria-invalid",
      "aria-label",
      "aria-level",
      "aria-live",
      "aria-multiline",
      "aria-multiselectable",
      "aria-orientation",
      "aria-posinset",
      "aria-pressed",
      "aria-readonly",
      "aria-relevant",
      "aria-required",
      "aria-selected",
      "aria-setsize",
      "aria-sort",
      "aria-valuemax",
      "aria-valuemin",
      "aria-valuenow",
      "aria-valuetext",
      "alt",
      "align",
      "autocapitalize",
      "autocomplete",
      "autocorrect",
      "autofocus",
      "autoplay",
      "bgcolor",
      "border",
      "cellpadding",
      "cellspacing",
      "checked",
      "color",
      "cols",
      "colspan",
      "controls",
      "datetime",
      "disabled",
      "download",
      "draggable",
      "enctype",
      "face",
      "formenctype",
      "frameborder",
      "height",
      "hreflang",
      Wa,
      "ismap",
      "label",
      "lang",
      "loop",
      "max",
      "maxlength",
      "media",
      "minlength",
      "min",
      "multiple",
      "muted",
      "nonce",
      "open",
      "placeholder",
      "preload",
      "rel",
      "required",
      "reversed",
      "role",
      "rows",
      "rowspan",
      "selected",
      "shape",
      "size",
      "sizes",
      "slot",
      "span",
      "spellcheck",
      "start",
      "step",
      "summary",
      "translate",
      "type",
      "valign",
      "value",
      "width",
      "wrap",
      "itemscope",
      "itemtype",
      "itemid",
      "itemprop",
      "itemref",
    ]),
    new Map([
      [
        "dir",
        {
          W: 3,
          conditions: new Map([["dir", new Set(["auto", "ltr", "rtl"])]]),
        },
      ],
      ["async", { W: 3, conditions: new Map([["async", new Set(["async"])]]) }],
      ["cite", { W: 2 }],
      [
        "loading",
        {
          W: 3,
          conditions: new Map([["loading", new Set(["eager", "lazy"])]]),
        },
      ],
      ["poster", { W: 2 }],
      [
        "target",
        { W: 3, conditions: new Map([["target", new Set(["_self", pa])]]) },
      ],
    ])
  );
  var Vd;
  try {
    new URL("s://g"), (Vd = !0);
  } catch (a) {
    Vd = !1;
  }
  var Wd = Vd,
    Xd = ["data:", "http:", Xa, "mailto:", "ftp:"];
  function Yd(a) {
    this.D = a;
    this.changes = [];
    if (ac !== ac) throw Error("Bad secret");
  }
  function Zd(a, b) {
    a.changes = [];
    b = a.C(b);
    if (0 !== a.changes.length) throw Error("");
    return b;
  }
  Yd.prototype.C = function (a) {
    var b = document.createElement("span");
    b.appendChild($d(this, a));
    a = new XMLSerializer().serializeToString(b);
    a = a.slice(a.indexOf(">") + 1, a.lastIndexOf("</"));
    return F(a);
  };
  function $d(a, b) {
    b = Qd(b);
    b = document.createTreeWalker(
      b,
      NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT,
      function (g) {
        return ae(a, g);
      },
      !1
    );
    for (
      var c = b.nextNode(), d = document.createDocumentFragment(), e = d;
      null !== c;

    ) {
      var f = void 0;
      if (c.nodeType === Node.TEXT_NODE) f = document.createTextNode(c.data);
      else if (Sd(c)) f = be(a, c);
      else throw Error("Node is not of type text or element");
      e.appendChild(f);
      if ((c = b.firstChild())) e = f;
      else
        for (; !(c = b.nextSibling()) && (c = b.parentNode()); )
          e = e.parentNode;
    }
    return d;
  }
  function be(a, b) {
    var c = Rd(b),
      d = document.createElement(c);
    b = b.attributes;
    for (var e = Cb(b), f = e.next(); !f.done; f = e.next()) {
      var g = f.value;
      f = g.name;
      g = g.value;
      var h = a.D,
        k = h.C.get(c);
      h = (null == k ? 0 : k.has(f))
        ? k.get(f)
        : h.F.has(f)
        ? { W: 1 }
        : h.G.get(f) || { W: 0 };
      a: {
        if ((k = h.conditions)) {
          k = Cb(k);
          for (var n = k.next(); !n.done; n = k.next()) {
            var u = Cb(n.value);
            n = u.next().value;
            u = u.next().value;
            var w = void 0;
            if (
              (n = null == (w = b.getNamedItem(n)) ? void 0 : w.value) &&
              !u.has(n)
            ) {
              k = !1;
              break a;
            }
          }
        }
        k = !0;
      }
      if (k)
        switch (h.W) {
          case 1:
            d.setAttribute(f, g);
            break;
          case 2:
            a: if (((h = void 0), Wd)) {
              try {
                h = new URL(g);
              } catch (G) {
                h = Xa;
                break a;
              }
              h = h.protocol;
            } else
              b: {
                h = document.createElement("a");
                try {
                  h.href = g;
                } catch (G) {
                  h = void 0;
                  break b;
                }
                h = h.protocol;
                h = ":" === h || "" === h ? Xa : h;
              }
            h = void 0 !== h && -1 !== Xd.indexOf(h.toLowerCase()) ? g : qa;
            h !== g && ce(a);
            d.setAttribute(f, h);
            break;
          case 3:
            d.setAttribute(f, g.toLowerCase());
            break;
          case 4:
            d.setAttribute(f, g);
            break;
          case 0:
            ce(a);
            break;
          default:
            throw Error("Unhandled AttributePolicyAction case");
        }
      else ce(a);
    }
    return d;
  }
  function ae(a, b) {
    if (b.nodeType === Node.TEXT_NODE) return NodeFilter.FILTER_ACCEPT;
    if (!Sd(b)) return NodeFilter.FILTER_REJECT;
    b = Rd(b);
    if (null === b) return ce(a), NodeFilter.FILTER_REJECT;
    var c = a.D;
    if ("form" !== b.toLowerCase() && (c.D.has(b) || c.C.has(b)))
      return NodeFilter.FILTER_ACCEPT;
    ce(a);
    return NodeFilter.FILTER_REJECT;
  }
  function ce(a) {
    0 === a.changes.length && a.changes.push("");
  }
  var de = new Yd(Ud);
  function ee(a, b) {
    var c;
    if ((c = b)) {
      var d, e;
      c =
        Math.random() <
        (null != (e = null != (d = b.Rd) ? d : fe[b.Ha[0]]) ? e : 0);
    }
    if (c)
      try {
        var f, g;
        Math.random() <
          (null != (g = null != (f = b.Nd) ? f : ge[b.Ha[0]]) ? g : 0) &&
          he(b, "HEARTBEAT");
        b: {
          try {
            Zd(ie, a);
          } catch (u) {
            he(b, "H_RSANITIZE");
            var h = !0;
            break b;
          }
          try {
            Zd(de, a);
          } catch (u) {
            he(b, "H_SANITIZE");
            h = !0;
            break b;
          }
          h = !1;
        }
        if (!h) {
          var k = void 0 === k ? {} : k;
          var n = Od(a);
          k.Pd && (n = n.replace(/(^|[\r\n\t ]) /g, "$1&#160;"));
          k.Od && (n = n.replace(/(\r\n|\n|\r)/g, "<br>"));
          k.Qd &&
            (n = n.replace(
              /(\t+)/g,
              '<span style="white-space:pre">$1</span>'
            ));
          F(n).toString() !== a && he(b, "H_ESCAPE");
        }
      } catch (u) {
        try {
          he(b, "CRASHED");
        } catch (w) {}
      }
    return F(a);
  }
  var fe = { 0: 1, 1: 0.01 },
    ge = { 0: 0.1, 1: 0.01 },
    H = new (function () {
      this.D = !1;
      this.C = Ud;
    })(),
    je = new Map(H.C.G);
  je.set(kb, { W: 4 });
  H.C = new Td(H.C.D, H.C.C, H.C.F, je);
  var ke = new Map(H.C.G);
  ke.set("class", { W: 1 });
  H.C = new Td(H.C.D, H.C.C, H.C.F, ke);
  var le = new Map(H.C.G);
  le.set("id", { W: 1 });
  H.C = new Td(H.C.D, H.C.C, H.C.F, le);
  if (H.D) throw Error("this sanitizer has already called build");
  H.D = !0;
  var ie = new Yd(H.C);
  function he(a, b) {
    (me.Sd || navigator.sendBeacon.bind(navigator) || ne)(
      "https://csp.withgoogle.com/csp/lcreport/" + a.Ha,
      JSON.stringify({
        host: window.location.hostname,
        type: b,
        additionalData: void 0,
      })
    );
  }
  function ne(a, b) {
    var c = new XMLHttpRequest();
    c.open("POST", a);
    c.setRequestHeader("Content-Type", "application/json");
    c.send(b);
  }
  var me = {};
  function oe(a) {
    a = a.className;
    return (typeof a === r && a.match(/\S+/g)) || [];
  }
  function pe(a, b) {
    var c = oe(a);
    qe(c, Array.prototype.slice.call(arguments, 1));
    a.className = c.join(" ");
  }
  function re(a, b) {
    var c = oe(a);
    c = se(c, Array.prototype.slice.call(arguments, 1));
    a.className = c.join(" ");
  }
  function qe(a, b) {
    for (var c = 0; c < b.length; c++) jc(a, b[c]) || a.push(b[c]);
  }
  function se(a, b) {
    return a.filter(function (c) {
      return !jc(b, c);
    });
  }
  function te(a, b, c) {
    for (var d = oe(a), e = !1, f = 0; f < d.length; f++)
      d[f] == b && (d.splice(f--, 1), (e = !0));
    e && (d.push(c), (a.className = d.join(" ")));
  }
  function ue(a, b) {
    return jc(oe(a), b);
  }
  function ve(a) {
    ve[" "](a);
    return a;
  }
  ve[" "] = function () {};
  function we(a, b) {
    var c = xe;
    return Object.prototype.hasOwnProperty.call(c, a) ? c[a] : (c[a] = b(a));
  }
  var ye = E("Opera"),
    I = ud(),
    ze = E(ea),
    Ae =
      E("Gecko") &&
      !(-1 != td().toLowerCase().indexOf("webkit") && !E(ea)) &&
      !(E("Trident") || E("MSIE")) &&
      !E(ea),
    Be = -1 != td().toLowerCase().indexOf("webkit") && !E(ea);
  function Ce() {
    var a = x.document;
    return a ? a.documentMode : void 0;
  }
  var De;
  a: {
    var Ee = "",
      Fe = (function () {
        var a = td();
        if (Ae) return /rv:([^\);]+)(\)|;)/.exec(a);
        if (ze) return /Edge\/([\d\.]+)/.exec(a);
        if (I) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
        if (Be) return /WebKit\/(\S+)/.exec(a);
        if (ye) return /(?:Version)[ \/]?(\S+)/.exec(a);
      })();
    Fe && (Ee = Fe ? Fe[1] : "");
    if (I) {
      var Ge = Ce();
      if (null != Ge && Ge > parseFloat(Ee)) {
        De = String(Ge);
        break a;
      }
    }
    De = Ee;
  }
  var He = De,
    xe = {};
  function Ie(a) {
    return we(a, function () {
      for (
        var b = 0,
          c = B(String(He)).split("."),
          d = B(String(a)).split("."),
          e = Math.max(c.length, d.length),
          f = 0;
        0 == b && f < e;
        f++
      ) {
        var g = c[f] || "",
          h = d[f] || "";
        do {
          g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
          h = /(\d*)(\D*)(.*)/.exec(h) || ["", "", "", ""];
          if (0 == g[0].length && 0 == h[0].length) break;
          b =
            Wc(
              0 == g[1].length ? 0 : parseInt(g[1], 10),
              0 == h[1].length ? 0 : parseInt(h[1], 10)
            ) ||
            Wc(0 == g[2].length, 0 == h[2].length) ||
            Wc(g[2], h[2]);
          g = g[3];
          h = h[3];
        } while (0 == b);
      }
      return 0 <= b;
    });
  }
  var Je;
  if (x.document && I) {
    var Ke = Ce();
    Je = Ke ? Ke : parseInt(He, 10) || void 0;
  } else Je = void 0;
  var Le = Je;
  try {
    new self.OffscreenCanvas(0, 0).getContext("2d");
  } catch (a) {}
  var Me = I || Be;
  function Ne(a) {
    return function () {
      return a;
    };
  }
  function Oe() {
    return null;
  }
  function Pe() {}
  function Qe(a) {
    return a;
  }
  var Re = (function (a) {
    var b = !1,
      c;
    return function () {
      b || ((c = a()), (b = !0));
      return c;
    };
  })(function () {
    var a = document.createElement(l),
      b = document.createElement(l);
    b.appendChild(document.createElement(l));
    a.appendChild(b);
    b = a.firstChild.firstChild;
    a.innerHTML = Bd(Jd);
    return !b.parentElement;
  });
  function Se(a, b) {
    if (Re()) for (; a.lastChild; ) a.removeChild(a.lastChild);
    a.innerHTML = Bd(b);
  }
  function Te(a, b) {
    var c = Nd(a.ownerDocument && a.ownerDocument.defaultView);
    c && a.setAttribute("nonce", c);
    a.src = Jc(b);
  }
  var Ue = /^[\w+/_-]+[=]{0,2}$/;
  function Nd(a) {
    a = (a || x).document;
    return a.querySelector
      ? (a = a.querySelector("script[nonce]")) &&
        (a = a.nonce || a.getAttribute("nonce")) &&
        Ue.test(a)
        ? a
        : ""
      : "";
  }
  function Ve(a, b) {
    this.x = void 0 !== a ? a : 0;
    this.y = void 0 !== b ? b : 0;
  }
  Ve.prototype.ceil = function () {
    this.x = Math.ceil(this.x);
    this.y = Math.ceil(this.y);
    return this;
  };
  Ve.prototype.floor = function () {
    this.x = Math.floor(this.x);
    this.y = Math.floor(this.y);
    return this;
  };
  Ve.prototype.round = function () {
    this.x = Math.round(this.x);
    this.y = Math.round(this.y);
    return this;
  };
  function We(a, b) {
    this.width = a;
    this.height = b;
  }
  t = We.prototype;
  t.aspectRatio = function () {
    return this.width / this.height;
  };
  t.la = function () {
    return !(this.width * this.height);
  };
  t.ceil = function () {
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  t.floor = function () {
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  t.round = function () {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  var Xe = String.prototype.repeat
    ? function (a, b) {
        return a.repeat(b);
      }
    : function (a, b) {
        return Array(b + 1).join(a);
      };
  function Ye(a) {
    return String(a).replace(/\-([a-z])/g, function (b, c) {
      return c.toUpperCase();
    });
  }
  function Ze(a) {
    return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function (b, c, d) {
      return c + d.toUpperCase();
    });
  }
  function J(a) {
    return $e(document, a);
  }
  function $e(a, b) {
    return typeof b === r ? a.getElementById(b) : b;
  }
  function af(a, b) {
    var c = b || document;
    return c.querySelectorAll && c.querySelector
      ? c.querySelectorAll("." + a)
      : bf(document, "*", a, b);
  }
  function K(a, b) {
    var c = b || document;
    if (c.getElementsByClassName) a = c.getElementsByClassName(a)[0];
    else {
      c = document;
      var d = b || c;
      a =
        d.querySelectorAll && d.querySelector && a
          ? d.querySelector(a ? "." + a : "")
          : bf(c, "*", a, b)[0] || null;
    }
    return a || null;
  }
  function bf(a, b, c, d) {
    a = d || a;
    b = b && "*" != b ? String(b).toUpperCase() : "";
    if (a.querySelectorAll && a.querySelector && (b || c))
      return a.querySelectorAll(b + (c ? "." + c : ""));
    if (c && a.getElementsByClassName) {
      a = a.getElementsByClassName(c);
      if (b) {
        d = {};
        for (var e = 0, f = 0, g; (g = a[f]); f++)
          b == g.nodeName && (d[e++] = g);
        d.length = e;
        return d;
      }
      return a;
    }
    a = a.getElementsByTagName(b || "*");
    if (c) {
      d = {};
      for (f = e = 0; (g = a[f]); f++)
        (b = g.className),
          typeof b.split == m && jc(b.split(/\s+/), c) && (d[e++] = g);
      d.length = e;
      return d;
    }
    return a;
  }
  function cf(a, b) {
    qc(b, function (c, d) {
      c && typeof c == q && c.ma && (c = c.ja());
      d == kb
        ? (a.style.cssText = c)
        : "class" == d
        ? (a.className = c)
        : "for" == d
        ? (a.htmlFor = c)
        : df.hasOwnProperty(d)
        ? a.setAttribute(df[d], c)
        : Nc(d, "aria-") || Nc(d, "data-")
        ? a.setAttribute(d, c)
        : (a[d] = c);
    });
  }
  var df = {
    cellpadding: "cellPadding",
    cellspacing: "cellSpacing",
    colspan: "colSpan",
    frameborder: "frameBorder",
    height: "height",
    maxlength: "maxLength",
    nonce: "nonce",
    role: "role",
    rowspan: "rowSpan",
    type: "type",
    usemap: "useMap",
    valign: "vAlign",
    width: "width",
  };
  function ef(a, b, c) {
    return ff(document, arguments);
  }
  function ff(a, b) {
    var c = b[1],
      d = gf(a, String(b[0]));
    c &&
      (typeof c === r
        ? (d.className = c)
        : Array.isArray(c)
        ? (d.className = c.join(" "))
        : cf(d, c));
    2 < b.length && hf(a, d, b);
    return d;
  }
  function hf(a, b, c) {
    function d(h) {
      h && b.appendChild(typeof h === r ? a.createTextNode(h) : h);
    }
    for (var e = 2; e < c.length; e++) {
      var f = c[e];
      if (!Tb(f) || (Ub(f) && 0 < f.nodeType)) d(f);
      else {
        a: {
          if (f && typeof f.length == cb) {
            if (Ub(f)) {
              var g = typeof f.item == m || typeof f.item == r;
              break a;
            }
            if (typeof f === m) {
              g = typeof f.item == m;
              break a;
            }
          }
          g = !1;
        }
        fc(g ? nc(f) : f, d);
      }
    }
  }
  function gf(a, b) {
    b = String(b);
    "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
    return a.createElement(b);
  }
  function jf(a) {
    for (var b; (b = a.firstChild); ) a.removeChild(b);
  }
  function kf(a) {
    return a && a.parentNode ? a.parentNode.removeChild(a) : null;
  }
  function lf(a) {
    var b;
    if (
      Me &&
      !(
        I &&
        Ie("9") &&
        !Ie("10") &&
        x.SVGElement &&
        a instanceof x.SVGElement
      ) &&
      (b = a.parentElement)
    )
      return b;
    b = a.parentNode;
    return Ub(b) && 1 == b.nodeType ? b : null;
  }
  function mf(a, b) {
    if ("textContent" in a) a.textContent = b;
    else if (3 == a.nodeType) a.data = String(b);
    else if (a.firstChild && 3 == a.firstChild.nodeType) {
      for (; a.lastChild != a.firstChild; ) a.removeChild(a.lastChild);
      a.firstChild.data = String(b);
    } else
      jf(a),
        a.appendChild(
          (9 == a.nodeType ? a : a.ownerDocument || a.document).createTextNode(
            String(b)
          )
        );
  }
  var nf = { SCRIPT: 1, STYLE: 1, HEAD: 1, IFRAME: 1, OBJECT: 1 },
    of = { IMG: " ", BR: "\n" };
  function pf(a, b, c) {
    if (!(a.nodeName in nf))
      if (3 == a.nodeType)
        c
          ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, ""))
          : b.push(a.nodeValue);
      else if (a.nodeName in of) b.push(of[a.nodeName]);
      else for (a = a.firstChild; a; ) pf(a, b, c), (a = a.nextSibling);
  }
  function qf(a, b, c) {
    if (!b && !c) return null;
    var d = b ? String(b).toUpperCase() : null;
    return rf(a, function (e) {
      return (
        (!d || e.nodeName == d) &&
        (!c || (typeof e.className === r && jc(e.className.split(/\s+/), c)))
      );
    });
  }
  function rf(a, b) {
    for (var c = 0; a; ) {
      if (b(a)) return a;
      a = a.parentNode;
      c++;
    }
    return null;
  }
  function sf(a) {
    this.D = a || x.document || document;
  }
  sf.prototype.Ya = function () {
    return $e(this.D);
  };
  sf.prototype.C = function (a, b, c) {
    return ff(this.D, arguments);
  };
  function tf(a, b) {
    return gf(a.D, b);
  }
  sf.prototype.appendChild = function (a, b) {
    a.appendChild(b);
  };
  function uf() {
    this.M = this.M;
    this.ha = this.ha;
  }
  uf.prototype.M = !1;
  uf.prototype.isDisposed = function () {
    return this.M;
  };
  uf.prototype.wa = function () {
    this.M || ((this.M = !0), this.X());
  };
  uf.prototype.X = function () {
    if (this.ha) for (; this.ha.length; ) this.ha.shift()();
  };
  function vf(a, b) {
    this.type = a;
    this.currentTarget = this.target = b;
    this.defaultPrevented = this.Ma = !1;
  }
  vf.prototype.stopPropagation = function () {
    this.Ma = !0;
  };
  vf.prototype.preventDefault = function () {
    this.defaultPrevented = !0;
  };
  var wf = (function () {
    if (!x.addEventListener || !Object.defineProperty) return !1;
    var a = !1,
      b = Object.defineProperty({}, "passive", {
        get: function () {
          a = !0;
        },
      });
    try {
      x.addEventListener("test", function () {}, b),
        x.removeEventListener("test", function () {}, b);
    } catch (c) {}
    return a;
  })();
  function xf(a, b) {
    vf.call(this, a ? a.type : "");
    this.relatedTarget = this.currentTarget = this.target = null;
    this.button =
      this.screenY =
      this.screenX =
      this.clientY =
      this.clientX =
      this.offsetY =
      this.offsetX =
        0;
    this.key = "";
    this.charCode = this.keyCode = 0;
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.pointerId = 0;
    this.pointerType = "";
    this.C = null;
    a && this.init(a, b);
  }
  A(xf, vf);
  var yf = { 2: "touch", 3: "pen", 4: "mouse" };
  xf.prototype.init = function (a, b) {
    var c = (this.type = a.type),
      d =
        a.changedTouches && a.changedTouches.length
          ? a.changedTouches[0]
          : null;
    this.target = a.target || a.srcElement;
    this.currentTarget = b;
    if ((b = a.relatedTarget)) {
      if (Ae) {
        a: {
          try {
            ve(b.nodeName);
            var e = !0;
            break a;
          } catch (f) {}
          e = !1;
        }
        e || (b = null);
      }
    } else
      "mouseover" == c
        ? (b = a.fromElement)
        : "mouseout" == c && (b = a.toElement);
    this.relatedTarget = b;
    d
      ? ((this.clientX = void 0 !== d.clientX ? d.clientX : d.pageX),
        (this.clientY = void 0 !== d.clientY ? d.clientY : d.pageY),
        (this.screenX = d.screenX || 0),
        (this.screenY = d.screenY || 0))
      : ((this.offsetX = Be || void 0 !== a.offsetX ? a.offsetX : a.layerX),
        (this.offsetY = Be || void 0 !== a.offsetY ? a.offsetY : a.layerY),
        (this.clientX = void 0 !== a.clientX ? a.clientX : a.pageX),
        (this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY),
        (this.screenX = a.screenX || 0),
        (this.screenY = a.screenY || 0));
    this.button = a.button;
    this.keyCode = a.keyCode || 0;
    this.key = a.key || "";
    this.charCode = a.charCode || ("keypress" == c ? a.keyCode : 0);
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.pointerId = a.pointerId || 0;
    this.pointerType =
      typeof a.pointerType === r ? a.pointerType : yf[a.pointerType] || "";
    this.state = a.state;
    this.C = a;
    a.defaultPrevented && xf.O.preventDefault.call(this);
  };
  xf.prototype.stopPropagation = function () {
    xf.O.stopPropagation.call(this);
    this.C.stopPropagation
      ? this.C.stopPropagation()
      : (this.C.cancelBubble = !0);
  };
  xf.prototype.preventDefault = function () {
    xf.O.preventDefault.call(this);
    var a = this.C;
    a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  };
  var zf = "closure_listenable_" + ((1e6 * Math.random()) | 0);
  function Af(a) {
    return !(!a || !a[zf]);
  }
  var Bf = 0;
  function Cf(a, b, c, d, e) {
    this.listener = a;
    this.proxy = null;
    this.src = b;
    this.type = c;
    this.capture = !!d;
    this.cb = e;
    this.key = ++Bf;
    this.Na = this.Wa = !1;
  }
  function Df(a) {
    a.Na = !0;
    a.listener = null;
    a.proxy = null;
    a.src = null;
    a.cb = null;
  }
  function Ef(a) {
    this.src = a;
    this.C = {};
    this.D = 0;
  }
  Ef.prototype.add = function (a, b, c, d, e) {
    var f = a.toString();
    a = this.C[f];
    a || ((a = this.C[f] = []), this.D++);
    var g = Ff(a, b, d, e);
    -1 < g
      ? ((b = a[g]), c || (b.Wa = !1))
      : ((b = new Cf(b, this.src, f, !!d, e)), (b.Wa = c), a.push(b));
    return b;
  };
  function Gf(a, b) {
    var c = b.type;
    if (!(c in a.C)) return !1;
    var d = lc(a.C[c], b);
    d && (Df(b), 0 == a.C[c].length && (delete a.C[c], a.D--));
    return d;
  }
  function Hf(a) {
    var b = 0,
      c;
    for (c in a.C) {
      for (var d = a.C[c], e = 0; e < d.length; e++) ++b, Df(d[e]);
      delete a.C[c];
      a.D--;
    }
  }
  function If(a, b, c, d, e) {
    a = a.C[b.toString()];
    b = -1;
    a && (b = Ff(a, c, d, e));
    return -1 < b ? a[b] : null;
  }
  function Ff(a, b, c, d) {
    for (var e = 0; e < a.length; ++e) {
      var f = a[e];
      if (!f.Na && f.listener == b && f.capture == !!c && f.cb == d) return e;
    }
    return -1;
  }
  var Jf = "closure_lm_" + ((1e6 * Math.random()) | 0),
    Kf = {},
    Lf = 0;
  function L(a, b, c, d, e) {
    if (d && d.once) return Mf(a, b, c, d, e);
    if (Array.isArray(b)) {
      for (var f = 0; f < b.length; f++) L(a, b[f], c, d, e);
      return null;
    }
    c = Nf(c);
    return Af(a)
      ? a.fa.add(String(b), c, !1, Ub(d) ? !!d.capture : !!d, e)
      : Pf(a, b, c, !1, d, e);
  }
  function Pf(a, b, c, d, e, f) {
    if (!b) throw Error("Invalid event type");
    var g = Ub(e) ? !!e.capture : !!e,
      h = Qf(a);
    h || (a[Jf] = h = new Ef(a));
    c = h.add(b, c, d, g, f);
    if (c.proxy) return c;
    d = Rf();
    c.proxy = d;
    d.src = a;
    d.listener = c;
    if (a.addEventListener)
      wf || (e = g),
        void 0 === e && (e = !1),
        a.addEventListener(b.toString(), d, e);
    else if (a.attachEvent) a.attachEvent(Sf(b.toString()), d);
    else if (a.addListener && a.removeListener) a.addListener(d);
    else throw Error("addEventListener and attachEvent are unavailable.");
    Lf++;
    return c;
  }
  function Rf() {
    function a(c) {
      return b.call(a.src, a.listener, c);
    }
    var b = Tf;
    return a;
  }
  function Mf(a, b, c, d, e) {
    if (Array.isArray(b)) {
      for (var f = 0; f < b.length; f++) Mf(a, b[f], c, d, e);
      return null;
    }
    c = Nf(c);
    return Af(a)
      ? a.fa.add(String(b), c, !0, Ub(d) ? !!d.capture : !!d, e)
      : Pf(a, b, c, !0, d, e);
  }
  function Uf(a, b, c, d, e) {
    if (Array.isArray(b))
      for (var f = 0; f < b.length; f++) Uf(a, b[f], c, d, e);
    else
      (d = Ub(d) ? !!d.capture : !!d),
        (c = Nf(c)),
        Af(a)
          ? ((a = a.fa),
            (b = String(b).toString()),
            b in a.C &&
              ((f = a.C[b]),
              (c = Ff(f, c, d, e)),
              -1 < c &&
                (Df(f[c]),
                Array.prototype.splice.call(f, c, 1),
                0 == f.length && (delete a.C[b], a.D--))))
          : a && (a = Qf(a)) && (c = If(a, b, c, d, e)) && Vf(c);
  }
  function Vf(a) {
    if (typeof a === cb || !a || a.Na) return !1;
    var b = a.src;
    if (Af(b)) return Gf(b.fa, a);
    var c = a.type,
      d = a.proxy;
    b.removeEventListener
      ? b.removeEventListener(c, d, a.capture)
      : b.detachEvent
      ? b.detachEvent(Sf(c), d)
      : b.addListener && b.removeListener && b.removeListener(d);
    Lf--;
    (c = Qf(b))
      ? (Gf(c, a), 0 == c.D && ((c.src = null), (b[Jf] = null)))
      : Df(a);
    return !0;
  }
  function Wf(a) {
    if (a)
      if (Af(a)) a.fa && Hf(a.fa);
      else if ((a = Qf(a))) {
        var b = 0,
          c;
        for (c in a.C)
          for (var d = a.C[c].concat(), e = 0; e < d.length; ++e)
            Vf(d[e]) && ++b;
      }
  }
  function Sf(a) {
    return a in Kf ? Kf[a] : (Kf[a] = "on" + a);
  }
  function Tf(a, b) {
    if (a.Na) a = !0;
    else {
      b = new xf(b, this);
      var c = a.listener,
        d = a.cb || a.src;
      a.Wa && Vf(a);
      a = c.call(d, b);
    }
    return a;
  }
  function Qf(a) {
    a = a[Jf];
    return a instanceof Ef ? a : null;
  }
  var Xf = "__closure_events_fn_" + ((1e9 * Math.random()) >>> 0);
  function Nf(a) {
    if (typeof a === m) return a;
    a[Xf] ||
      (a[Xf] = function (b) {
        return a.handleEvent(b);
      });
    return a[Xf];
  }
  function Yf(a) {
    uf.call(this);
    this.D = a;
    this.C = {};
  }
  A(Yf, uf);
  var Zf = [];
  function $f(a, b, c, d) {
    Array.isArray(c) || (c && (Zf[0] = c.toString()), (c = Zf));
    for (var e = 0; e < c.length; e++) {
      var f = L(b, c[e], d || a.handleEvent, !1, a.D || a);
      if (!f) break;
      a.C[f.key] = f;
    }
  }
  function ag(a, b, c, d, e, f) {
    if (Array.isArray(c))
      for (var g = 0; g < c.length; g++) ag(a, b, c[g], d, e, f);
    else
      (d = d || a.handleEvent),
        (e = Ub(e) ? !!e.capture : !!e),
        (f = f || a.D || a),
        (d = Nf(d)),
        (e = !!e),
        (c = Af(b)
          ? If(b.fa, String(c), d, e, f)
          : b
          ? (b = Qf(b))
            ? If(b, c, d, e, f)
            : null
          : null),
        c && (Vf(c), delete a.C[c.key]);
  }
  function bg(a) {
    qc(
      a.C,
      function (b, c) {
        this.C.hasOwnProperty(c) && Vf(b);
      },
      a
    );
    a.C = {};
  }
  Yf.prototype.X = function () {
    Yf.O.X.call(this);
    bg(this);
  };
  Yf.prototype.handleEvent = function () {
    throw Error("EventHandler.handleEvent not implemented");
  };
  function cg() {
    uf.call(this);
    this.fa = new Ef(this);
    this.fd = this;
    this.Ga = null;
  }
  A(cg, uf);
  cg.prototype[zf] = !0;
  cg.prototype.addEventListener = function (a, b, c, d) {
    L(this, a, b, c, d);
  };
  cg.prototype.removeEventListener = function (a, b, c, d) {
    Uf(this, a, b, c, d);
  };
  function M(a, b) {
    var c = a.Ga;
    if (c) {
      var d = [];
      for (var e = 1; c; c = c.Ga) d.push(c), ++e;
    }
    a = a.fd;
    c = b.type || b;
    typeof b === r
      ? (b = new vf(b, a))
      : b instanceof vf
      ? (b.target = b.target || a)
      : ((e = b), (b = new vf(c, a)), xc(b, e));
    e = !0;
    if (d)
      for (var f = d.length - 1; !b.Ma && 0 <= f; f--) {
        var g = (b.currentTarget = d[f]);
        e = dg(g, c, !0, b) && e;
      }
    b.Ma ||
      ((g = b.currentTarget = a),
      (e = dg(g, c, !0, b) && e),
      b.Ma || (e = dg(g, c, !1, b) && e));
    if (d)
      for (f = 0; !b.Ma && f < d.length; f++)
        (g = b.currentTarget = d[f]), (e = dg(g, c, !1, b) && e);
  }
  cg.prototype.X = function () {
    cg.O.X.call(this);
    this.fa && Hf(this.fa);
    this.Ga = null;
  };
  function dg(a, b, c, d) {
    b = a.fa.C[String(b)];
    if (!b) return !0;
    b = b.concat();
    for (var e = !0, f = 0; f < b.length; ++f) {
      var g = b[f];
      if (g && !g.Na && g.capture == c) {
        var h = g.listener,
          k = g.cb || g.src;
        g.Wa && Gf(a.fa, g);
        e = !1 !== h.call(k, d) && e;
      }
    }
    return e && !d.defaultPrevented;
  }
  function eg(a, b) {
    this.F = a;
    this.G = b;
    this.D = 0;
    this.C = null;
  }
  eg.prototype.get = function () {
    if (0 < this.D) {
      this.D--;
      var a = this.C;
      this.C = a.next;
      a.next = null;
    } else a = this.F();
    return a;
  };
  function fg(a, b) {
    a.G(b);
    100 > a.D && (a.D++, (b.next = a.C), (a.C = b));
  }
  var gg;
  function hg() {
    var a = x.MessageChannel;
    "undefined" === typeof a &&
      "undefined" !== typeof window &&
      window.postMessage &&
      window.addEventListener &&
      !E("Presto") &&
      (a = function () {
        var e = gf(document, "IFRAME");
        e.style.display = p;
        document.documentElement.appendChild(e);
        var f = e.contentWindow;
        e = f.document;
        e.open();
        e.close();
        var g = "callImmediate" + Math.random(),
          h =
            "file:" == f.location.protocol
              ? "*"
              : f.location.protocol + "//" + f.location.host;
        e = y(function (k) {
          if (("*" == h || k.origin == h) && k.data == g)
            this.port1.onmessage();
        }, this);
        f.addEventListener("message", e, !1);
        this.port1 = {};
        this.port2 = {
          postMessage: function () {
            f.postMessage(g, h);
          },
        };
      });
    if ("undefined" !== typeof a && !ud()) {
      var b = new a(),
        c = {},
        d = c;
      b.port1.onmessage = function () {
        if (void 0 !== c.next) {
          c = c.next;
          var e = c.Ub;
          c.Ub = null;
          e();
        }
      };
      return function (e) {
        d.next = { Ub: e };
        d = d.next;
        b.port2.postMessage(0);
      };
    }
    return function (e) {
      x.setTimeout(e, 0);
    };
  }
  function ig(a) {
    x.setTimeout(function () {
      throw a;
    }, 0);
  }
  function jg() {
    this.D = this.C = null;
  }
  jg.prototype.add = function (a, b) {
    var c = kg.get();
    c.set(a, b);
    this.D ? (this.D.next = c) : (this.C = c);
    this.D = c;
  };
  function lg() {
    var a = mg,
      b = null;
    a.C && ((b = a.C), (a.C = a.C.next), a.C || (a.D = null), (b.next = null));
    return b;
  }
  var kg = new eg(
    function () {
      return new ng();
    },
    function (a) {
      return a.reset();
    }
  );
  function ng() {
    this.next = this.scope = this.C = null;
  }
  ng.prototype.set = function (a, b) {
    this.C = a;
    this.scope = b;
    this.next = null;
  };
  ng.prototype.reset = function () {
    this.next = this.scope = this.C = null;
  };
  var og,
    pg = !1,
    mg = new jg();
  function qg(a, b) {
    og || rg();
    pg || (og(), (pg = !0));
    mg.add(a, b);
  }
  function rg() {
    if (x.Promise && x.Promise.resolve) {
      var a = x.Promise.resolve(void 0);
      og = function () {
        a.then(sg);
      };
    } else
      og = function () {
        var b = sg;
        typeof x.setImmediate !== m ||
        (x.Window &&
          x.Window.prototype &&
          !E(ea) &&
          x.Window.prototype.setImmediate == x.setImmediate)
          ? (gg || (gg = hg()), gg(b))
          : x.setImmediate(b);
      };
  }
  function sg() {
    for (var a; (a = lg()); ) {
      try {
        a.C.call(a.scope);
      } catch (b) {
        ig(b);
      }
      fg(kg, a);
    }
    pg = !1;
  }
  function tg(a) {
    if (!a) return !1;
    try {
      return !!a.$goog_Thenable;
    } catch (b) {
      return !1;
    }
  }
  function ug(a) {
    this.C = 0;
    this.M = void 0;
    this.G = this.D = this.F = null;
    this.J = this.K = !1;
    if (a != Pe)
      try {
        var b = this;
        a.call(
          void 0,
          function (c) {
            vg(b, 2, c);
          },
          function (c) {
            vg(b, 3, c);
          }
        );
      } catch (c) {
        vg(this, 3, c);
      }
  }
  function wg() {
    this.next = this.F = this.D = this.G = this.C = null;
    this.J = !1;
  }
  wg.prototype.reset = function () {
    this.F = this.D = this.G = this.C = null;
    this.J = !1;
  };
  var xg = new eg(
    function () {
      return new wg();
    },
    function (a) {
      a.reset();
    }
  );
  function yg(a, b, c) {
    var d = xg.get();
    d.G = a;
    d.D = b;
    d.F = c;
    return d;
  }
  function zg() {
    var a,
      b,
      c = new ug(function (d, e) {
        a = d;
        b = e;
      });
    return new Ag(c, a, b);
  }
  ug.prototype.then = function (a, b, c) {
    return Bg(this, typeof a === m ? a : null, typeof b === m ? b : null, c);
  };
  ug.prototype.$goog_Thenable = !0;
  ug.prototype.cancel = function (a) {
    if (0 == this.C) {
      var b = new Cg(a);
      qg(function () {
        Dg(this, b);
      }, this);
    }
  };
  function Dg(a, b) {
    if (0 == a.C)
      if (a.F) {
        var c = a.F;
        if (c.D) {
          for (
            var d = 0, e = null, f = null, g = c.D;
            g && (g.J || (d++, g.C == a && (e = g), !(e && 1 < d)));
            g = g.next
          )
            e || (f = g);
          e &&
            (0 == c.C && 1 == d
              ? Dg(c, b)
              : (f
                  ? ((d = f),
                    d.next == c.G && (c.G = d),
                    (d.next = d.next.next))
                  : Eg(c),
                Fg(c, e, 3, b)));
        }
        a.F = null;
      } else vg(a, 3, b);
  }
  function Gg(a, b) {
    a.D || (2 != a.C && 3 != a.C) || Hg(a);
    a.G ? (a.G.next = b) : (a.D = b);
    a.G = b;
  }
  function Bg(a, b, c, d) {
    var e = yg(null, null, null);
    e.C = new ug(function (f, g) {
      e.G = b
        ? function (h) {
            try {
              var k = b.call(d, h);
              f(k);
            } catch (n) {
              g(n);
            }
          }
        : f;
      e.D = c
        ? function (h) {
            try {
              var k = c.call(d, h);
              void 0 === k && h instanceof Cg ? g(h) : f(k);
            } catch (n) {
              g(n);
            }
          }
        : g;
    });
    e.C.F = a;
    Gg(a, e);
    return e.C;
  }
  ug.prototype.R = function (a) {
    this.C = 0;
    vg(this, 2, a);
  };
  ug.prototype.T = function (a) {
    this.C = 0;
    vg(this, 3, a);
  };
  function vg(a, b, c) {
    if (0 == a.C) {
      a === c &&
        ((b = 3), (c = new TypeError("Promise cannot resolve to itself")));
      a.C = 1;
      a: {
        var d = c,
          e = a.R,
          f = a.T;
        if (d instanceof ug) {
          Gg(d, yg(e || Pe, f || null, a));
          var g = !0;
        } else if (tg(d)) d.then(e, f, a), (g = !0);
        else {
          if (Ub(d))
            try {
              var h = d.then;
              if (typeof h === m) {
                Ig(d, h, e, f, a);
                g = !0;
                break a;
              }
            } catch (k) {
              f.call(a, k);
              g = !0;
              break a;
            }
          g = !1;
        }
      }
      g ||
        ((a.M = c),
        (a.C = b),
        (a.F = null),
        Hg(a),
        3 != b || c instanceof Cg || Jg(a, c));
    }
  }
  function Ig(a, b, c, d, e) {
    function f(k) {
      h || ((h = !0), d.call(e, k));
    }
    function g(k) {
      h || ((h = !0), c.call(e, k));
    }
    var h = !1;
    try {
      b.call(a, g, f);
    } catch (k) {
      f(k);
    }
  }
  function Hg(a) {
    a.K || ((a.K = !0), qg(a.L, a));
  }
  function Eg(a) {
    var b = null;
    a.D && ((b = a.D), (a.D = b.next), (b.next = null));
    a.D || (a.G = null);
    return b;
  }
  ug.prototype.L = function () {
    for (var a; (a = Eg(this)); ) Fg(this, a, this.C, this.M);
    this.K = !1;
  };
  function Fg(a, b, c, d) {
    if (3 == c && b.D && !b.J) for (; a && a.J; a = a.F) a.J = !1;
    if (b.C) (b.C.F = null), Kg(b, c, d);
    else
      try {
        b.J ? b.G.call(b.F) : Kg(b, c, d);
      } catch (e) {
        Lg.call(null, e);
      }
    fg(xg, b);
  }
  function Kg(a, b, c) {
    2 == b ? a.G.call(a.F, c) : a.D && a.D.call(a.F, c);
  }
  function Jg(a, b) {
    a.J = !0;
    qg(function () {
      a.J && Lg.call(null, b);
    });
  }
  var Lg = ig;
  function Cg(a) {
    bc.call(this, a);
  }
  A(Cg, bc);
  Cg.prototype.name = "cancel";
  function Ag(a, b, c) {
    this.promise = a;
    this.resolve = b;
    this.reject = c;
  }
  function Mg(a, b) {
    cg.call(this);
    this.D = a || 1;
    this.C = b || x;
    this.F = y(this.Kd, this);
    this.G = Date.now();
  }
  A(Mg, cg);
  t = Mg.prototype;
  t.Ra = !1;
  t.na = null;
  t.Kd = function () {
    if (this.Ra) {
      var a = Date.now() - this.G;
      0 < a && a < 0.8 * this.D
        ? (this.na = this.C.setTimeout(this.F, this.D - a))
        : (this.na && (this.C.clearTimeout(this.na), (this.na = null)),
          M(this, "tick"),
          this.Ra && (Ng(this), this.start()));
    }
  };
  t.start = function () {
    this.Ra = !0;
    this.na ||
      ((this.na = this.C.setTimeout(this.F, this.D)), (this.G = Date.now()));
  };
  function Ng(a) {
    a.Ra = !1;
    a.na && (a.C.clearTimeout(a.na), (a.na = null));
  }
  t.X = function () {
    Mg.O.X.call(this);
    Ng(this);
    delete this.C;
  };
  function Og(a, b, c) {
    if (typeof a === m) c && (a = y(a, c));
    else if (a && typeof a.handleEvent == m) a = y(a.handleEvent, a);
    else throw Error("Invalid listener argument");
    return 2147483647 < Number(b) ? -1 : x.setTimeout(a, b || 0);
  }
  function Pg() {
    this.J = {};
    this.C = {};
    this.F = {};
    this.G = null;
    this.D = [];
  }
  Sb(Pg);
  function Qg(a) {
    var b = Pg.Za(),
      c = b.J,
      d = b.C;
    d.lightbox
      ? a(d.lightbox[1])
      : c.lightbox
      ? c.lightbox.push([1, a])
      : ((c.lightbox = [[1, a]]),
        typeof b.G === r ? Rg(b, "lightbox") : b.D.push("lightbox"));
  }
  function Sg() {
    return function () {
      var a = arguments;
      Qg(function (b) {
        b.apply(null, a);
      });
    };
  }
  Pg.prototype.K = function (a, b) {
    return a + "_" + b + ".js";
  };
  function Tg(a) {
    eval(a);
  }
  Pg.prototype.init = function (a, b) {
    z("__gjsload__", Tg);
    this.G = a.replace(/\.js$/, "");
    b && (this.K = b);
    this.D.forEach(function (c) {
      Rg(this, c);
    }, this);
    kc(this.D);
  };
  function Rg(a, b) {
    Og(
      function () {
        if (!this.C[b]) {
          var c = this.K(this.G, b),
            d = tc(this.F, c);
          this.F[b] = c;
          d ||
            ((d = ef("SCRIPT", { type: mb })),
            Te(d, Lc(c)),
            document.body.appendChild(d));
        }
      },
      0,
      a
    );
  }
  function Ug(a) {
    try {
      return x.JSON.parse(a);
    } catch (b) {}
    a = String(a);
    if (
      /^\s*$/.test(a)
        ? 0
        : /^[\],:{}\s\u2028\u2029]*$/.test(
            a
              .replace(/\\["\\\/bfnrtu]/g, "@")
              .replace(
                /(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g,
                "]"
              )
              .replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, "")
          )
    )
      try {
        return eval("(" + a + ")");
      } catch (b) {}
    throw Error("Invalid JSON string: " + a);
  }
  function Vg() {}
  Vg.prototype.C = null;
  function Wg(a) {
    var b;
    (b = a.C) || ((b = {}), Xg(a) && ((b[0] = !0), (b[1] = !0)), (b = a.C = b));
    return b;
  }
  var Yg;
  function Zg() {}
  A(Zg, Vg);
  function $g(a) {
    return (a = Xg(a)) ? new ActiveXObject(a) : new XMLHttpRequest();
  }
  function Xg(a) {
    if (
      !a.D &&
      "undefined" == typeof XMLHttpRequest &&
      "undefined" != typeof ActiveXObject
    ) {
      for (
        var b = [
            "MSXML2.XMLHTTP.6.0",
            "MSXML2.XMLHTTP.3.0",
            "MSXML2.XMLHTTP",
            "Microsoft.XMLHTTP",
          ],
          c = 0;
        c < b.length;
        c++
      ) {
        var d = b[c];
        try {
          return new ActiveXObject(d), (a.D = d);
        } catch (e) {}
      }
      throw Error(
        "Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed"
      );
    }
    return a.D;
  }
  Yg = new Zg();
  var ah = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function bh(a, b) {
    if (a) {
      a = a.split("&");
      for (var c = 0; c < a.length; c++) {
        var d = a[c].indexOf("="),
          e = null;
        if (0 <= d) {
          var f = a[c].substring(0, d);
          e = a[c].substring(d + 1);
        } else f = a[c];
        b(f, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "");
      }
    }
  }
  function ch(a) {
    cg.call(this);
    this.headers = new Map();
    this.da = a || null;
    this.F = !1;
    this.Z = this.C = null;
    this.Fa = "";
    this.J = 0;
    this.G = this.Ea = this.T = this.sa = !1;
    this.R = 0;
    this.Y = null;
    this.L = "";
    this.xb = this.K = !1;
  }
  A(ch, cg);
  var dh = /^https?$/i,
    eh = ["POST", "PUT"],
    fh = [];
  function gh(a, b, c, d) {
    var e = new ch();
    fh.push(e);
    b && e.fa.add(za, b, !1, void 0, void 0);
    e.fa.add(eb, e.jd, !0, void 0, void 0);
    hh(e, a, c, d);
  }
  t = ch.prototype;
  t.jd = function () {
    this.wa();
    lc(fh, this);
  };
  t.ec = function () {
    return this.L;
  };
  t.fc = function () {
    return this.K;
  };
  function hh(a, b, c, d, e) {
    if (a.C)
      throw Error(
        "[goog.net.XhrIo] Object is active with another request=" +
          a.Fa +
          "; newUri=" +
          b
      );
    c = c ? c.toUpperCase() : ha;
    a.Fa = b;
    a.J = 0;
    a.sa = !1;
    a.F = !0;
    a.C = a.da ? $g(a.da) : $g(Yg);
    a.Z = a.da ? Wg(a.da) : Wg(Yg);
    a.C.onreadystatechange = y(a.jc, a);
    try {
      (a.Ea = !0), a.C.open(c, String(b), !0), (a.Ea = !1);
    } catch (h) {
      ih(a);
      return;
    }
    b = d || "";
    d = new Map(a.headers);
    if (e)
      if (Object.getPrototypeOf(e) === Object.prototype)
        for (var f in e) d.set(f, e[f]);
      else if (typeof e.keys === m && typeof e.get === m) {
        f = Cb(e.keys());
        for (var g = f.next(); !g.done; g = f.next())
          (g = g.value), d.set(g, e.get(g));
      } else throw Error("Unknown input type for opt_headers: " + String(e));
    e = Array.from(d.keys()).find(function (h) {
      return "content-type" == h.toLowerCase();
    });
    f = x.FormData && b instanceof x.FormData;
    !jc(eh, c) ||
      e ||
      f ||
      d.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    c = Cb(d);
    for (e = c.next(); !e.done; e = c.next())
      (d = Cb(e.value)),
        (e = d.next().value),
        (d = d.next().value),
        a.C.setRequestHeader(e, d);
    a.L && (a.C.responseType = a.L);
    "withCredentials" in a.C &&
      a.C.withCredentials !== a.K &&
      (a.C.withCredentials = a.K);
    try {
      jh(a),
        0 < a.R &&
          ((a.xb = kh(a.C)),
          a.xb
            ? ((a.C.timeout = a.R), (a.C.ontimeout = y(a.va, a)))
            : (a.Y = Og(a.va, a.R, a))),
        (a.T = !0),
        a.C.send(b),
        (a.T = !1);
    } catch (h) {
      ih(a);
    }
  }
  function kh(a) {
    return I && Ie(9) && typeof a.timeout === cb && void 0 !== a.ontimeout;
  }
  t.va = function () {
    "undefined" != typeof Rb &&
      this.C &&
      ((this.J = 8), M(this, "timeout"), this.abort(8));
  };
  function ih(a) {
    a.F = !1;
    a.C && ((a.G = !0), a.C.abort(), (a.G = !1));
    a.J = 5;
    lh(a);
    mh(a);
  }
  function lh(a) {
    a.sa || ((a.sa = !0), M(a, za), M(a, Pa));
  }
  t.abort = function (a) {
    this.C &&
      this.F &&
      ((this.F = !1),
      (this.G = !0),
      this.C.abort(),
      (this.G = !1),
      (this.J = a || 7),
      M(this, za),
      M(this, "abort"),
      mh(this));
  };
  t.X = function () {
    this.C &&
      (this.F && ((this.F = !1), (this.G = !0), this.C.abort(), (this.G = !1)),
      mh(this, !0));
    ch.O.X.call(this);
  };
  t.jc = function () {
    this.isDisposed() || (this.Ea || this.T || this.G ? nh(this) : this.Ad());
  };
  t.Ad = function () {
    nh(this);
  };
  function nh(a) {
    if (
      a.F &&
      "undefined" != typeof Rb &&
      (!a.Z[1] || 4 != (a.C ? a.C.readyState : 0) || 2 != oh(a))
    )
      if (a.T && 4 == (a.C ? a.C.readyState : 0)) Og(a.jc, 0, a);
      else if ((M(a, "readystatechange"), 4 == (a.C ? a.C.readyState : 0))) {
        a.F = !1;
        try {
          ph(a) ? (M(a, za), M(a, lb)) : ((a.J = 6), lh(a));
        } finally {
          mh(a);
        }
      }
  }
  function mh(a, b) {
    if (a.C) {
      jh(a);
      var c = a.C,
        d = a.Z[0] ? function () {} : null;
      a.C = null;
      a.Z = null;
      b || M(a, eb);
      try {
        c.onreadystatechange = d;
      } catch (e) {}
    }
  }
  function jh(a) {
    a.C && a.xb && (a.C.ontimeout = null);
    a.Y && (x.clearTimeout(a.Y), (a.Y = null));
  }
  t.isActive = function () {
    return !!this.C;
  };
  function ph(a) {
    var b = oh(a);
    a: switch (b) {
      case 200:
      case 201:
      case 202:
      case 204:
      case 206:
      case 304:
      case 1223:
        var c = !0;
        break a;
      default:
        c = !1;
    }
    if (!c) {
      if ((b = 0 === b))
        (a = String(a.Fa).match(ah)[1] || null),
          !a &&
            x.self &&
            x.self.location &&
            (a = x.self.location.protocol.slice(0, -1)),
          (b = !dh.test(a ? a.toLowerCase() : ""));
      c = b;
    }
    return c;
  }
  function oh(a) {
    try {
      return 2 < (a.C ? a.C.readyState : 0) ? a.C.status : -1;
    } catch (b) {
      return -1;
    }
  }
  function qh(a) {
    try {
      return a.C ? a.C.responseText : "";
    } catch (b) {
      return "";
    }
  }
  function rh(a, b) {
    this.C = a[x.Symbol.iterator]();
    this.D = b;
  }
  rh.prototype[Symbol.iterator] = function () {
    return this;
  };
  rh.prototype.next = function () {
    var a = this.C.next();
    return {
      value: a.done ? void 0 : this.D.call(void 0, a.value),
      done: a.done,
    };
  };
  function sh(a, b) {
    return new rh(a, b);
  }
  function th() {}
  th.prototype.next = function () {
    return uh;
  };
  var uh = { done: !0, value: void 0 };
  th.prototype.ta = function () {
    return this;
  };
  function vh(a) {
    if (a instanceof wh || a instanceof xh || a instanceof yh) return a;
    if (typeof a.next == m)
      return new wh(function () {
        return a;
      });
    if (typeof a[Symbol.iterator] == m)
      return new wh(function () {
        return a[Symbol.iterator]();
      });
    if (typeof a.ta == m)
      return new wh(function () {
        return a.ta();
      });
    throw Error("Not an iterator or iterable.");
  }
  function wh(a) {
    this.C = a;
  }
  wh.prototype.ta = function () {
    return new xh(this.C());
  };
  wh.prototype[Symbol.iterator] = function () {
    return new yh(this.C());
  };
  wh.prototype.D = function () {
    return new yh(this.C());
  };
  function xh(a) {
    this.C = a;
  }
  v(xh, th);
  xh.prototype.next = function () {
    return this.C.next();
  };
  xh.prototype[Symbol.iterator] = function () {
    return new yh(this.C);
  };
  xh.prototype.D = function () {
    return new yh(this.C);
  };
  function yh(a) {
    wh.call(this, function () {
      return a;
    });
    this.F = a;
  }
  v(yh, wh);
  yh.prototype.next = function () {
    return this.F.next();
  };
  function zh() {
    this.D = [];
    this.C = [];
  }
  function Ah(a) {
    0 === a.D.length && ((a.D = a.C), a.D.reverse(), (a.C = []));
    return a.D.pop();
  }
  zh.prototype.V = function () {
    return this.D.length + this.C.length;
  };
  zh.prototype.la = function () {
    return 0 === this.D.length && 0 === this.C.length;
  };
  zh.prototype.ca = function () {
    for (var a = [], b = this.D.length - 1; 0 <= b; --b) a.push(this.D[b]);
    var c = this.C.length;
    for (b = 0; b < c; ++b) a.push(this.C[b]);
    return a;
  };
  function Bh(a, b) {
    this.D = {};
    this.C = [];
    this.F = this.size = 0;
    var c = arguments.length;
    if (1 < c) {
      if (c % 2) throw Error("Uneven number of arguments");
      for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1]);
    } else if (a)
      if (a instanceof Bh)
        for (c = a.oa(), d = 0; d < c.length; d++) this.set(c[d], a.get(c[d]));
      else for (d in a) this.set(d, a[d]);
  }
  t = Bh.prototype;
  t.V = function () {
    return this.size;
  };
  t.ca = function () {
    Ch(this);
    for (var a = [], b = 0; b < this.C.length; b++) a.push(this.D[this.C[b]]);
    return a;
  };
  t.oa = function () {
    Ch(this);
    return this.C.concat();
  };
  t.has = function (a) {
    return Dh(this.D, a);
  };
  t.la = function () {
    return 0 == this.size;
  };
  function Eh(a, b) {
    return Dh(a.D, b)
      ? (delete a.D[b], --a.size, a.F++, a.C.length > 2 * a.size && Ch(a), !0)
      : !1;
  }
  function Ch(a) {
    if (a.size != a.C.length) {
      for (var b = 0, c = 0; b < a.C.length; ) {
        var d = a.C[b];
        Dh(a.D, d) && (a.C[c++] = d);
        b++;
      }
      a.C.length = c;
    }
    if (a.size != a.C.length) {
      var e = {};
      for (c = b = 0; b < a.C.length; )
        (d = a.C[b]), Dh(e, d) || ((a.C[c++] = d), (e[d] = 1)), b++;
      a.C.length = c;
    }
  }
  t.get = function (a, b) {
    return Dh(this.D, a) ? this.D[a] : b;
  };
  t.set = function (a, b) {
    Dh(this.D, a) || ((this.size += 1), this.C.push(a), this.F++);
    this.D[a] = b;
  };
  t.forEach = function (a, b) {
    for (var c = this.oa(), d = 0; d < c.length; d++) {
      var e = c[d],
        f = this.get(e);
      a.call(b, f, e, this);
    }
  };
  t.keys = function () {
    return vh(this.ta(!0)).D();
  };
  t.values = function () {
    return vh(this.ta(!1)).D();
  };
  t.entries = function () {
    var a = this;
    return sh(this.keys(), function (b) {
      return [b, a.get(b)];
    });
  };
  t.ta = function (a) {
    Ch(this);
    var b = 0,
      c = this.F,
      d = this,
      e = new th();
    e.next = function () {
      if (c != d.F)
        throw Error("The map has changed since the iterator was created");
      if (b >= d.C.length) return uh;
      var f = d.C[b++];
      return { value: a ? f : d.D[f], done: !1 };
    };
    return e;
  };
  function Dh(a, b) {
    return Object.prototype.hasOwnProperty.call(a, b);
  }
  function Fh(a) {
    if (a.ca && typeof a.ca == m) return a.ca();
    if (
      ("undefined" !== typeof Map && a instanceof Map) ||
      ("undefined" !== typeof Set && a instanceof Set)
    )
      return Array.from(a.values());
    if (typeof a === r) return a.split("");
    if (Tb(a)) {
      for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
      return b;
    }
    return rc(a);
  }
  function Gh(a) {
    if (a.oa && typeof a.oa == m) return a.oa();
    if (!a.ca || typeof a.ca != m) {
      if ("undefined" !== typeof Map && a instanceof Map)
        return Array.from(a.keys());
      if (!("undefined" !== typeof Set && a instanceof Set)) {
        if (Tb(a) || typeof a === r) {
          var b = [];
          a = a.length;
          for (var c = 0; c < a; c++) b.push(c);
          return b;
        }
        return sc(a);
      }
    }
  }
  function Hh(a, b, c) {
    if (a.forEach && typeof a.forEach == m) a.forEach(b, c);
    else if (Tb(a) || typeof a === r) Array.prototype.forEach.call(a, b, c);
    else
      for (var d = Gh(a), e = Fh(a), f = e.length, g = 0; g < f; g++)
        b.call(c, e[g], d && d[g], a);
  }
  function Ih() {
    this.C = new Bh();
    this.size = 0;
  }
  function Jh(a) {
    var b = typeof a;
    return (b == q && a) || b == m
      ? "o" +
          ((Object.prototype.hasOwnProperty.call(a, Vb) && a[Vb]) ||
            (a[Vb] = ++Wb))
      : b.slice(0, 1) + a;
  }
  t = Ih.prototype;
  t.V = function () {
    return this.C.size;
  };
  t.add = function (a) {
    this.C.set(Jh(a), a);
    this.size = this.C.size;
  };
  function Kh(a, b) {
    b = Jh(b);
    b = Eh(a.C, b);
    a.size = a.C.size;
    return b;
  }
  t.la = function () {
    return 0 === this.C.size;
  };
  t.has = function (a) {
    a = Jh(a);
    return this.C.has(a);
  };
  t.ca = function () {
    return this.C.ca();
  };
  t.values = function () {
    return this.C.values();
  };
  t.ta = function () {
    return this.C.ta(!1);
  };
  Ih.prototype[Symbol.iterator] = function () {
    return this.values();
  };
  function Lh(a, b) {
    uf.call(this);
    this.L = a || 0;
    this.F = b || 10;
    if (this.L > this.F)
      throw Error("[goog.structs.Pool] Min can not be greater than max");
    this.C = new zh();
    this.D = new Ih();
    this.delay = 0;
    this.J = null;
    this.Ua();
  }
  A(Lh, uf);
  t = Lh.prototype;
  t.ab = function () {
    var a = Date.now();
    if (!(null != this.J && a - this.J < this.delay)) {
      for (var b; 0 < this.C.V() && ((b = Ah(this.C)), !this.Db(b)); )
        this.Ua();
      !b && this.V() < this.F && (b = this.Ab());
      b && ((this.J = a), this.D.add(b));
      return b;
    }
  };
  t.Ja = function (a) {
    Kh(this.D, a);
    this.Db(a) && this.V() < this.F ? this.C.C.push(a) : Mh(a);
  };
  t.Ua = function () {
    for (var a = this.C; this.V() < this.L; ) {
      var b = this.Ab();
      a.C.push(b);
    }
    for (; this.V() > this.F && 0 < this.C.V(); ) Mh(Ah(a));
  };
  t.Ab = function () {
    return {};
  };
  function Mh(a) {
    if (typeof a.wa == m) a.wa();
    else for (var b in a) a[b] = null;
  }
  t.Db = function (a) {
    return typeof a.hd == m ? a.hd() : !0;
  };
  t.V = function () {
    return this.C.V() + this.D.V();
  };
  t.la = function () {
    return this.C.la() && this.D.la();
  };
  t.X = function () {
    Lh.O.X.call(this);
    if (0 < this.D.V()) throw Error("[goog.structs.Pool] Objects not released");
    delete this.D;
    for (var a = this.C; !a.la(); ) Mh(Ah(a));
    delete this.C;
  };
  function Nh(a, b) {
    this.C = a;
    this.D = b;
  }
  function Oh(a) {
    this.C = [];
    if (a)
      a: {
        if (a instanceof Oh) {
          var b = a.oa();
          a = a.ca();
          if (0 >= this.V()) {
            for (var c = this.C, d = 0; d < b.length; d++)
              c.push(new Nh(b[d], a[d]));
            break a;
          }
        } else (b = sc(a)), (a = rc(a));
        for (c = 0; c < b.length; c++) this.insert(b[c], a[c]);
      }
  }
  t = Oh.prototype;
  t.insert = function (a, b) {
    var c = this.C;
    c.push(new Nh(a, b));
    a = c.length - 1;
    b = this.C;
    for (c = b[a]; 0 < a; ) {
      var d = (a - 1) >> 1;
      if (b[d].C > c.C) (b[a] = b[d]), (a = d);
      else break;
    }
    b[a] = c;
  };
  t.ca = function () {
    for (var a = this.C, b = [], c = a.length, d = 0; d < c; d++)
      b.push(a[d].D);
    return b;
  };
  t.oa = function () {
    for (var a = this.C, b = [], c = a.length, d = 0; d < c; d++)
      b.push(a[d].C);
    return b;
  };
  t.V = function () {
    return this.C.length;
  };
  t.la = function () {
    return 0 === this.C.length;
  };
  function Ph() {
    Oh.apply(this, arguments);
  }
  v(Ph, Oh);
  function Qh(a, b) {
    this.K = void 0;
    this.G = new Ph();
    Lh.call(this, a, b);
  }
  A(Qh, Lh);
  t = Qh.prototype;
  t.ab = function (a, b) {
    if (!a)
      return (
        (a = Qh.O.ab.call(this)) &&
          this.delay &&
          (this.K = x.setTimeout(y(this.bb, this), this.delay)),
        a
      );
    this.G.insert(void 0 !== b ? b : 100, a);
    this.bb();
  };
  t.bb = function () {
    for (var a = this.G; 0 < a.V(); ) {
      var b = this.ab();
      if (b) {
        var c = a,
          d = c.C,
          e = d.length;
        var f = d[0];
        if (0 >= e) f = void 0;
        else {
          if (1 == e) d.length = 0;
          else {
            d[0] = d.pop();
            d = 0;
            c = c.C;
            e = c.length;
            for (var g = c[d]; d < e >> 1; ) {
              var h = 2 * d + 1,
                k = 2 * d + 2;
              h = k < e && c[k].C < c[h].C ? k : h;
              if (c[h].C > g.C) break;
              c[d] = c[h];
              d = h;
            }
            c[d] = g;
          }
          f = f.D;
        }
        f.apply(this, [b]);
      } else break;
    }
  };
  t.Ja = function (a) {
    Qh.O.Ja.call(this, a);
    this.bb();
  };
  t.Ua = function () {
    Qh.O.Ua.call(this);
    this.bb();
  };
  t.X = function () {
    Qh.O.X.call(this);
    x.clearTimeout(this.K);
    this.G.C.length = 0;
    this.G = null;
  };
  function Rh(a, b, c, d) {
    this.R = a;
    this.T = !!d;
    Qh.call(this, b, c);
  }
  A(Rh, Qh);
  Rh.prototype.Ab = function () {
    var a = new ch(),
      b = this.R;
    b &&
      b.forEach(function (c, d) {
        a.headers.set(d, c);
      });
    this.T && (a.K = !0);
    return a;
  };
  Rh.prototype.Db = function (a) {
    return !a.isDisposed() && !a.isActive();
  };
  function Sh(a, b, c, d, e, f) {
    cg.call(this);
    this.G = void 0 !== a ? a : 1;
    this.J = void 0 !== e ? Math.max(0, e) : 0;
    this.K = !!f;
    this.D = new Rh(b, c, d, f);
    this.C = new Bh();
    this.F = new Yf(this);
  }
  A(Sh, cg);
  var Th = [eb, za, lb, Pa, "abort", "timeout"];
  function Uh(a, b, c, d, e, f) {
    if (a.C.get(b)) throw Error("[goog.net.XhrManager] ID in use");
    c = new Vh(c, y(a.R, a, b), d, e, f, a.G, a.K);
    a.C.set(b, c);
    b = y(a.L, a, b);
    a.D.ab(b, null);
  }
  Sh.prototype.abort = function (a, b) {
    var c = this.C.get(a);
    if (c) {
      var d = c.gb;
      c.Qb = !0;
      b &&
        (d &&
          (ag(this.F, d, Th, c.Hb),
          Mf(
            d,
            eb,
            function () {
              var e = this.D;
              Kh(e.D, d) && e.Ja(d);
            },
            !1,
            this
          )),
        Eh(this.C, a));
      d && d.abort();
    }
  };
  Sh.prototype.L = function (a, b) {
    var c = this.C.get(a);
    c && !c.gb
      ? ($f(this.F, b, Th, c.Hb),
        (b.R = Math.max(0, this.J)),
        (b.L = c.ec()),
        (b.K = c.fc()),
        (c.gb = b),
        M(this, new Wh(eb, this, a, b)),
        Xh(this, a, b),
        c.Qb && b.abort())
      : ((a = this.D), Kh(a.D, b) && a.Ja(b));
  };
  Sh.prototype.R = function (a, b) {
    var c = b.target;
    switch (b.type) {
      case eb:
        Xh(this, a, c);
        break;
      case za:
        a: {
          var d = this.C.get(a);
          if (7 == c.J || ph(c) || d.Va > d.lb)
            if ((M(this, new Wh(za, this, a, c)), d && ((d.Wb = !0), d.Vb))) {
              a = d.Vb.call(c, b);
              break a;
            }
          a = null;
        }
        return a;
      case lb:
        M(this, new Wh(lb, this, a, c));
        break;
      case "timeout":
      case Pa:
        b = this.C.get(a);
        b.Va > b.lb && M(this, new Wh(Pa, this, a, c));
        break;
      case "abort":
        M(this, new Wh("abort", this, a, c));
    }
    return null;
  };
  function Xh(a, b, c) {
    var d = a.C.get(b);
    !d || d.Wb || d.Va > d.lb
      ? (d && (ag(a.F, c, Th, d.Hb), Eh(a.C, b)),
        (a = a.D),
        Kh(a.D, c) && a.Ja(c))
      : (d.Va++, hh(c, d.getUrl(), d.yd, d.Cb(), d.Cc));
  }
  Sh.prototype.X = function () {
    Sh.O.X.call(this);
    this.D.wa();
    this.D = null;
    this.F.wa();
    this.F = null;
    var a = this.C;
    a.D = {};
    a.C.length = 0;
    a.size = 0;
    a.F = 0;
    this.C = null;
  };
  function Wh(a, b, c, d) {
    vf.call(this, a, b);
    this.id = c;
    this.gb = d;
  }
  A(Wh, vf);
  function Vh(a, b, c, d, e, f, g) {
    this.C = a;
    this.yd = c || ha;
    this.F = d;
    this.Cc = null;
    this.lb = void 0 !== f ? f : 1;
    this.Va = 0;
    this.Qb = this.Wb = !1;
    this.Hb = b;
    this.Vb = e;
    this.D = !!g;
    this.gb = null;
  }
  Vh.prototype.getUrl = function () {
    return this.C;
  };
  Vh.prototype.Cb = function () {
    return this.F;
  };
  Vh.prototype.fc = function () {
    return this.D;
  };
  Vh.prototype.ec = function () {
    return "";
  };
  function Yh(a, b, c, d, e) {
    this.D = a;
    this.G = b;
    this.C = c || null;
    this.data = d || null;
    if (e) {
      if (
        ((this.F = e),
        "displayModeSnippet" != e && e != La && e != Ma && e != Na)
      )
        throw "bad display mode: " + e;
    } else this.F = Na;
    this.K = !1;
  }
  Yh.prototype.J = function () {
    return this.D;
  };
  function Zh(a) {
    this.G = !0;
    this.N = a;
    this.C = null;
  }
  function N(a, b) {
    return document.getElementById(a.N.D + "_" + b);
  }
  function $h(a, b) {
    a = N(a, b);
    if (!a) throw "did not find element for id " + b;
    return a;
  }
  Zh.prototype.F = function () {
    return this.N.data;
  };
  Zh.prototype.D = function () {
    var a = {};
    a.type = this.C.Qa();
    a.instanceId = this.N.D;
    a.sectionId = this.N.G;
    a.actionUrl = O.Tb;
    a.quickEditUrl =
      O.Zb +
      "&widgetType=" +
      this.C.Qa() +
      "&widgetId=" +
      this.N.D +
      "&sectionId=" +
      this.N.G +
      aa +
      O.vc;
    return a;
  };
  Zh.prototype.Da = function (a, b, c, d) {
    b = b || {};
    window.__wavt && (b.xssi_token = window.__wavt);
    O.Da(a, b, this.N.D, this.C.Qa(), c, d);
  };
  function ai(a) {
    var b = -1;
    try {
      b = a.status;
    } catch (c) {}
    return b;
  }
  function O() {}
  O.Bc = function (a, b) {
    O.Aa = {};
    O.Zb = a;
    O.Tb = b;
    O.Ka = {};
    O.hb = new Sh();
    O.hc = 0;
    O.Eb = 0;
    L(O.hb, eb, function () {
      O.Eb++;
    });
    L(O.hb, za, function () {
      O.Eb--;
    });
  };
  O.Sc = function (a, b) {
    O.lc = a;
    O.kc = b;
  };
  O.ad = function () {
    var a = O.uc();
    document.body.appendChild(a);
  };
  O.Uc = function (a) {
    O.ad();
    if (window.parent == window) {
      var b = "Preview";
      a && (b = a);
      a = O.tc(b);
      document.body.appendChild(a[0]);
      document.body.appendChild(a[1]);
    }
  };
  O.vc = "editWidget";
  O.Tc = function (a) {
    O.Ld = a;
  };
  O.Kb = function () {
    return O.Ld;
  };
  O.Rc = function (a) {
    O.Ka = a;
  };
  O.xc = function () {
    var a = {},
      b;
    for (b in O.Ka) {
      var c = O.Ka[b];
      a[c.name] = c.data;
    }
    c = {};
    for (b in O.Aa) c[b] = O.Aa[b].H.N.data;
    a.widgets = c;
    return a;
  };
  O.Pb = function (a, b) {
    var c = new Zh(b);
    a = new window[a](c);
    c.C = a;
    O.Aa[b.D] = a;
    O.Jb(a);
    return a;
  };
  O.Mc = function (a, b) {
    a = O.Pb(a, b);
    a.H.N.K = !0;
    return a;
  };
  O.Jb = function (a) {
    var b = a.H;
    b.N.F != Na && (b.N.F == La && a.ia(), (a.H.G = !1));
  };
  O.kb = function (a) {
    return O.Aa ? O.Aa[a] : null;
  };
  O.Kc = function (a, b, c, d, e) {
    var f = "";
    d && (f = "&widgetId=" + d);
    a = O.Zb + aa + a + "&sectionId=" + b + "&widgetType=" + c + f;
    if (window.name == e)
      return window.location.replace(a), window.focus(), window;
    e = window.open(
      a,
      e,
      "width=570,height=600,left=75,top=20,resizable=yes,scrollbars=yes"
    );
    e.focus();
    return e;
  };
  O.Jc = function (a) {
    var b = a.getAttribute("id"),
      c = a.parentNode.getAttribute("id");
    a = a.getAttribute("widgetType");
    O.kc && O.kc(c, a, b);
    return !1;
  };
  O.Lc = function (a) {
    a = a.parentNode.getAttribute("id");
    O.lc && O.lc(a);
    return !1;
  };
  O.Da = function (a, b, c, d, e, f) {
    O.Pc(a, b, c, d, e, f);
  };
  O.Pc = function (a, b, c, d, e, f) {
    function g() {
      n(this.C) && window.eval(qh(this));
    }
    var h = O.Tb;
    a = [
      "action=" + encodeURIComponent(a),
      "widgetId=" + encodeURIComponent(c),
      "widgetType=" + encodeURIComponent(d),
      "responseType=js",
    ];
    for (var k in b)
      if (typeof b[k] == q)
        for (c = b[k], d = 0; d < c.length; ++d)
          a.push(encodeURIComponent(k) + "=" + encodeURIComponent(c[d]));
      else a.push(encodeURIComponent(k) + "=" + encodeURIComponent(b[k]));
    var n = e || bi();
    f == ha
      ? ((h = 0 <= h.indexOf("?") ? h + "&" : h + "?"),
        Uh(O.hb, "" + O.hc++, h + a.join("&"), ha, void 0, g))
      : Uh(O.hb, "" + O.hc++, h, "POST", a.join("&"), g);
  };
  O.ib = function (a, b) {
    0 == O.Eb
      ? a.setTimeout(function () {
          a.close();
        }, b)
      : a.setTimeout(function () {
          O.ib(a, b);
        }, 200);
  };
  O.Ec = function (a, b) {
    a && (O.ib(a, 100), O.bd(a, b));
  };
  O.bd = function (a, b) {
    if (a) {
      var c = a.document.getElementById(jb);
      c && (c = c.innerHTML);
      c &&
        a &&
        a.opener.parent &&
        a.opener.parent.editor &&
        a.opener.parent.editor.SetSaveMessage(c, b);
    }
  };
  O.ka = function (a, b, c) {
    a = O.Aa[a];
    if (null != c.errors) {
      var d = window;
      O.wb(d, c.errors);
      a && a.Ba ? a.Ba(b, c, d) : O.Ba(c, d);
    } else a.ka(b, c);
  };
  O.Ba = function (a, b) {
    a = a["error-details"];
    for (var c in a) {
      var d = a[c],
        e;
      (e = b.document) || (e = document);
      if ((e = e.getElementById("errormessage_" + c)))
        Pd(e, ee(d, { Ha: "0567fa1b-4186-4a3e-a4ef-72037eeeac65" })),
          (e.className = "errorbox-bad errormsg");
    }
  };
  function ci(a, b) {
    O.wb(a.J, b[ib]);
    O.wc(a.N.D, function (c) {
      window.opener._WidgetManager._OnWidgetConfigured(c, b);
    });
  }
  O.Hc = function (a, b) {
    window.parent && window.parent.editor && b
      ? O.Ob(a, b)
      : window.location.replace(window.location.href);
  };
  O.Ob = function (a, b) {
    var c = O.kb(a);
    c.H.N.data = b.data;
    a = document.getElementById(a);
    jf(a);
    di(a, c);
  };
  O.Ac = function (a, b, c) {
    null != c.errors && (O.wb(window, c.errors), O.Ba(c, window));
  };
  O.Ic = function (a) {
    var b = O.kb(a);
    b &&
      (b.H.N.F == Ma
        ? top.editor.HandleDeleteWidget(b.H.N.C)
        : ((b = b.H.N.C), b.parentNode.removeChild(b)),
      delete O.Aa[a]);
  };
  O.wc = function (a, b) {
    if (O.Lb(window)) {
      var c = window.opener;
      b || (b = c._WidgetManager._OnWidgetConfigured);
      b(a);
      c._WidgetManager
        ? c._WidgetManager._KillPopupDelay(window, a)
        : O.ib(window, 100);
    } else
      (a = O.Kb() + "?widgetId=" + a),
        (a += "&func=" + encodeURIComponent("_OnWidgetConfigured")),
        window.location.replace(a);
  };
  O.Lb = function (a) {
    var b = !1;
    try {
      if (a.opener) {
        var c = "X" + a.opener.document.domain;
        c && "X" != c && (b = !0);
      }
    } catch (d) {}
    return b;
  };
  O.Qc = "status-msg-yellow-on-white";
  O.wb = function (a, b) {
    a || (a = self);
    var c = a.document.getElementById(jb);
    c && (c.textContent = b);
    (a = a.document.getElementById(ib)) && pe(a, O.Qc);
  };
  O.Pa = function (a, b) {
    if (ue(a, b)) return a;
    if (a)
      for (var c = a.childNodes.length, d = 0; d < c; d++) {
        var e = O.Pa(a.childNodes.item(d), b);
        if (e) return e;
      }
    return null;
  };
  O.uc = function () {
    var a = window.document.createElement(l);
    a.className = "blogger-clickTrap singleton-element";
    a.style.position = "fixed";
    a.style.top = "0";
    a.style.left = "0";
    a.style.width = "100%";
    a.style.height = "100%";
    6 >= yd() && (a.style.height = "expression(this.parentNode.clientHeight)");
    a.style.zIndex = "1000";
    a.style.cursor = "default";
    a.onclick = O.ub;
    a.onmousedown = O.ub;
    a.onmouseup = O.ub;
    a.style.background = "white";
    a.style.filter = "alpha(opacity=1)";
    a.style.opacity = ".01";
    a.textContent = "\u00a0";
    return a;
  };
  O.tc = function (a) {
    var b = window.document,
      c = O.Ib(b, a);
    a = O.Ib(b, a);
    c.style.backgroundColor = "#000";
    c.style.border = "1px solid #aaa";
    I &&
      (c.style.filter =
        ' progid:DXImageTransform.Microsoft.Matrix(sizingMethod="auto expand", M11=0.70710678, M12=0.70710678, M21=-0.70710678, M22=0.70710678) alpha(opacity=50)');
    c.style.opacity = ".5";
    a.style.border = "1px solid transparent";
    c.style.zIndex = 1200;
    a.style.zIndex = 1200;
    return [c, a];
  };
  O.Ib = function (a, b) {
    a = a.createElement(l);
    a.style.position = "absolute";
    a.style.top = "75px";
    a.style.left = "-225px";
    a.style.width = "600px";
    a.style.height = "28px";
    a.style.margin = "0";
    a.style.padding = "10px";
    a.style.fontSize = "24px";
    a.style.textAlign = "center";
    a.style.color = "#fff";
    a.style.fontFamily = '"trebuchet ms",verdana,arial,sans-serif';
    I &&
      ((a.style.top = "-140px"),
      (a.style.left = "-140px"),
      (a.style.filter =
        ' progid:DXImageTransform.Microsoft.Matrix(sizingMethod="auto expand", M11=0.70710678, M12=0.70710678, M21=-0.70710678, M22=0.70710678)'));
    a.style.MozTransform = gb;
    a.style.MozTransformOrigin = "50% 0";
    a.style.WebkitTransform = gb;
    a.style.WebkitTransformOrigin = "50% 0";
    a.textContent = b;
    a.className = "singleton-element";
    return a;
  };
  O.ub = function (a) {
    a || (a = window.event);
    a && ((a.cancelBubble = !0), a.stopPropagation && a.stopPropagation());
    return !1;
  };
  function ei() {
    this.C = [];
    for (var a = 0; a < O.Ka.length; ++a) this.C[this.C.length] = O.Ka[a];
  }
  function fi(a, b) {
    null == b && (b = "");
    for (var c = a.C.length - 1; 0 <= c; --c)
      if (a.C[c].name == b) return a.C[c].data;
    return null;
  }
  function gi(a, b) {
    var c = fi(a, b);
    if (null !== c) return c;
    var d = b.split(".");
    if (1 == d.length) return (c = fi(a, "")), c[b];
    c = fi(a, d[0]);
    b = 0;
    c ? (b = 1) : (c = fi(a, ""));
    for (a = b; a < d.length; a++) {
      if (null == c) return null;
      c = c[d[a]];
    }
    return c;
  }
  function Q(a, b) {
    this.L = a;
    this.H = b;
  }
  t = Q.prototype;
  t.Qa = function () {
    return this.L;
  };
  t.yc = function () {
    return this.H;
  };
  t.ka = function (a, b) {
    "configure" == a && ci(this.H, b);
  };
  t.Ba = function (a, b, c) {
    O.Ba(b, c);
  };
  t.ia = function () {};
  z("_WidgetManager", O);
  O._SetOpenWidgetDialogs = O.Sc;
  O._Init = O.Bc;
  O._SetWidgetRefreshUrl = O.Tc;
  O._GetWidgetRefreshUrl = O.Kb;
  O._DisplayWidget = O.Jb;
  O._GetWidget = O.kb;
  O._HandleControllerResult = O.ka;
  O._HandlePageActionResult = O.Ac;
  O._IsOpenerReachable = O.Lb;
  O._SetDataContext = O.Rc;
  O._SetupPreview = O.Uc;
  O._RegisterWidget = O.Pb;
  O._RegisterNewWidget = O.Mc;
  O._PopupPaneFromParams = O.Kc;
  O._PopupConfig = O.Jc;
  O._PopupToolbox = O.Lc;
  O._KillPopupDelay = O.Ec;
  O._OnWidgetConfigured = O.Hc;
  O._OnWidgetConfiguredWithData = O.Ob;
  O._OnWidgetDeleted = O.Ic;
  z("_WidgetInfo", Yh);
  Yh.prototype._getInstanceId = Yh.prototype.J;
  Q.prototype._GetHelper = Q.prototype.yc;
  Zh.prototype._GetData = Zh.prototype.F;
  Zh.prototype._GenerateWidgetMetadata = Zh.prototype.D;
  O._GetAllData = O.xc;
  z("widget_module_provide", function (a, b, c) {
    var d = Pg.Za(),
      e = d.C,
      f = d.J;
    e[a] || (e[a] = {});
    if (c) e[a][b] = c;
    else if (f[a]) {
      for (b = 0; b < f[a].length; ++b) (0, f[a][b][1])(e[a][f[a][b][0]]);
      delete f[a];
      delete d.F[a];
    }
  });
  function hi(a) {
    Q.call(this, "AdSense", a);
    this.H = a;
  }
  v(hi, Q);
  z("_AdSenseView", hi);
  function ii(a) {
    Q.call(this, "BlogArchive", a);
    this.C = a.N;
  }
  A(ii, Q);
  var ji = "&#9658;&nbsp;";
  t = ii.prototype;
  t.ka = function (a, b) {
    if ("configure" == a) ci(this.H, b);
    else if ("getTitles" == a) {
      a: {
        a = b.path;
        var c = this.C.C.getElementsByTagName("A");
        for (e in c) {
          var d = c[e];
          if (d.href == a) {
            var e = qf(d, "li", "archivedate");
            break a;
          }
        }
        e = void 0;
      }
      a = K("posts", e);
      (c = qf(e, l, wa)) && cf(c, { style: "", "data-height": "" });
      jf(a);
      for (c = 0; c < b.posts.length; c++) {
        d = b.posts[c];
        var f = document.createElement("li");
        Pd(
          f,
          ee("<a href=" + d.url + ">" + d.title + "</a>", {
            Ha: "057788eb-9301-40b2-bfcf-360831db5d31",
          })
        );
        a.appendChild(f);
      }
      ki(this, e);
      li(this, e);
    } else ii.O.ka.call(this, a, b);
  };
  t.ia = function () {
    if (N(this.H, "ArchiveList")) {
      var a = bf(document, "a", qb, this.C.C);
      1 > a.length && (a = bf(document, "li", qb, this.C.C));
      if (0 < a.length && a[0].currentStyle)
        var b = a[0].parentNode.currentStyle.color;
      for (var c = 0; c < a.length; c++) {
        var d = a[c];
        0 < bf(document, l, wa, d).length
          ? ((d.onclick = this.Vc.bind(this)), ki(this, d))
          : (d.onclick = this.Wc.bind(this));
        b && (d.style.color = b);
      }
      if ((a = N(this.H, "ArchiveMenu"))) {
        for (b = 1; b < a.options.length; b++)
          if (
            ((c = a.options[b].value),
            c == window.location.href || null != window.location.href.match(c))
          ) {
            a.selectedIndex = b;
            break;
          }
        a.onchange = this.zc.bind(this);
      } else
        for (a = bf(document, l, Oa, this.C.C), b = 0; b < a.length; b++)
          (c = a[b]),
            c.addEventListener(ua, this.Zc.bind(this), !1),
            c.addEventListener(ua, this.Oc.bind(this), !1);
      "rtl" == this.H.N.data.languageDirection && (ji = "&#9668;&nbsp;");
    }
  };
  t.zc = function () {
    var a = N(this.H, "ArchiveMenu");
    a && "" != a.value && (window.location.href = a.value);
  };
  t.Wc = function (a) {
    a = a || window.event;
    var b = a.currentTarget || a.srcElement;
    b && !ue(b, qb) && (b = b.parentNode);
    a = O.Pa(b, "zippy");
    b = b.parentNode;
    if (ue(b, Qa))
      return te(b, Qa, va), Pd(a, Zd(de, ji)), re(a, "toggle-open"), !1;
    te(b, va, Qa);
    Pd(a, Zd(de, "&#9660;&nbsp;"));
    pe(a, "toggle-open");
    mi(this, b);
    return !1;
  };
  t.Zc = function (a) {
    a = a || window.event;
    a = a.currentTarget || a.srcElement;
    (a = ue(a, Oa) ? a : qf(a, l, Oa)) &&
      (a = K("menu", a)) &&
      (ue(a, "open") ? re(a, "open") : pe(a, "open"));
  };
  t.Oc = function (a) {
    a = a || window.event;
    var b = a.currentTarget || a.srcElement;
    if ((b = ue(b, "ripple") ? b : qf(b, l, "ripple"))) {
      var c = K("splash", b);
      if (!c) {
        c = document.createElement("span");
        pe(c, "splash");
        var d = document.createElement(l);
        pe(d, "splash-wrapper");
        d.appendChild(c);
        b.insertBefore(d, b.firstChild);
      }
      re(c, "animate");
      d = b.offsetWidth;
      var e = getComputedStyle(b);
      d += parseInt(e.marginLeft) + parseInt(e.marginRight);
      d = Math.max(d, ni(b));
      cf(c, {
        style:
          "height: " +
          d +
          "px; width: " +
          d +
          "px; left: " +
          (a.pageX - b.offsetLeft - d / 2) +
          "px; top: " +
          (a.pageY - b.offsetTop - d / 2) +
          "px;",
      });
      pe(c, "animate");
    }
  };
  t.Vc = function (a) {
    a = a || window.event;
    if (
      !a.currentTarget ||
      a.currentTarget == a.srcElement ||
      "A" != a.srcElement.tagName
    ) {
      var b = a.currentTarget || a.srcElement;
      b && !ue(b, qb) && (b = b.parentNode);
      a.stopPropagation();
      a = ue(b, "archivedate") ? b : b.parentNode;
      ue(a, Qa)
        ? (oi(this, a), te(a, Qa, va))
        : (mi(this, a), li(this, a), te(a, va, Qa));
    }
  };
  function mi(a, b) {
    var c = b.getElementsByTagName("UL");
    0 < c.length && !ue(c[0], "posts")
      ? (c = !1)
      : ((c = O.Pa(b, "post-count")),
        (c = parseInt(c.innerHTML.match(/\d+/), 10)),
        (c = b.getElementsByTagName("LI").length < c));
    if (c) {
      var d = K(wa, b);
      c = K("posts", b);
      c ||
        ((c = document.createElement("UL")),
        d ? d.appendChild(c) : b.appendChild(c),
        pe(c, "posts"));
      d && cf(d, { style: "", "data-height": "" });
      (d = qf(b, l, wa)) && cf(d, { style: "", "data-height": "" });
      d = document.createElement("LI");
      Pd(d, de.C(a.H.N.data.loadingMessage || "Loading..."));
      c.appendChild(d);
      a.H.Da("getTitles", { path: O.Pa(b, "post-count-link").href }, null, ha);
    }
  }
  function li(a, b) {
    var c = K(wa, b);
    c.getAttribute(Ia) || ki(a, b);
    var d = (a = c.getAttribute(Ia) || ni(c)) ? a + "px" : p;
    window.setTimeout(function () {
      cf(c, { style: "max-height: " + d + ";" });
    }, 10);
  }
  function oi(a, b) {
    var c = K(wa, b);
    c.getAttribute(Ia) || ki(a, b);
    window.setTimeout(function () {
      cf(c, { style: $a });
    }, 10);
  }
  function ki(a, b) {
    var c = K(wa, b);
    cf(c, { style: "max-height: none;" });
    for (var d = 0, e = bf(document, l, wa, c), f = 0; f < e.length; f++) {
      var g = e[f],
        h = qf(g, "li", qb);
      if (ue(h, va)) {
        var k = g.getAttribute(Ia);
        k || (ki(a, h), (k = g.getAttribute(Ia)));
        d += parseInt(k);
      }
    }
    a = d + ni(c);
    c.setAttribute(Ia, a);
    c.setAttribute(kb, "max-height: " + a + "px;");
    ue(b, va) && c.setAttribute(kb, $a);
  }
  function ni(a) {
    var b = a.offsetHeight;
    a = getComputedStyle(a);
    return (b += parseInt(a.marginTop) + parseInt(a.marginBottom));
  }
  z("_BlogArchiveView", ii);
  function bi() {
    return function (a) {
      return 500 <= ai(a)
        ? (a.responseText.length
            ? (document.body.innerHTML = a.responseText)
            : window.alert(LayoutsMessages.SERVER_ERROR),
          !1)
        : !0;
    };
  }
  function di(a, b) {
    var c = O,
      d = a.ownerDocument;
    b = b._GetHelper();
    var e = b._GetData(),
      f = c._GetAllData();
    a = pi(d, a, l, "widget-wrap1");
    a = pi(d, a, l, "widget-wrap2");
    a = pi(d, a, l, "widget-wrap3");
    var g = pi(d, a, l, "widget-content");
    if ((a = e.version && 1 < e.version))
      (g.className += " visibility"),
        pi(
          d,
          g,
          l,
          "layout-widget-state " + (e.isVisible ? rb : "not-visible")
        ).setAttribute(pb, e.visibilityTooltipMessage);
    var h = pi(d, g, l, "layout-title");
    if (e[Za]) {
      var k = pi(d, g, l, Ya);
      k.appendChild(d.createTextNode(e[Za]));
      k.setAttribute(pb, e[Ya]);
    }
    h.appendChild(d.createTextNode(e["layout-title"]));
    e = pi(d, g, "a", "editlink");
    var n = b._GenerateWidgetMetadata();
    e.target = "chooseWidget";
    e.onclick = function () {
      return c._PopupConfig(d.getElementById(n.instanceId));
    };
    a && (e.className += " icon");
    e.appendChild(d.createTextNode(f.messages.edit || "Edit"));
  }
  function pi(a, b, c, d) {
    a = a.createElement(c);
    a.className = d;
    b.appendChild(a);
    return a;
  }
  function qi(a) {
    Q.call(this, qi.ea, a);
  }
  A(qi, Q);
  qi.ea = "Attribution";
  z("_AttributionView", qi);
  xd();
  wd();
  vd();
  var ri = {},
    si = null;
  var ti = "undefined" !== typeof Uint8Array;
  var ui =
    typeof Symbol === m && "symbol" === typeof Symbol()
      ? Symbol(void 0)
      : void 0;
  function vi(a, b) {
    Object.isFrozen(a) ||
      (ui
        ? (a[ui] |= b)
        : void 0 !== a.za
        ? (a.za |= b)
        : Object.defineProperties(a, {
            za: { value: b, configurable: !0, writable: !0, enumerable: !1 },
          }));
  }
  function wi(a) {
    var b;
    ui ? (b = a[ui]) : (b = a.za);
    return null == b ? 0 : b;
  }
  function xi(a) {
    vi(a, 1);
    return a;
  }
  function yi(a) {
    vi(a, 17);
    return a;
  }
  var zi = {};
  function Ai(a) {
    return (
      null !== a &&
      typeof a === q &&
      !Array.isArray(a) &&
      a.constructor === Object
    );
  }
  var Bi = Object.freeze(xi([]));
  function Ci(a, b, c, d) {
    if (null != a) {
      if (Array.isArray(a)) a = Di(a, b, c, void 0 !== d);
      else if (Ai(a)) {
        var e = {},
          f;
        for (f in a) e[f] = Ci(a[f], b, c, d);
        a = e;
      } else a = b(a, d);
      return a;
    }
  }
  function Di(a, b, c, d) {
    d = d ? !!(wi(a) & 16) : void 0;
    var e = Array.prototype.slice.call(a);
    c(a, e);
    for (a = 0; a < e.length; a++) e[a] = Ci(e[a], b, c, d);
    return e;
  }
  function Ei(a) {
    if (a.wd === zi) a = a.toJSON();
    else
      a: switch (typeof a) {
        case cb:
          a = isFinite(a) ? a : String(a);
          break a;
        case q:
          if (
            a &&
            !Array.isArray(a) &&
            ti &&
            null != a &&
            a instanceof Uint8Array
          ) {
            var b;
            void 0 === b && (b = 0);
            if (!si) {
              si = {};
              for (
                var c =
                    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
                      ""
                    ),
                  d = ["+/=", "+/", "-_=", "-_.", "-_"],
                  e = 0;
                5 > e;
                e++
              ) {
                var f = c.concat(d[e].split(""));
                ri[e] = f;
                for (var g = 0; g < f.length; g++) {
                  var h = f[g];
                  void 0 === si[h] && (si[h] = g);
                }
              }
            }
            b = ri[b];
            c = Array(Math.floor(a.length / 3));
            d = b[64] || "";
            for (e = f = 0; f < a.length - 2; f += 3) {
              var k = a[f],
                n = a[f + 1];
              h = a[f + 2];
              g = b[k >> 2];
              k = b[((k & 3) << 4) | (n >> 4)];
              n = b[((n & 15) << 2) | (h >> 6)];
              h = b[h & 63];
              c[e++] = "" + g + k + n + h;
            }
            g = 0;
            h = d;
            switch (a.length - f) {
              case 2:
                (g = a[f + 1]), (h = b[(g & 15) << 2] || d);
              case 1:
                (a = a[f]),
                  (c[e] =
                    "" + b[a >> 2] + b[((a & 3) << 4) | (g >> 4)] + h + d);
            }
            a = c.join("");
          }
      }
    return a;
  }
  function Fi() {}
  function R(a, b) {
    return -1 === b ? null : b >= a.F ? (a.D ? a.D[b] : void 0) : a.C[b + a.G];
  }
  function S(a, b, c, d, e) {
    if ((e = void 0 === e || !e)) e = (e = a.C) ? !!(wi(e) & 2) : !1;
    if (e) throw Error("Cannot mutate an immutable Message");
    a.J && (a.J = void 0);
    if (b >= a.F || (void 0 === d ? 0 : d))
      return ((a.D || (a.D = a.C[a.F + a.G] = {}))[b] = c), a;
    void 0 !== a.D && a.F >= a.C.length
      ? ((d = a.C.length - 1),
        (e = b + a.G),
        e >= d
          ? ((a.C[d] = void 0), (a.C[e] = c), a.C.push(a.D))
          : (a.C[e] = c))
      : (a.C[b + a.G] = c);
    void 0 !== a.D && b in a.D && delete a.D[b];
    return a;
  }
  function Gi(a, b) {
    a = R(a, b);
    return null == a ? a : +a;
  }
  function T(a, b) {
    a = R(a, b);
    return null == a ? a : !!a;
  }
  function U(a, b) {
    a = T(a, b);
    return null == a ? !1 : a;
  }
  function Hi(a, b, c) {
    a || (a = Ii);
    Ii = null;
    var d = this.constructor.C || 0,
      e = 0 < d,
      f = this.constructor.D,
      g = !1;
    if (!a) {
      var h = f ? [f] : [];
      vi(h, 48);
      a = h;
      h = !0;
    } else if ((h = !!(wi(a) & 16))) {
      g = wi(a);
      var k = a,
        n = g | 32;
      ui
        ? (k[ui] = n)
        : void 0 !== k.za
        ? (k.za = n)
        : Object.defineProperties(k, {
            za: { value: n, configurable: !0, writable: !0, enumerable: !1 },
          });
      g = !!(g & 32);
    }
    e &&
      0 < a.length &&
      Ai(a[a.length - 1]) &&
      "g" in a[a.length - 1] &&
      (d = 0);
    this.G = (f ? 0 : -1) - d;
    this.C = a;
    a: {
      f = this.C.length;
      d = f - 1;
      if (f && ((f = this.C[d]), Ai(f))) {
        this.D = f;
        b = Object.keys(f);
        0 < b.length && ic(b, isNaN)
          ? (this.F = Number.MAX_VALUE)
          : (this.F = d - this.G);
        break a;
      }
      void 0 !== b && -1 < b
        ? ((this.F = Math.max(b, d + 1 - this.G)), (this.D = void 0))
        : (this.F = Number.MAX_VALUE);
    }
    if (!e && this.D && "g" in this.D)
      throw Error(
        'Unexpected "g" flag in sparse object of message that is not a group type.'
      );
    if (c)
      for (e = h && !g ? yi : xi, b = 0; b < c.length; b++)
        (h = c[b]),
          (g = R(this, h)) ? Array.isArray(g) && e(g) : S(this, h, Bi, !1, !0);
  }
  Hi.prototype.toJSON = function () {
    return Di(this.C, Ei, Fi);
  };
  Hi.prototype.wd = zi;
  Hi.prototype.toString = function () {
    return this.C.toString();
  };
  var Ii;
  function Ji(a, b) {
    this.F = this.L = this.G = "";
    this.M = null;
    this.K = this.D = "";
    this.J = !1;
    var c;
    a instanceof Ji
      ? ((this.J = void 0 !== b ? b : a.J),
        Ki(this, a.G),
        (this.L = a.L),
        (this.F = a.F),
        Li(this, a.M),
        Mi(this, a.D),
        Ni(this, Oi(a.C)),
        (this.K = a.K))
      : a && (c = String(a).match(ah))
      ? ((this.J = !!b),
        Ki(this, c[1] || "", !0),
        (this.L = Pi(c[2] || "")),
        (this.F = Pi(c[3] || "", !0)),
        Li(this, c[4]),
        Mi(this, c[5] || "", !0),
        Ni(this, c[6] || "", !0),
        (this.K = Pi(c[7] || "")))
      : ((this.J = !!b), (this.C = new Qi(null, this.J)));
  }
  Ji.prototype.toString = function () {
    var a = [],
      b = this.G;
    b && a.push(Ri(b, Si, !0), ":");
    var c = this.F;
    if (c || "file" == b)
      a.push("//"),
        (b = this.L) && a.push(Ri(b, Si, !0), "@"),
        a.push(
          encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")
        ),
        (c = this.M),
        null != c && a.push(":", String(c));
    if ((c = this.D))
      this.F && "/" != c.charAt(0) && a.push("/"),
        a.push(Ri(c, "/" == c.charAt(0) ? Ti : Ui, !0));
    (c = this.C.toString()) && a.push("?", c);
    (c = this.K) && a.push("#", Ri(c, Vi));
    return a.join("");
  };
  Ji.prototype.resolve = function (a) {
    var b = new Ji(this),
      c = !!a.G;
    c ? Ki(b, a.G) : (c = !!a.L);
    c ? (b.L = a.L) : (c = !!a.F);
    c ? (b.F = a.F) : (c = null != a.M);
    var d = a.D;
    if (c) Li(b, a.M);
    else if ((c = !!a.D)) {
      if ("/" != d.charAt(0))
        if (this.F && !this.D) d = "/" + d;
        else {
          var e = b.D.lastIndexOf("/");
          -1 != e && (d = b.D.slice(0, e + 1) + d);
        }
      e = d;
      if (".." == e || "." == e) d = "";
      else if (-1 != e.indexOf("./") || -1 != e.indexOf("/.")) {
        d = Nc(e, "/");
        e = e.split("/");
        for (var f = [], g = 0; g < e.length; ) {
          var h = e[g++];
          "." == h
            ? d && g == e.length && f.push("")
            : ".." == h
            ? ((1 < f.length || (1 == f.length && "" != f[0])) && f.pop(),
              d && g == e.length && f.push(""))
            : (f.push(h), (d = !0));
        }
        d = f.join("/");
      } else d = e;
    }
    c ? Mi(b, d) : (c = "" !== a.C.toString());
    c ? Ni(b, Oi(a.C)) : (c = !!a.K);
    c && (b.K = a.K);
    return b;
  };
  function Ki(a, b, c) {
    a.G = c ? Pi(b, !0) : b;
    a.G && (a.G = a.G.replace(/:$/, ""));
  }
  function Li(a, b) {
    if (b) {
      b = Number(b);
      if (isNaN(b) || 0 > b) throw Error("Bad port number " + b);
      a.M = b;
    } else a.M = null;
  }
  function Mi(a, b, c) {
    a.D = c ? Pi(b, !0) : b;
    return a;
  }
  function Ni(a, b, c) {
    b instanceof Qi
      ? ((a.C = b), Wi(a.C, a.J))
      : (c || (b = Ri(b, Xi)), (a.C = new Qi(b, a.J)));
  }
  function Yi(a, b, c) {
    a.C.set(b, c);
    return a;
  }
  function Zi(a, b) {
    return a instanceof Ji ? new Ji(a) : new Ji(a, b);
  }
  function Pi(a, b) {
    return a
      ? b
        ? decodeURI(a.replace(/%25/g, "%2525"))
        : decodeURIComponent(a)
      : "";
  }
  function Ri(a, b, c) {
    return typeof a === r
      ? ((a = encodeURI(a).replace(b, $i)),
        c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")),
        a)
      : null;
  }
  function $i(a) {
    a = a.charCodeAt(0);
    return "%" + ((a >> 4) & 15).toString(16) + (a & 15).toString(16);
  }
  var Si = /[#\/\?@]/g,
    Ui = /[#\?:]/g,
    Ti = /[#\?]/g,
    Xi = /[#\?@]/g,
    Vi = /#/g;
  function Qi(a, b) {
    this.D = this.C = null;
    this.F = a || null;
    this.G = !!b;
  }
  function aj(a) {
    a.C ||
      ((a.C = new Map()),
      (a.D = 0),
      a.F &&
        bh(a.F, function (b, c) {
          a.add(decodeURIComponent(b.replace(/\+/g, " ")), c);
        }));
  }
  function bj(a) {
    var b = Gh(a);
    if ("undefined" == typeof b) throw Error("Keys are undefined");
    var c = new Qi(null);
    a = Fh(a);
    for (var d = 0; d < b.length; d++) {
      var e = b[d],
        f = a[d];
      Array.isArray(f) ? cj(c, e, f) : c.add(e, f);
    }
    return c;
  }
  t = Qi.prototype;
  t.V = function () {
    aj(this);
    return this.D;
  };
  t.add = function (a, b) {
    aj(this);
    this.F = null;
    a = dj(this, a);
    var c = this.C.get(a);
    c || this.C.set(a, (c = []));
    c.push(b);
    this.D = this.D + 1;
    return this;
  };
  function ej(a, b) {
    aj(a);
    b = dj(a, b);
    a.C.has(b) &&
      ((a.F = null), (a.D = a.D - a.C.get(b).length), a.C.delete(b));
  }
  t.la = function () {
    aj(this);
    return 0 == this.D;
  };
  function fj(a, b) {
    aj(a);
    b = dj(a, b);
    return a.C.has(b);
  }
  t.forEach = function (a, b) {
    aj(this);
    this.C.forEach(function (c, d) {
      c.forEach(function (e) {
        a.call(b, e, d, this);
      }, this);
    }, this);
  };
  t.oa = function () {
    aj(this);
    for (
      var a = Array.from(this.C.values()),
        b = Array.from(this.C.keys()),
        c = [],
        d = 0;
      d < b.length;
      d++
    )
      for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
    return c;
  };
  t.ca = function (a) {
    aj(this);
    var b = [];
    if (typeof a === r) fj(this, a) && (b = b.concat(this.C.get(dj(this, a))));
    else {
      a = Array.from(this.C.values());
      for (var c = 0; c < a.length; c++) b = b.concat(a[c]);
    }
    return b;
  };
  t.set = function (a, b) {
    aj(this);
    this.F = null;
    a = dj(this, a);
    fj(this, a) && (this.D = this.D - this.C.get(a).length);
    this.C.set(a, [b]);
    this.D = this.D + 1;
    return this;
  };
  t.get = function (a, b) {
    if (!a) return b;
    a = this.ca(a);
    return 0 < a.length ? String(a[0]) : b;
  };
  function cj(a, b, c) {
    ej(a, b);
    0 < c.length &&
      ((a.F = null), a.C.set(dj(a, b), nc(c)), (a.D = a.D + c.length));
  }
  t.toString = function () {
    if (this.F) return this.F;
    if (!this.C) return "";
    for (var a = [], b = Array.from(this.C.keys()), c = 0; c < b.length; c++) {
      var d = b[c],
        e = encodeURIComponent(String(d));
      d = this.ca(d);
      for (var f = 0; f < d.length; f++) {
        var g = e;
        "" !== d[f] && (g += "=" + encodeURIComponent(String(d[f])));
        a.push(g);
      }
    }
    return (this.F = a.join("&"));
  };
  function Oi(a) {
    var b = new Qi();
    b.F = a.F;
    a.C && ((b.C = new Map(a.C)), (b.D = a.D));
    return b;
  }
  function dj(a, b) {
    b = String(b);
    a.G && (b = b.toLowerCase());
    return b;
  }
  function Wi(a, b) {
    b &&
      !a.G &&
      (aj(a),
      (a.F = null),
      a.C.forEach(function (c, d) {
        var e = d.toLowerCase();
        d != e && (ej(this, d), cj(this, e, c));
      }, a));
    a.G = b;
  }
  t.Dc = function (a) {
    for (var b = 0; b < arguments.length; b++)
      Hh(
        arguments[b],
        function (c, d) {
          this.add(d, c);
        },
        this
      );
  };
  var gj = {},
    hj = {},
    ij = {};
  function jj() {
    throw Error("Do not instantiate directly");
  }
  jj.prototype.Xb = null;
  jj.prototype.Cb = function () {
    return this.content;
  };
  jj.prototype.toString = function () {
    return this.content;
  };
  function kj() {
    jj.call(this);
  }
  A(kj, jj);
  kj.prototype.Yb = gj;
  function lj(a, b) {
    return null != a && a.Yb === b;
  }
  function mj(a) {
    if (null != a)
      switch (a.Xb) {
        case 1:
          return 1;
        case -1:
          return -1;
        case 0:
          return 0;
      }
    return null;
  }
  function nj(a) {
    return lj(a, gj)
      ? a
      : a instanceof Ad
      ? oj(Bd(a).toString())
      : a instanceof Ad
      ? oj(Bd(a).toString())
      : oj(String(String(a)).replace(pj, qj), mj(a));
  }
  var oj = (function (a) {
    function b(c) {
      this.content = c;
    }
    b.prototype = a.prototype;
    return function (c, d) {
      c = new b(String(c));
      void 0 !== d && (c.Xb = d);
      return c;
    };
  })(kj);
  function rj(a) {
    if (lj(a, gj)) {
      var b = String;
      a = String(a.Cb()).replace(sj, "").replace(tj, "&lt;");
      b = b(a).replace(uj, qj);
    } else b = String(a).replace(pj, qj);
    return b;
  }
  function vj(a) {
    lj(a, hj) || lj(a, ij)
      ? (a = wj(a))
      : a instanceof C
      ? (a = wj(Yc(a)))
      : a instanceof C
      ? (a = wj(Yc(a)))
      : a instanceof Hc
      ? (a = wj(Jc(a).toString()))
      : a instanceof Hc
      ? (a = wj(Jc(a).toString()))
      : ((a = String(a)), (a = xj.test(a) ? a.replace(yj, zj) : ra));
    return a;
  }
  var Aj = {
    "\x00": "&#0;",
    "\t": "&#9;",
    "\n": "&#10;",
    "\v": "&#11;",
    "\f": "&#12;",
    "\r": "&#13;",
    " ": "&#32;",
    '"': "&quot;",
    "&": "&amp;",
    "'": "&#39;",
    "-": "&#45;",
    "/": "&#47;",
    "<": "&lt;",
    "=": "&#61;",
    ">": "&gt;",
    "`": "&#96;",
    "\u0085": "&#133;",
    "\u00a0": "&#160;",
    "\u2028": "&#8232;",
    "\u2029": "&#8233;",
  };
  function qj(a) {
    return Aj[a];
  }
  var Bj = {
    "\x00": "%00",
    "\u0001": "%01",
    "\u0002": "%02",
    "\u0003": "%03",
    "\u0004": "%04",
    "\u0005": "%05",
    "\u0006": "%06",
    "\u0007": "%07",
    "\b": "%08",
    "\t": "%09",
    "\n": "%0A",
    "\v": "%0B",
    "\f": "%0C",
    "\r": "%0D",
    "\u000e": "%0E",
    "\u000f": "%0F",
    "\u0010": "%10",
    "\u0011": "%11",
    "\u0012": "%12",
    "\u0013": "%13",
    "\u0014": "%14",
    "\u0015": "%15",
    "\u0016": "%16",
    "\u0017": "%17",
    "\u0018": "%18",
    "\u0019": "%19",
    "\u001a": "%1A",
    "\u001b": "%1B",
    "\u001c": "%1C",
    "\u001d": "%1D",
    "\u001e": "%1E",
    "\u001f": "%1F",
    " ": "%20",
    '"': "%22",
    "'": "%27",
    "(": "%28",
    ")": "%29",
    "<": "%3C",
    ">": "%3E",
    "\\": "%5C",
    "{": "%7B",
    "}": "%7D",
    "\u007f": "%7F",
    "\u0085": "%C2%85",
    "\u00a0": "%C2%A0",
    "\u2028": "%E2%80%A8",
    "\u2029": "%E2%80%A9",
    "\uff01": "%EF%BC%81",
    "\uff03": "%EF%BC%83",
    "\uff04": "%EF%BC%84",
    "\uff06": "%EF%BC%86",
    "\uff07": "%EF%BC%87",
    "\uff08": "%EF%BC%88",
    "\uff09": "%EF%BC%89",
    "\uff0a": "%EF%BC%8A",
    "\uff0b": "%EF%BC%8B",
    "\uff0c": "%EF%BC%8C",
    "\uff0f": "%EF%BC%8F",
    "\uff1a": "%EF%BC%9A",
    "\uff1b": "%EF%BC%9B",
    "\uff1d": "%EF%BC%9D",
    "\uff1f": "%EF%BC%9F",
    "\uff20": "%EF%BC%A0",
    "\uff3b": "%EF%BC%BB",
    "\uff3d": "%EF%BC%BD",
  };
  function zj(a) {
    return Bj[a];
  }
  var pj = /[\x00\x22\x26\x27\x3c\x3e]/g,
    uj = /[\x00\x22\x27\x3c\x3e]/g,
    yj =
      /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
    xj = /^(?:(?:https?|mailto|ftp):|[^&:\/?#]*(?:[\/?#]|$))/i,
    Cj =
      /^[^&:\/?#]*(?:[\/?#]|$)|^https?:|^ftp:|^data:image\/[a-z0-9+]+;base64,[a-z0-9+\/]+=*$|^blob:/i;
  function wj(a) {
    return String(a).replace(yj, zj);
  }
  var sj = /<(?:!|\/?([a-zA-Z][a-zA-Z0-9:\-]*))(?:[^>'"]|"[^"]*"|'[^']*')*>/g,
    tj = /</g; /*
 SPDX-License-Identifier: Apache-2.0 */
  var Dj = Object.prototype.hasOwnProperty;
  function Ej() {}
  Ej.prototype = Object.create(null);
  function Fj(a, b, c) {
    a = a.style;
    if (typeof c === r) a.cssText = c;
    else {
      a.cssText = "";
      for (var d in c)
        Dj.call(c, d) &&
          ((b = c[d]), 0 <= d.indexOf("-") ? a.setProperty(d, b) : (a[d] = b));
    }
  }
  function Gj(a, b, c) {
    var d = typeof c;
    d === q || d === m
      ? (a[b] = c)
      : null == c
      ? a.removeAttribute(b)
      : (d =
          0 === b.lastIndexOf("xml:", 0)
            ? "http://www.w3.org/XML/1998/namespace"
            : 0 === b.lastIndexOf("xlink:", 0)
            ? "http://www.w3.org/1999/xlink"
            : null)
      ? a.setAttributeNS(d, b, c)
      : a.setAttribute(b, c);
  }
  function Hj() {
    var a = new Ej();
    a.__default = Gj;
    a.style = Fj;
    return a;
  }
  Hj();
  var Ij = Hj(); /*
 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var Jj = {};
  Ij.checked = function (a, b, c) {
    null == c
      ? (a.removeAttribute("checked"), (a.checked = !1))
      : (a.setAttribute("checked", String(c)),
        (a.checked = !(!1 === c || "false" === c)));
  };
  Ij.value = function (a, b, c) {
    null == c
      ? (a.removeAttribute("value"), (a.value = ""))
      : (a.setAttribute("value", String(c)), (a.value = String(c)));
  };
  function Kj(a, b) {
    return Lj(b, a.config, a.xd, a.ld, a.depth);
  }
  function Lj(a, b, c, d, e) {
    var f = d.extraIconClass,
      g =
        '<li class="comment" id="c' +
        rj(d.id) +
        '"><div class="avatar-image-container"><img src="',
      h = d.authorAvatarSrc;
    lj(h, hj) || lj(h, ij)
      ? (h = wj(h))
      : h instanceof C
      ? (h = wj(Yc(h)))
      : h instanceof C
      ? (h = wj(Yc(h)))
      : h instanceof Hc
      ? (h = wj(Jc(h).toString()))
      : h instanceof Hc
      ? (h = wj(Jc(h).toString()))
      : ((h = String(h)), (h = Cj.test(h) ? h.replace(yj, zj) : ra));
    f =
      g +
      rj(h) +
      '" alt=""/></div><div class="comment-block"><div class="comment-header"><cite class="user">' +
      (d.authorUrl
        ? '<a href="' +
          rj(vj(d.authorUrl)) +
          '" rel="nofollow">' +
          nj(d.author) +
          "</a>"
        : nj(d.author)) +
      '</cite><span class="icon user ' +
      rj(null != f ? f : "") +
      '"></span><span class="datetime secondary-text"><a rel="nofollow" href="' +
      rj(vj(d.url)) +
      '">' +
      nj(d.timestamp) +
      '</a></span></div><p class="comment-content">' +
      nj(d.body) +
      '</p><span class="comment-actions secondary-text">' +
      (e < b.maxDepth
        ? '<a class="comment-reply" target="_self" data-comment-id="' +
          rj(d.id) +
          '">' +
          nj(c.reply) +
          "</a>"
        : "") +
      '<span class="item-control blog-admin ' +
      rj(d.adminClass) +
      '"><a target="_self" href="' +
      rj(vj(d.deleteUrl)) +
      '">' +
      nj(c["delete"]) +
      '</a></span></span></div><div class="comment-replies">';
    g = d.replies;
    g = null != g ? g : [];
    f +=
      '<div id="c' +
      rj(d.id) +
      '-rt" class="comment-thread inline-thread' +
      (0 == g.length ? " hidden" : "") +
      '"><span class="thread-toggle thread-expanded"><span class="thread-arrow"></span><span class="thread-count"><a target="_self">' +
      nj(c.replies) +
      '</a></span></span><ol id="c' +
      rj(d.id) +
      '-ra" class="thread-chrome thread-expanded"><div>';
    h = g.length;
    for (var k = 0; k < h; k++) f += Lj(a, b, c, g[k], e ? e + 1 : 1);
    f +=
      '</div><div id="c' +
      rj(d.id) +
      '-continue" class="continue"><a class="comment-reply" target="_self" data-comment-id="' +
      rj(d.id) +
      '">' +
      nj(c.reply) +
      '</a></div></ol></div></div><div class="comment-replybox-single" id="c' +
      rj(d.id) +
      '-ce"></div></li>';
    return oj(f);
  }
  function Mj(a, b, c) {
    if (typeof b === r) (b = Nj(a, b)) && (a.style[b] = c);
    else
      for (var d in b) {
        c = a;
        var e = b[d],
          f = Nj(c, d);
        f && (c.style[f] = e);
      }
  }
  var Oj = {};
  function Nj(a, b) {
    var c = Oj[b];
    if (!c) {
      var d = Ye(b);
      c = d;
      void 0 === a.style[d] &&
        ((d = (Be ? "Webkit" : Ae ? "Moz" : I ? "ms" : null) + Ze(d)),
        void 0 !== a.style[d] && (c = d));
      Oj[b] = c;
    }
    return c;
  }
  function Pj() {}
  Sb(Pj);
  function Qj(a) {
    cg.call(this);
    this.Y = a || cc || (cc = new sf());
    this.ga = null;
    this.ua = !1;
    this.C = null;
    this.D = void 0;
    this.T = this.L = null;
  }
  A(Qj, cg);
  Pj.Za();
  t = Qj.prototype;
  t.Ya = function () {
    return this.C;
  };
  function Rj(a) {
    a.D || (a.D = new Yf(a));
    return a.D;
  }
  t.Mb = function () {
    this.C = tf(this.Y, "DIV");
  };
  t.render = function (a) {
    if (this.ua) throw Error("Component already rendered");
    this.C || this.Mb();
    a ? a.insertBefore(this.C, null) : this.Y.D.body.appendChild(this.C);
    (this.L && !this.L.ua) || this.Xa();
  };
  t.Xa = function () {
    this.ua = !0;
    Sj(this, function (a) {
      !a.ua && a.Ya() && a.Xa();
    });
  };
  function Tj(a) {
    Sj(a, function (b) {
      b.ua && Tj(b);
    });
    a.D && bg(a.D);
    a.ua = !1;
  }
  t.X = function () {
    this.ua && Tj(this);
    this.D && (this.D.wa(), delete this.D);
    Sj(this, function (a) {
      a.wa();
    });
    this.C && kf(this.C);
    this.L = this.C = this.T = null;
    Qj.O.X.call(this);
  };
  function Sj(a, b) {
    a.T && a.T.forEach(b, void 0);
  }
  function Uj(a, b, c, d) {
    Qj.call(this, d);
    this.J = c || window;
    this.Z = a;
    this.da = b;
    this.R = {};
    this.K = this.F = null;
    this.G = {};
    this.G.EMAIL = { eb: "Email", yb: this.cd };
    this.G.FACEBOOK = { eb: "Facebook", yb: this.dd };
    this.G.TWITTER = { eb: "Twitter", yb: this.ed };
  }
  v(Uj, Qj);
  t = Uj.prototype;
  t.Mb = function () {
    var a = this.Y,
      b = a.C("DIV", {
        style:
          "position:absolute;width:100%;left:0;top:0;height:100%;z-index:100;",
        class: "mobile-share-panel-outer",
      });
    this.F = a.C("DIV", {
      style: "position:absolute;;width:230px;height:200px;",
      class: "mobile-share-panel-inner",
    });
    b.appendChild(this.F);
    var c = a.C("DIV", { class: "mobile-share-panel-title" });
    c.innerText = na;
    c.textContent = na;
    this.F.appendChild(c);
    this.K = a.C("A", {
      href: "javascript:void(0)",
      class: "mobile-share-panel-button-close",
    });
    this.K.textContent = "\u00d7";
    c.appendChild(this.K);
    for (var d in this.G) {
      c = a.C("A", {
        target: pa,
        display: ta,
        class:
          "mobile-share-panel-button mobile-share-panel-button-" +
          d.toLowerCase(),
      });
      var e = a.C(ja),
        f = this.G[d];
      e.innerText = f.eb;
      e.textContent = f.eb;
      c.href = f.yb.call(this);
      c.appendChild(e);
      this.F.appendChild(c);
      this.R[d] = c;
    }
    this.C = b;
  };
  t.Xa = function () {
    Qj.prototype.Xa.call(this);
    for (var a in this.R) {
      var b = this.R[a];
      b && $f(Rj(this), b, ua, this.zb);
    }
    $f(Rj(this), this.K, ua, this.zb);
    a = this.Ya();
    $f(Rj(this), a, ua, this.zb);
    this.Rb();
    $f(Rj(this), this.J, "scroll", this.Rb);
  };
  t.show = function (a) {
    var b = this.Ya();
    b && (b.style.display = a ? "" : p);
  };
  t.Rb = function () {
    var a = this.J.innerHeight,
      b = this.J.innerWidth,
      c = this.J.pageYOffset,
      d = this.J.pageXOffset,
      e = 0;
    200 < a && (e = (a - 200) / 2);
    Mj(this.F, "top", e + c + "px");
    a = 0;
    230 < b && (a = (b - 230) / 2);
    Mj(this.F, "left", a + d + "px");
  };
  t.ed = function () {
    return (
      "https://twitter.com/intent/tweet?text=" +
      encodeURIComponent(this.Z + ": " + this.da)
    );
  };
  t.dd = function () {
    return (
      "https://m.facebook.com/sharer.php?u=" +
      encodeURIComponent(this.da) +
      "&t=" +
      encodeURIComponent(this.Z)
    );
  };
  t.cd = function () {
    return (
      "mailto:?subject=" +
      encodeURIComponent(this.Z) +
      "&body=" +
      encodeURIComponent(this.da)
    );
  };
  t.zb = function () {
    this.show(!1);
  };
  var Vj = RegExp(
      "^((http(s)?):)?\\/\\/((((lh[3-6](-tt|-d[a-g,z]|-testonly)?\\.((ggpht)|(googleusercontent)|(google)|(sandbox\\.google)))|(([1-4]\\.bp\\.blogspot)|(bp[0-3]\\.blogger))|(ccp-lh\\.googleusercontent)|((((cp|ci|gp)[3-6])|(ap[1-2]))\\.(ggpht|googleusercontent))|(gm[1-4]\\.ggpht)|(play-(ti-)?lh\\.googleusercontent)|(gz0\\.googleusercontent)|(((yt[3-4])|(sp[1-3]))\\.(ggpht|googleusercontent)))\\.com)|(dp[3-6]\\.googleusercontent\\.cn)|(lh[3-6]\\.(googleadsserving\\.cn|xn--9kr7l\\.com))|(photos\\-image\\-(dev|qa)(-auth)?\\.corp\\.google\\.com)|((dev|dev2|dev3|qa|qa2|qa3|qa-red|qa-blue|canary)[-.]lighthouse\\.sandbox\\.google\\.com\\/image)|(image\\-(dev|qa)\\-lighthouse(-auth)?\\.sandbox\\.google\\.com(\\/image)?))\\/",
      "i"
    ),
    Wj = /^(https?:)?\/\/sp[1-4]\.((ggpht)|(googleusercontent))\.com\//i,
    Xj =
      /^(https?:)?\/\/(qa(-red|-blue)?|dev2?|image-dev)(-|\.)lighthouse(-auth)?\.sandbox\.google\.com\//i,
    Yj =
      /^(https?:)?\/\/lighthouse-(qa(-red|-blue)?|dev2)\.corp\.google\.com\//i;
  function Zj(a) {
    return Vj.test(a) || Wj.test(a) || Xj.test(a) || Yj.test(a);
  }
  function ak(a) {
    Hi.call(this, a);
  }
  v(ak, Hi);
  ak.prototype.getToken = function () {
    return R(this, 24);
  };
  ak.prototype.setToken = function (a) {
    return S(this, 24, a);
  };
  function bk() {
    this.D = void 0;
    this.C = {};
  }
  t = bk.prototype;
  t.set = function (a, b) {
    ck(this, a, b, !1);
  };
  t.add = function (a, b) {
    ck(this, a, b, !0);
  };
  function ck(a, b, c, d) {
    for (var e = 0; e < b.length; e++) {
      var f = b.charAt(e);
      a.C[f] || (a.C[f] = new bk());
      a = a.C[f];
    }
    if (d && void 0 !== a.D)
      throw Error('The collection already contains the key "' + b + '"');
    a.D = c;
  }
  function dk(a, b) {
    for (var c = 0; c < b.length; c++) if (((a = a.C[b.charAt(c)]), !a)) return;
    return a;
  }
  t.get = function (a) {
    return (a = dk(this, a)) ? a.D : void 0;
  };
  t.ca = function () {
    var a = [];
    ek(this, a);
    return a;
  };
  function ek(a, b) {
    void 0 !== a.D && b.push(a.D);
    for (var c in a.C) ek(a.C[c], b);
  }
  t.oa = function (a) {
    var b = [];
    if (a) {
      for (var c = this, d = 0; d < a.length; d++) {
        var e = a.charAt(d);
        if (!c.C[e]) return [];
        c = c.C[e];
      }
      fk(c, a, b);
    } else fk(this, "", b);
    return b;
  };
  function fk(a, b, c) {
    void 0 !== a.D && c.push(b);
    for (var d in a.C) fk(a.C[d], b + d, c);
  }
  t.V = function () {
    var a = this.ca();
    if (a.V && typeof a.V == m) a = a.V();
    else if (Tb(a) || typeof a === r) a = a.length;
    else {
      var b = 0,
        c;
      for (c in a) b++;
      a = b;
    }
    return a;
  };
  t.la = function () {
    return void 0 === this.D && uc(this.C);
  };
  function gk() {
    if (!hk) {
      var a = (hk = new bk()),
        b;
      for (b in ik) a.add(b, ik[b]);
    }
  }
  var hk;
  function V(a, b) {
    this.types = a;
    this.C = b;
  }
  var ik = {
    a: new V(
      [3, 0],
      [
        function (a, b) {
          S(a, 21, b);
        },
        function (a, b) {
          S(a, 56, b);
        },
      ]
    ),
    al: new V(
      [3],
      [
        function (a, b) {
          S(a, 74, b);
        },
      ]
    ),
    b: new V(
      [3, 0],
      [
        function (a, b) {
          S(a, 23, b);
        },
        function (a, b) {
          S(a, 38, b);
        },
      ]
    ),
    ba: new V(
      [0],
      [
        function (a, b) {
          S(a, 85, b);
        },
      ]
    ),
    bc: new V(
      [0],
      [
        function (a, b) {
          S(a, 87, b);
        },
      ]
    ),
    br: new V(
      [0],
      [
        function (a, b) {
          S(a, 86, b);
        },
      ]
    ),
    c: new V(
      [3, 0],
      [
        function (a, b) {
          S(a, 2, b);
        },
        function (a, b) {
          S(a, 39, b);
        },
      ]
    ),
    cc: new V(
      [3],
      [
        function (a, b) {
          S(a, 51, b);
        },
      ]
    ),
    ci: new V(
      [3],
      [
        function (a, b) {
          S(a, 32, b);
        },
      ]
    ),
    cp: new V(
      [0],
      [
        function (a, b) {
          S(a, 92, b);
        },
      ]
    ),
    cv: new V(
      [0],
      [
        function (a, b) {
          S(a, 94, b);
        },
      ]
    ),
    d: new V(
      [3],
      [
        function (a, b) {
          S(a, 3, b);
        },
      ]
    ),
    dc: new V(
      [5],
      [
        function (a, b) {
          S(a, 99, b);
        },
      ]
    ),
    df: new V(
      [3],
      [
        function (a, b) {
          S(a, 80, b);
        },
      ]
    ),
    dv: new V(
      [3],
      [
        function (a, b) {
          S(a, 90, b);
        },
      ]
    ),
    e: new V(
      [0],
      [
        function (a, b) {
          S(a, 15, b);
        },
      ]
    ),
    f: new V(
      [4],
      [
        function (a, b) {
          S(a, 16, b);
        },
      ]
    ),
    fg: new V(
      [3],
      [
        function (a, b) {
          S(a, 34, b);
        },
      ]
    ),
    fh: new V(
      [3],
      [
        function (a, b) {
          S(a, 30, b);
        },
      ]
    ),
    fm: new V(
      [3],
      [
        function (a, b) {
          S(a, 84, b);
        },
      ]
    ),
    fo: new V(
      [2],
      [
        function (a, b) {
          S(a, 79, b);
        },
      ]
    ),
    ft: new V(
      [3],
      [
        function (a, b) {
          S(a, 50, b);
        },
      ]
    ),
    fv: new V(
      [3],
      [
        function (a, b) {
          S(a, 31, b);
        },
      ]
    ),
    g: new V(
      [3],
      [
        function (a, b) {
          S(a, 14, b);
        },
      ]
    ),
    gd: new V(
      [3],
      [
        function (a, b) {
          S(a, 83, b);
        },
      ]
    ),
    h: new V(
      [3, 0],
      [
        function (a, b) {
          S(a, 4, b);
        },
        function (a, b) {
          S(a, 13, b);
        },
      ]
    ),
    i: new V(
      [3],
      [
        function (a, b) {
          S(a, 22, b);
        },
      ]
    ),
    ic: new V(
      [0],
      [
        function (a, b) {
          S(a, 71, b);
        },
      ]
    ),
    id: new V(
      [3],
      [
        function (a, b) {
          S(a, 70, b);
        },
      ]
    ),
    il: new V(
      [3],
      [
        function (a, b) {
          S(a, 96, b);
        },
      ]
    ),
    ip: new V(
      [3],
      [
        function (a, b) {
          S(a, 54, b);
        },
      ]
    ),
    iv: new V(
      [0],
      [
        function (a, b) {
          S(a, 75, b);
        },
      ]
    ),
    j: new V(
      [1],
      [
        function (a, b) {
          S(a, 29, b);
        },
      ]
    ),
    k: new V(
      [3, 0],
      [
        function (a, b) {
          S(a, 17, b);
        },
        function (a, b) {
          S(a, 42, b);
        },
      ]
    ),
    l: new V(
      [0],
      [
        function (a, b) {
          S(a, 44, b);
        },
      ]
    ),
    lf: new V(
      [3],
      [
        function (a, b) {
          S(a, 65, b);
        },
      ]
    ),
    lo: new V(
      [3],
      [
        function (a, b) {
          S(a, 97, b);
        },
      ]
    ),
    m: new V(
      [0],
      [
        function (a, b) {
          S(a, 63, b);
        },
      ]
    ),
    md: new V(
      [3],
      [
        function (a, b) {
          S(a, 91, b);
        },
      ]
    ),
    mm: new V(
      [4],
      [
        function (a, b) {
          S(a, 81, b);
        },
      ]
    ),
    mo: new V(
      [3],
      [
        function (a, b) {
          S(a, 73, b);
        },
      ]
    ),
    mv: new V(
      [3],
      [
        function (a, b) {
          S(a, 66, b);
        },
      ]
    ),
    n: new V(
      [3],
      [
        function (a, b) {
          S(a, 20, b);
        },
      ]
    ),
    nc: new V(
      [3],
      [
        function (a, b) {
          S(a, 55, b);
        },
      ]
    ),
    nd: new V(
      [3],
      [
        function (a, b) {
          S(a, 53, b);
        },
      ]
    ),
    ng: new V(
      [3],
      [
        function (a, b) {
          S(a, 95, b);
        },
      ]
    ),
    no: new V(
      [3],
      [
        function (a, b) {
          S(a, 37, b);
        },
      ]
    ),
    ns: new V(
      [3],
      [
        function (a, b) {
          S(a, 40, b);
        },
      ]
    ),
    nt0: new V(
      [4],
      [
        function (a, b) {
          S(a, 36, b);
        },
      ]
    ),
    nu: new V(
      [3],
      [
        function (a, b) {
          S(a, 46, b);
        },
      ]
    ),
    nw: new V(
      [3],
      [
        function (a, b) {
          S(a, 48, b);
        },
      ]
    ),
    o: new V(
      [1, 3],
      [
        function (a, b) {
          S(a, 7, b);
        },
        function (a, b) {
          S(a, 27, b);
        },
      ]
    ),
    p: new V(
      [3, 0],
      [
        function (a, b) {
          S(a, 19, b);
        },
        function (a, b) {
          S(a, 43, b);
        },
      ]
    ),
    pa: new V(
      [3],
      [
        function (a, b) {
          S(a, 61, b);
        },
      ]
    ),
    pc: new V(
      [0],
      [
        function (a, b) {
          S(a, 88, b);
        },
      ]
    ),
    pd: new V(
      [3],
      [
        function (a, b) {
          S(a, 60, b);
        },
      ]
    ),
    pf: new V(
      [3],
      [
        function (a, b) {
          S(a, 67, b);
        },
      ]
    ),
    pg: new V(
      [3],
      [
        function (a, b) {
          S(a, 72, b);
        },
      ]
    ),
    pi: new V(
      [2],
      [
        function (a, b) {
          S(a, 76, b);
        },
      ]
    ),
    pp: new V(
      [3],
      [
        function (a, b) {
          S(a, 52, b);
        },
      ]
    ),
    q: new V(
      [4],
      [
        function (a, b) {
          S(a, 28, b);
        },
      ]
    ),
    r: new V(
      [3, 0],
      [
        function (a, b) {
          S(a, 6, b);
        },
        function (a, b) {
          S(a, 26, b);
        },
      ]
    ),
    rf: new V(
      [3],
      [
        function (a, b) {
          S(a, 100, b);
        },
      ]
    ),
    rg: new V(
      [3],
      [
        function (a, b) {
          S(a, 59, b);
        },
      ]
    ),
    rh: new V(
      [3],
      [
        function (a, b) {
          S(a, 49, b);
        },
      ]
    ),
    rj: new V(
      [3],
      [
        function (a, b) {
          S(a, 57, b);
        },
      ]
    ),
    ro: new V(
      [2],
      [
        function (a, b) {
          S(a, 78, b);
        },
      ]
    ),
    rp: new V(
      [3],
      [
        function (a, b) {
          S(a, 58, b);
        },
      ]
    ),
    rw: new V(
      [3],
      [
        function (a, b) {
          S(a, 35, b);
        },
      ]
    ),
    rwa: new V(
      [3],
      [
        function (a, b) {
          S(a, 64, b);
        },
      ]
    ),
    rwu: new V(
      [3],
      [
        function (a, b) {
          S(a, 41, b);
        },
      ]
    ),
    s: new V(
      [3, 0],
      [
        function (a, b) {
          S(a, 33, b);
        },
        function (a, b) {
          S(a, 1, b);
        },
      ]
    ),
    sc: new V(
      [0],
      [
        function (a, b) {
          S(a, 89, b);
        },
      ]
    ),
    sg: new V(
      [3],
      [
        function (a, b) {
          S(a, 82, b);
        },
      ]
    ),
    sm: new V(
      [3],
      [
        function (a, b) {
          S(a, 93, b);
        },
      ]
    ),
    t: new V(
      [4],
      [
        function (a, b) {
          a.setToken(b);
        },
      ]
    ),
    u: new V(
      [3],
      [
        function (a, b) {
          S(a, 18, b);
        },
      ]
    ),
    ut: new V(
      [3],
      [
        function (a, b) {
          S(a, 45, b);
        },
      ]
    ),
    v: new V(
      [0],
      [
        function (a, b) {
          S(a, 62, b);
        },
      ]
    ),
    vb: new V(
      [0],
      [
        function (a, b) {
          S(a, 68, b);
        },
      ]
    ),
    vf: new V(
      [4],
      [
        function (a, b) {
          S(a, 102, b);
        },
      ]
    ),
    vl: new V(
      [0],
      [
        function (a, b) {
          S(a, 69, b);
        },
      ]
    ),
    vm: new V(
      [3],
      [
        function (a, b) {
          S(a, 98, b);
        },
      ]
    ),
    w: new V(
      [0],
      [
        function (a, b) {
          S(a, 12, b);
        },
      ]
    ),
    x: new V(
      [0],
      [
        function (a, b) {
          S(a, 9, b);
        },
      ]
    ),
    y: new V(
      [0],
      [
        function (a, b) {
          S(a, 10, b);
        },
      ]
    ),
    ya: new V(
      [2],
      [
        function (a, b) {
          S(a, 77, b);
        },
      ]
    ),
    z: new V(
      [0],
      [
        function (a, b) {
          S(a, 11, b);
        },
      ]
    ),
  };
  t = gk.prototype;
  t.parse = function (a) {
    var b = new ak(),
      c = new ak();
    if ("" == a) a = !0;
    else {
      a = a.split("-");
      for (var d = !0, e = 0; e < a.length; e++) {
        var f = a[e];
        if (0 == f.length) d = !1;
        else {
          var g = f,
            h = !1;
          var k = g;
          var n = g.substring(0, 1);
          n != n.toLowerCase() &&
            ((h = !0), (k = g.substring(0, 1).toLowerCase() + g.substring(1)));
          var u = hk;
          for (n = 1; n <= k.length; ++n) {
            var w = u,
              G = k.substring(0, n);
            if (0 == G.length ? w.la() : !dk(w, G)) break;
          }
          k =
            1 == n
              ? null
              : (k = u.get(k.substring(0, n - 1)))
              ? {
                  Bd: g.substring(0, n - 1),
                  value: g.substring(n - 1),
                  Jd: h,
                  attributes: k,
                }
              : null;
          if (k) {
            g = [];
            h = [];
            n = !1;
            for (u = 0; u < k.attributes.types.length; u++) {
              w = k.attributes.types[u];
              var D = k.value;
              G = e;
              if (k.Jd && 1 == w)
                for (var P = D.length; 12 > P && G < a.length - 1; )
                  (D += "-" + a[G + 1]), (P = D.length), ++G;
              else if (2 == w)
                for (; G < a.length - 1 && a[G + 1].match(/^[\d\.]/); )
                  (D += "-" + a[G + 1]), ++G;
              P = k.attributes.C[u];
              D = jk(this, w)(k.Bd, D, b, c, P);
              if (null === D) {
                n = !0;
                e = G;
                break;
              } else g.push(w), h.push(D);
            }
            if (!n)
              for (k = 0; k < h.length; k++)
                (u = g[k]), (D = h[k]), kk(this, u)(f, D);
            d = d && n;
          } else d = !1;
        }
      }
      a = d;
    }
    return new lk(b, c, a);
  };
  function mk(a, b, c, d, e, f) {
    e(c, b);
    a = a.substring(0, 1);
    f = f(a == a.toUpperCase());
    e(d, f);
  }
  t.Ed = function (a, b, c, d, e) {
    if ("" == b) return 0;
    isFinite(b) && (b = String(b));
    b =
      typeof b === r
        ? /^\s*-?0x/i.test(b)
          ? parseInt(b, 16)
          : parseInt(b, 10)
        : NaN;
    if (isNaN(b)) return 1;
    mk(a, b, c, d, e, Number);
    return null;
  };
  t.ud = function () {};
  t.Dd = function (a, b, c, d, e) {
    if ("" == b) return 0;
    var f = Number(b);
    b = 0 == f && /^[\s\xa0]*$/.test(b) ? NaN : f;
    if (isNaN(b)) return 1;
    mk(a, b, c, d, e, Number);
    return null;
  };
  t.td = function () {};
  t.Cd = function (a, b, c, d, e) {
    if ("" != b) return 2;
    mk(a, !0, c, d, e, Boolean);
    return null;
  };
  t.sd = function () {};
  t.Fd = function (a, b, c, d, e) {
    if ("" == b) return 0;
    mk(a, b, c, d, e, function (f) {
      return f ? "1" : "";
    });
    return null;
  };
  t.vd = function () {};
  function jk(a, b) {
    switch (b) {
      case 0:
        return y(a.Ed, a);
      case 2:
        return y(a.Dd, a);
      case 3:
        return y(a.Cd, a);
      case 4:
      case 1:
        return y(a.Fd, a);
      default:
        return function () {};
    }
  }
  function kk(a, b) {
    switch (b) {
      case 0:
        return y(a.ud, a);
      case 2:
        return y(a.td, a);
      case 3:
        return y(a.sd, a);
      case 4:
      case 1:
        return y(a.vd, a);
      default:
        return function () {};
    }
  }
  function lk(a, b, c) {
    this.C = a;
    this.D = b;
    this.F = c;
  }
  lk.prototype.K = function () {
    return this.F;
  };
  function nk(a, b) {
    null != a && this.D.apply(this, arguments);
  }
  nk.prototype.C = "";
  nk.prototype.set = function (a) {
    this.C = "" + a;
  };
  nk.prototype.D = function (a, b, c) {
    this.C += String(a);
    if (null != b)
      for (var d = 1; d < arguments.length; d++) this.C += arguments[d];
    return this;
  };
  nk.prototype.toString = function () {
    return this.C;
  };
  function ok(a) {
    this.G = null;
    this.F = [];
    this.D = null;
    pk(this, a);
  }
  function qk(a) {
    null == a.G && (a.G = new gk());
    return a.G;
  }
  function pk(a, b) {
    a.D = b ? (typeof b === r ? qk(a).parse(b) : b) : qk(a).parse("");
  }
  t = ok.prototype;
  t.ob = function (a) {
    a = a || void 0;
    var b = this.D.C;
    a != U(b, 2) && S(b, 2, a);
    return this;
  };
  t.nb = function (a) {
    a = a || void 0;
    var b = this.D.C;
    a != T(b, 51) && S(b, 51, a);
    return this;
  };
  t.pb = function (a) {
    a = a || void 0;
    var b = this.D.C;
    a != T(b, 32) && S(b, 32, a);
    return this;
  };
  t.Sa = function (a) {
    var b = this.D.C;
    a != R(b, 13) && S(b, 13, a);
    return this;
  };
  t.mb = function (a) {
    a = a || void 0;
    var b = this.D.C;
    a != U(b, 20) && S(b, 20, a);
    return this;
  };
  t.rb = function (a) {
    a = a || void 0;
    var b = this.D.C;
    a != U(b, 19) && S(b, 19, a);
    return this;
  };
  t.qb = function (a) {
    a = a || void 0;
    var b = this.D.C;
    a != T(b, 60) && S(b, 60, a);
    return this;
  };
  t.tb = function (a) {
    a = a || void 0;
    var b = this.D.C;
    a != U(b, 67) && S(b, 67, a);
    return this;
  };
  t.sb = function (a) {
    a = a || void 0;
    var b = this.D.C;
    a != U(b, 52) && S(b, 52, a);
    return this;
  };
  t.Ca = function (a) {
    var b = this.D.C;
    a != R(b, 1) && S(b, 1, a);
    return this;
  };
  t.setToken = function (a) {
    a = a || void 0;
    var b = this.D,
      c = b.C,
      d = c.getToken();
    b.D.getToken();
    a != d && c.setToken(a);
    return this;
  };
  t.Ta = function (a) {
    var b = this.D.C;
    a != R(b, 12) && S(b, 12, a);
    return this;
  };
  function rk(a) {
    pk(a, "");
    return a;
  }
  t.ra = function () {
    this.F.length = 0;
    var a = this.D,
      b = a.C;
    a = a.D;
    W(this, "s", R(b, 1), R(a, 1));
    W(this, "w", R(b, 12), R(a, 12));
    X(this, "c", U(b, 2), U(a, 2));
    X(this, "d", U(b, 3), U(a, 3));
    W(this, "h", R(b, 13), R(a, 13));
    X(this, "s", T(b, 33), T(a, 33));
    X(this, "h", U(b, 4), U(a, 4));
    X(this, "p", U(b, 19), U(a, 19));
    X(this, "pp", U(b, 52), U(a, 52));
    X(this, "pf", U(b, 67), U(a, 67));
    X(this, "n", U(b, 20), U(a, 20));
    W(this, "r", R(b, 26), R(a, 26));
    X(this, "r", U(b, 6), U(a, 6));
    X(this, "o", T(b, 27), T(a, 27));
    sk(this, "o", R(b, 7), R(a, 7));
    sk(this, "j", R(b, 29), R(a, 29));
    W(this, "x", R(b, 9), R(a, 9));
    W(this, "y", R(b, 10), R(a, 10));
    W(this, "z", R(b, 11), R(a, 11));
    X(this, "g", U(b, 14), U(a, 14));
    W(this, "e", R(b, 15), R(a, 15));
    sk(this, "f", R(b, 16), R(a, 16));
    X(this, "k", T(b, 17), T(a, 17));
    X(this, "u", T(b, 18), !0);
    X(this, "ut", T(b, 45), !0);
    X(this, "i", T(b, 22), !0);
    X(this, "a", T(b, 21), T(a, 21));
    X(this, "b", U(b, 23), U(a, 23));
    W(this, "b", R(b, 38), R(a, 38));
    W(this, "c", R(b, 39), R(a, 39), 16, 8);
    sk(this, "q", R(b, 28), R(a, 28));
    X(this, "fh", T(b, 30), T(a, 30));
    X(this, "fv", T(b, 31), T(a, 31));
    X(this, "fg", U(b, 34), U(a, 34));
    X(this, "ci", T(b, 32), T(a, 32));
    sk(this, "t", b.getToken(), a.getToken());
    sk(this, "nt0", R(b, 36), R(a, 36));
    X(this, "rw", U(b, 35), U(a, 35));
    X(this, "rwu", U(b, 41), U(a, 41));
    X(this, "rwa", U(b, 64), U(a, 64));
    X(this, "nw", U(b, 48), U(a, 48));
    X(this, "rh", U(b, 49), U(a, 49));
    X(this, "no", U(b, 37), U(a, 37));
    X(this, "ns", T(b, 40), T(a, 40));
    W(this, "k", R(b, 42), R(a, 42));
    W(this, "p", R(b, 43), R(a, 43));
    W(this, "l", R(b, 44), R(a, 44));
    W(this, "v", R(b, 62), R(a, 62));
    X(this, "nu", T(b, 46), T(a, 46));
    X(this, "ft", T(b, 50), T(a, 50));
    X(this, "cc", T(b, 51), T(a, 51));
    X(this, "nd", T(b, 53), T(a, 53));
    X(this, "ip", T(b, 54), T(a, 54));
    X(this, "nc", T(b, 55), T(a, 55));
    W(this, "a", R(b, 56), R(a, 56));
    X(this, "rj", T(b, 57), T(a, 57));
    X(this, "rp", T(b, 58), T(a, 58));
    X(this, "rg", T(b, 59), T(a, 59));
    X(this, "pd", T(b, 60), T(a, 60));
    X(this, "pa", T(b, 61), T(a, 61));
    W(this, "m", R(b, 63), R(a, 63));
    W(this, "vb", R(b, 68), R(a, 68));
    W(this, "vl", R(b, 69), R(a, 69));
    X(this, "lf", T(b, 65), T(a, 65));
    X(this, "mv", T(b, 66), T(a, 66));
    X(this, "id", T(b, 70), T(a, 70));
    W(this, "ic", R(b, 71), !0);
    X(this, "pg", U(b, 72), U(a, 72));
    X(this, "mo", T(b, 73), T(a, 73));
    X(this, "al", T(b, 74), T(a, 74));
    W(this, "iv", R(b, 75), R(a, 75));
    W(this, "pi", Gi(b, 76), Gi(a, 76));
    W(this, "ya", Gi(b, 77), Gi(a, 77));
    W(this, "ro", Gi(b, 78), Gi(a, 78));
    W(this, "fo", Gi(b, 79), Gi(a, 79));
    X(this, "df", T(b, 80), T(a, 80));
    sk(this, "mm", R(b, 81), R(a, 81));
    X(this, "sg", T(b, 82), T(a, 82));
    X(this, "gd", T(b, 83), T(a, 83));
    X(this, "fm", T(b, 84), T(a, 84));
    W(this, "ba", R(b, 85), R(a, 85));
    W(this, "br", R(b, 86), R(a, 86));
    W(this, "bc", R(b, 87), R(a, 87), 16, 8);
    W(this, "pc", R(b, 88), R(a, 88), 16, 8);
    W(this, "sc", R(b, 89), R(a, 89), 16, 8);
    X(this, "dv", T(b, 90), T(a, 90));
    X(this, "md", T(b, 91), T(a, 91));
    W(this, "cp", R(b, 92), R(a, 92));
    X(this, "sm", T(b, 93), T(a, 93));
    W(this, "cv", R(b, 94), R(a, 94));
    X(this, "ng", T(b, 95), T(a, 95));
    X(this, "il", T(b, 96), T(a, 96));
    X(this, "lo", T(b, 97), T(a, 97));
    X(this, "vm", T(b, 98), T(a, 98));
    sk(this, "dc", R(b, 99), R(a, 99));
    X(this, "rf", T(b, 100), T(a, 100));
    sk(this, "vf", R(b, 102), R(a, 102));
    return this.F.join("-");
  };
  function W(a, b, c, d, e, f) {
    if (null != c) {
      var g = void 0 == e || (10 != e && 16 != e) ? 10 : e;
      c = c.toString(g);
      e = new nk();
      e.D(16 == g ? "0x" : "");
      g = e.D;
      void 0 == f
        ? (f = "")
        : ((f -= c.length), (f = 0 >= f ? "" : Xe("0", f)));
      g.call(e, f);
      e.D(c);
      tk(a, b, e.toString(), !!d);
    }
  }
  function X(a, b, c, d) {
    c && tk(a, b, "", !!d);
  }
  function sk(a, b, c, d) {
    c && tk(a, b, c, !!d);
  }
  function tk(a, b, c, d) {
    d && (b = b.substring(0, 1).toUpperCase() + b.substring(1));
    a.F.push(b + c);
  }
  function Y(a) {
    ok.call(this, a);
  }
  A(Y, ok);
  t = Y.prototype;
  t.ob = function (a) {
    a && uk(this);
    return Y.O.ob.call(this, a);
  };
  t.Sa = function (a) {
    a = null == a || 0 > a ? void 0 : a;
    null != a && this.Ca();
    return Y.O.Sa.call(this, a);
  };
  t.pb = function (a) {
    a && uk(this);
    return Y.O.pb.call(this, a);
  };
  t.nb = function (a) {
    a && uk(this);
    return Y.O.nb.call(this, a);
  };
  t.Ca = function (a) {
    Ub(a) && (a = Math.max(a.width, a.height));
    a = null == a || 0 > a ? void 0 : a;
    null != a && (this.Ta(), this.Sa());
    return Y.O.Ca.call(this, a);
  };
  t.rb = function (a) {
    a && uk(this);
    return Y.O.rb.call(this, a);
  };
  t.sb = function (a) {
    a && uk(this);
    return Y.O.sb.call(this, a);
  };
  t.tb = function (a) {
    a && uk(this);
    return Y.O.tb.call(this, a);
  };
  t.mb = function (a) {
    a && uk(this);
    return Y.O.mb.call(this, a);
  };
  t.qb = function (a) {
    a && uk(this);
    return Y.O.qb.call(this, a);
  };
  t.Ta = function (a) {
    a = null == a || 0 > a ? void 0 : a;
    null != a && this.Ca();
    return Y.O.Ta.call(this, a);
  };
  function uk(a) {
    a.mb();
    a.nb();
    a.ob();
    a.pb();
    a.qb();
    a.rb();
    a.sb();
    a.tb();
  }
  t.ra = function () {
    var a = this.D.C;
    T(a, 18) || T(a, 45)
      ? R(a, 1) || this.Ca(0)
      : ((a = this.D.C),
        R(a, 1) ||
          R(a, 12) ||
          R(a, 13) ||
          (this.Ca(), this.Sa(), this.Ta(), uk(this)));
    return Y.O.ra.call(this);
  };
  var vk = /^[^\/]*\/\//;
  function wk(a, b) {
    b = void 0 === b ? !1 : b;
    this.G = a;
    this.M = "";
    (a = this.G.match(vk)) && a[0]
      ? ((this.M = a[0]),
        (a = this.M.match(/\w+/)
          ? this.G
          : "http://" + this.G.substring(this.M.length)))
      : (a = "http://" + this.G);
    this.D = Zi(a, !0);
    this.Y = b;
    this.J = !0;
    this.sa = !1;
  }
  function xk(a, b) {
    a.F = a.F ? a.F + ("/" + b) : b;
  }
  function yk(a) {
    if (void 0 == a.C) {
      var b = a.D.D.substring(1);
      a.F = null;
      if (a.Y) {
        a.C = [];
        if (1 < (b.match(/=/g) || []).length) return (a.J = !1), a.C;
        var c = b.indexOf("=");
        -1 != c
          ? (a.C.push(b.substr(0, c)), a.C.push(b.substr(c + 1)))
          : a.C.push(b);
        return a.C;
      }
      a.C = b.split("/");
      b = a.C.length;
      2 < b &&
        "u" == a.C[0] &&
        (xk(a, a.C[0] + "/" + a.C[1]), a.C.shift(), a.C.shift(), (b -= 2));
      if (0 == b || 4 == b || 7 < b) return (a.J = !1), a.C;
      if (2 == b) xk(a, a.C[0]);
      else if ("image" == a.C[0]) xk(a, a.C[0]);
      else if (7 == b || 3 == b) return (a.J = !1), a.C;
      if (3 >= b) {
        a.sa = !0;
        3 == b && (xk(a, a.C[1]), a.C.shift(), --b);
        --b;
        c = a.C[b];
        var d = c.indexOf("=");
        -1 != d && ((a.C[b] = c.substr(0, d)), a.C.push(c.substr(d + 1)));
      }
    }
    return a.C;
  }
  wk.prototype.K = function () {
    yk(this);
    return this.J;
  };
  function zk(a) {
    yk(a);
    return a.sa;
  }
  function Ak(a) {
    yk(a);
    return a.Y;
  }
  function Bk(a) {
    yk(a);
    void 0 == a.F && (a.F = null);
    return a.F;
  }
  function Ck(a) {
    switch (yk(a).length) {
      case 7:
        return !0;
      case 6:
        return null == Bk(a);
      case 5:
        return !1;
      case 3:
        return !0;
      case 2:
        return null == Bk(a);
      case 1:
        return !1;
      default:
        return !1;
    }
  }
  function Dk(a, b) {
    if (Ak(a))
      a: {
        switch (b) {
          case 7:
            b = 0;
            break;
          case 4:
            if (!Ck(a)) {
              a = null;
              break a;
            }
            b = 1;
            break;
          default:
            a = null;
            break a;
        }
        a = yk(a)[b];
      }
    else if (zk(a))
      a: {
        var c = null != Bk(a) ? 1 : 0;
        switch (b) {
          case 6:
            b = 0 + c;
            break;
          case 4:
            if (!Ck(a)) {
              a = null;
              break a;
            }
            b = 1 + c;
            break;
          default:
            a = null;
            break a;
        }
        a = yk(a)[b];
      }
    else
      a: {
        c = null != Bk(a) ? 1 : 0;
        switch (b) {
          case 0:
            b = 0 + c;
            break;
          case 1:
            b = 1 + c;
            break;
          case 2:
            b = 2 + c;
            break;
          case 3:
            b = 3 + c;
            break;
          case 4:
            if (!Ck(a)) {
              a = null;
              break a;
            }
            b = 4 + c;
            break;
          case 5:
            b = Ck(a) ? 1 : 0;
            b = 4 + c + b;
            break;
          default:
            a = null;
            break a;
        }
        a = yk(a)[b];
      }
    return a;
  }
  function Ek(a) {
    void 0 == a.Ea && (a.Ea = Dk(a, 4));
    return a.Ea;
  }
  function Fk() {}
  Fk.prototype.parse = function (a, b) {
    return new Gk(a, void 0 === b ? !1 : b);
  };
  function Gk(a, b) {
    wk.call(this, a, void 0 === b ? !1 : b);
  }
  v(Gk, wk);
  function Hk(a, b) {
    b = void 0 === b ? !1 : b;
    this.C = null;
    a instanceof Gk ||
      (void 0 == Ik && (Ik = new Fk()), (a = Ik.parse(a.toString(), b)));
    a = this.C = a;
    void 0 == a.L && ((b = Ek(a)) || (b = ""), (a.L = new gk().parse(b)));
    ok.call(this, a.L);
    this.L = this.C.M;
    a = this.C;
    b = a.D.M;
    this.M = a.D.F + (b ? ":" + b : "");
    this.J = this.C.D.C.toString();
  }
  var Ik;
  A(Hk, Y);
  function Jk(a) {
    a.J = "";
    return a;
  }
  Hk.prototype.K = function () {
    return this.C.K();
  };
  Hk.prototype.ra = function () {
    if (!this.C.K()) return this.C.G;
    var a = Hk.O.ra.call(this),
      b = [];
    null != Bk(this.C) && b.push(Bk(this.C));
    var c = Ak(this.C);
    if (zk(this.C)) {
      var d = this.C;
      void 0 == d.Z && (d.Z = Dk(d, 6));
      b.push(d.Z + (a ? "=" + a : ""));
    } else if (c) {
      d = b.push;
      var e = this.C;
      void 0 === e.T && (e.T = Dk(e, 7));
      d.call(b, e.T);
      a && b.push(a);
    } else
      (d = b.push),
        (e = this.C),
        void 0 == e.da && (e.da = Dk(e, 0)),
        d.call(b, e.da),
        (d = b.push),
        (e = this.C),
        void 0 == e.Fa && (e.Fa = Dk(e, 1)),
        d.call(b, e.Fa),
        (d = b.push),
        (e = this.C),
        void 0 == e.ha && (e.ha = Dk(e, 2)),
        d.call(b, e.ha),
        (d = b.push),
        (e = this.C),
        void 0 == e.Ga && (e.Ga = Dk(e, 3)),
        d.call(b, e.Ga),
        a && b.push(a),
        (a = b.push),
        (d = this.C),
        void 0 == d.R && (d.R = Dk(d, 5)),
        a.call(b, d.R);
    b = Zi(
      this.L +
        this.M +
        "/" +
        (c ? b.join("=") : b.join("/")) +
        (this.J ? "?" + this.J : "")
    ).toString();
    b.startsWith("%3a//") && (b = b.replace("%3a//", "://"));
    return b;
  };
  var Kk = new Fk();
  var Lk = RegExp(
      "^((?:https?:)?//((?:blogger\\.googleusercontent\\.com|blogger-image(?:-(?:dev|staging|autopush|prod))?\\.corp\\.google\\.com))/img/(a))/([^/=?]+)(?:=([-a-zA-Z0-9_=]+))?(?:\\?[^/]*)?$"
    ),
    Mk = RegExp(
      "^((?:https?:)?//((?:blogger\\.googleusercontent\\.com|blogger-image(?:-(?:dev|staging|autopush|prod))?\\.corp\\.google\\.com))/img/(proxy))/([^/=?]+)(?:=([-a-zA-Z0-9_=]+))?(?:\\?[^/]*)?$"
    ),
    Nk = RegExp(
      "^((?:https?:)?//((?:blogger\\.googleusercontent\\.com|blogger-image(?:-(?:dev|staging|autopush|prod))?\\.corp\\.google\\.com)))/img/(b)/[^/?]*/([^/=?]+)/(?:([-a-zA-Z0-9_=]+)?/(?:[^/?]*)?)?(?:\\?[^/]*)?$"
    ),
    Ok = { qc: 3, proxy: 3, rc: 3 },
    Pk = { qc: 4, proxy: 4, rc: 4 };
  function Qk(a) {
    return Lk.test(a) || Mk.test(a) || Nk.test(a);
  }
  function Rk(a) {
    return "/blogger/image/" + Sk(a, Ok) + "/" + Sk(a, Pk);
  }
  function Sk(a, b) {
    if (Lk.test(a)) {
      var c;
      return null != (c = Lk.exec(a)[b.qc]) ? c : "";
    }
    if (Mk.test(a)) {
      var d;
      return null != (d = Mk.exec(a)[b.proxy]) ? d : "";
    }
    if (Nk.test(a)) {
      var e;
      return null != (e = Nk.exec(a)[b.rc]) ? e : "";
    }
    throw Error("Not a blogger image url: " + a);
  }
  function Tk() {
    var a = Uk,
      b = "xa";
    if (a.xa && a.hasOwnProperty(b)) return a.xa;
    var c = new a();
    a.xa = c;
    a.hasOwnProperty(b);
    return c;
  }
  function Uk() {
    this.F = null;
    this.C = {};
    this.D = !1;
  }
  Uk.prototype.init = function (a, b) {
    var c = Ne(a);
    Pg.Za().init(a, c);
    this.G = b;
  };
  Uk.prototype.J = function (a, b, c) {
    c.ctrlKey ||
      c.altKey ||
      c.shiftKey ||
      c.metaKey ||
      ((a = this.C[a]) &&
        0 < a.length &&
        (Vk(this), Sg()(a, b), c.preventDefault()));
  };
  Uk.prototype.K = function () {
    Vk(this);
    Qg(function () {});
  };
  function Vk(a) {
    a.D ||
      (document.body.appendChild(
        ef("LINK", { type: "text/css", rel: "stylesheet", href: a.G })
      ),
      (a.D = !0));
  }
  function Wk() {
    this.D = {};
    this.C = 0;
    this.J = [];
    this.F = [];
    var a = this;
    this.K = function () {
      Xk(a);
    };
  }
  Wk.prototype.init = function () {
    for (
      var a = this.D, b = bf(document, "img", "delayLoad"), c = 0;
      c < b.length;
      c++
    )
      if ((b[c].style.display == p && (b[c].style.display = ""), 5 > c)) {
        var d = b[c];
        "" != d.longDesc && (d.src = d.longDesc);
      } else
        (d = b[c].id),
          "" == d && (d = "av-delay-tempId-" + c),
          (a[d] = { ac: b[c], key: d }),
          this.C++;
    0 != this.C &&
      ((this.L = L(window, "scroll", this.K)),
      (this.M = L(window, "resize", this.K)),
      Yk(this));
  };
  function Xk(a) {
    a.G && window.clearTimeout(a.G);
    a.G = window.setTimeout(function () {
      a.G = null;
      Yk(a);
    }, 100);
  }
  function Yk(a) {
    if (!(0 > a.C))
      if (0 == a.C) Vf(a.L), Vf(a.M), (a.C = -1);
      else {
        var b = !1,
          c;
        for (c in a.D) {
          a: {
            var d = a;
            var e = a.D[c],
              f = window.document;
            f = "CSS1Compat" == f.compatMode ? f.documentElement : f.body;
            f = new We(f.clientWidth, f.clientHeight).height;
            var g = e.ac;
            if (1 == g.nodeType) {
              try {
                var h = g.getBoundingClientRect();
              } catch (k) {
                h = { left: 0, top: 0, right: 0, bottom: 0 };
              }
              g = new Ve(h.left, h.top);
            } else
              (g = g.changedTouches ? g.changedTouches[0] : g),
                (g = new Ve(g.clientX, g.clientY));
            g = g.y;
            if (0 <= g && g <= f) d.J.push(e);
            else if (0 < g && g < Math.round(2.25 * f)) d.F.push(e);
            else if (0 > g && g > Math.round(-1.25 * f)) d.F.push(e);
            else {
              d = !1;
              break a;
            }
            d = !0;
          }
          d && (b = !0);
        }
        if (b) {
          b = a.J.concat(a.F);
          for (c = 0; c < b.length; c++)
            (h = b[c].ac),
              "" != h.longDesc && (h.src = h.longDesc),
              a.C--,
              delete a.D[b[c].key];
          a.J = [];
          a.F = [];
        }
      }
  }
  var Zk = !I && !vd();
  function $k(a) {
    if (/-[a-z]/.test(ya)) return null;
    if (Zk && a.dataset) {
      if (xd() && !(ya in a.dataset)) return null;
      a = a.dataset.commentId;
      return void 0 === a ? null : a;
    }
    return a.getAttribute(
      "data-" + ya.replace(/([A-Z])/g, "-$1").toLowerCase()
    );
  }
  var al = {};
  function bl(a) {
    if (I && !Ie(9)) return [0, 0, 0, 0];
    var b = al.hasOwnProperty(a) ? al[a] : null;
    if (b) return b;
    65536 < Object.keys(al).length && (al = {});
    var c = [0, 0, 0, 0],
      d = RegExp("\\\\[0-9A-Fa-f]{1,5}\\s", "g");
    b = cl(a, RegExp("\\\\[0-9A-Fa-f]{6}\\s?", "g"));
    b = cl(b, d);
    b = cl(b, /\\./g);
    b = b.replace(RegExp(":not\\(([^\\)]*)\\)", "g"), "     $1 ");
    b = b.replace(RegExp("{[^]*", "gm"), "");
    b = dl(b, c, RegExp("(\\[[^\\]]+\\])", "g"), 2);
    b = dl(b, c, RegExp("(#[^\\#\\s\\+>~\\.\\[:]+)", "g"), 1);
    b = dl(b, c, RegExp("(\\.[^\\s\\+>~\\.\\[:]+)", "g"), 2);
    b = dl(
      b,
      c,
      /(::[^\s\+>~\.\[:]+|:first-line|:first-letter|:before|:after)/gi,
      3
    );
    b = dl(b, c, /(:[\w-]+\([^\)]*\))/gi, 2);
    b = dl(b, c, /(:[^\s\+>~\.\[:]+)/g, 2);
    b = b.replace(/[\*\s\+>~]/g, " ");
    b = b.replace(/[#\.]/g, " ");
    dl(b, c, /([^\s\+>~\.\[:]+)/g, 3);
    b = c;
    return (al[a] = b);
  }
  function dl(a, b, c, d) {
    return a.replace(c, function (e) {
      b[d] += 1;
      return Array(e.length + 1).join(" ");
    });
  }
  function cl(a, b) {
    return a.replace(b, function (c) {
      return Array(c.length + 1).join("A");
    });
  }
  var el = {
      "* ARIA-CHECKED": !0,
      "* ARIA-COLCOUNT": !0,
      "* ARIA-COLINDEX": !0,
      "* ARIA-CONTROLS": !0,
      "* ARIA-DESCRIBEDBY": !0,
      "* ARIA-DISABLED": !0,
      "* ARIA-EXPANDED": !0,
      "* ARIA-GOOG-EDITABLE": !0,
      "* ARIA-HASPOPUP": !0,
      "* ARIA-HIDDEN": !0,
      "* ARIA-LABEL": !0,
      "* ARIA-LABELLEDBY": !0,
      "* ARIA-MULTILINE": !0,
      "* ARIA-MULTISELECTABLE": !0,
      "* ARIA-ORIENTATION": !0,
      "* ARIA-PLACEHOLDER": !0,
      "* ARIA-READONLY": !0,
      "* ARIA-REQUIRED": !0,
      "* ARIA-ROLEDESCRIPTION": !0,
      "* ARIA-ROWCOUNT": !0,
      "* ARIA-ROWINDEX": !0,
      "* ARIA-SELECTED": !0,
      "* ABBR": !0,
      "* ACCEPT": !0,
      "* ACCESSKEY": !0,
      "* ALIGN": !0,
      "* ALT": !0,
      "* AUTOCOMPLETE": !0,
      "* AXIS": !0,
      "* BGCOLOR": !0,
      "* BORDER": !0,
      "* CELLPADDING": !0,
      "* CELLSPACING": !0,
      "* CHAROFF": !0,
      "* CHAR": !0,
      "* CHECKED": !0,
      "* CLEAR": !0,
      "* COLOR": !0,
      "* COLSPAN": !0,
      "* COLS": !0,
      "* COMPACT": !0,
      "* COORDS": !0,
      "* DATETIME": !0,
      "* DIR": !0,
      "* DISABLED": !0,
      "* ENCTYPE": !0,
      "* FACE": !0,
      "* FRAME": !0,
      "* HEIGHT": !0,
      "* HREFLANG": !0,
      "* HSPACE": !0,
      "* ISMAP": !0,
      "* LABEL": !0,
      "* LANG": !0,
      "* MAX": !0,
      "* MAXLENGTH": !0,
      "* METHOD": !0,
      "* MULTIPLE": !0,
      "* NOHREF": !0,
      "* NOSHADE": !0,
      "* NOWRAP": !0,
      "* OPEN": !0,
      "* READONLY": !0,
      "* REQUIRED": !0,
      "* REL": !0,
      "* REV": !0,
      "* ROLE": !0,
      "* ROWSPAN": !0,
      "* ROWS": !0,
      "* RULES": !0,
      "* SCOPE": !0,
      "* SELECTED": !0,
      "* SHAPE": !0,
      "* SIZE": !0,
      "* SPAN": !0,
      "* START": !0,
      "* SUMMARY": !0,
      "* TABINDEX": !0,
      "* TITLE": !0,
      "* TYPE": !0,
      "* VALIGN": !0,
      "* VALUE": !0,
      "* VSPACE": !0,
      "* WIDTH": !0,
    },
    fl = {
      "* USEMAP": !0,
      "* ACTION": !0,
      "* CITE": !0,
      "* HREF": !0,
      "* LONGDESC": !0,
      "* SRC": !0,
      "LINK HREF": !0,
      "* FOR": !0,
      "* HEADERS": !0,
      "* NAME": !0,
      "A TARGET": !0,
      "* CLASS": !0,
      "* ID": !0,
      "* STYLE": !0,
    };
  var gl = {
      rgb: !0,
      rgba: !0,
      alpha: !0,
      rect: !0,
      image: !0,
      "linear-gradient": !0,
      "radial-gradient": !0,
      "repeating-linear-gradient": !0,
      "repeating-radial-gradient": !0,
      "cubic-bezier": !0,
      matrix: !0,
      perspective: !0,
      rotate: !0,
      rotate3d: !0,
      rotatex: !0,
      rotatey: !0,
      steps: !0,
      rotatez: !0,
      scale: !0,
      scale3d: !0,
      scalex: !0,
      scaley: !0,
      scalez: !0,
      skew: !0,
      skewx: !0,
      skewy: !0,
      translate: !0,
      translate3d: !0,
      translatex: !0,
      translatey: !0,
      translatez: !0,
    },
    hl = /[\n\f\r"'()*<>]/g,
    il = {
      "\n": "%0a",
      "\f": "%0c",
      "\r": "%0d",
      '"': "%22",
      "'": "%27",
      "(": "%28",
      ")": "%29",
      "*": "%2a",
      "<": "%3c",
      ">": "%3e",
    };
  function jl(a) {
    return il[a];
  }
  function kl(a, b, c) {
    b = B(b);
    if ("" == b) return null;
    var d = String(b.slice(0, 4)).toLowerCase();
    if (0 == ("url(" < d ? -1 : "url(" == d ? 0 : 1)) {
      if (
        !b.endsWith(")") ||
        1 < (b ? b.split("(").length - 1 : 0) ||
        1 < (b ? b.split(")").length - 1 : 0) ||
        !c
      )
        a = null;
      else {
        a: for (b = b.substring(4, b.length - 1), d = 0; 2 > d; d++) {
          var e = "\"'".charAt(d);
          if (b.charAt(0) == e && b.charAt(b.length - 1) == e) {
            b = b.substring(1, b.length - 1);
            break a;
          }
        }
        a = c
          ? (a = c(b, a)) && Yc(a) != qa
            ? 'url("' + Yc(a).replace(hl, jl) + '")'
            : null
          : null;
      }
      return a;
    }
    if (0 < b.indexOf("(")) {
      if (/"|'/.test(b)) return null;
      for (a = /([\-\w]+)\(/g; (c = a.exec(b)); )
        if (!(c[1].toLowerCase() in gl)) return null;
    }
    return b;
  }
  function ll(a, b) {
    a = x[a];
    return a && a.prototype
      ? ((b = Object.getOwnPropertyDescriptor(a.prototype, b)) && b.get) || null
      : null;
  }
  function ml(a, b) {
    return ((a = x[a]) && a.prototype && a.prototype[b]) || null;
  }
  var nl = ll(fa, sa) || ll(ia, sa),
    ol = ml(fa, Va),
    pl = ml(fa, Sa),
    ql = ml(fa, hb),
    rl = ml(fa, fb);
  ll(fa, "innerHTML") || ll("HTMLElement", "innerHTML");
  var sl = ml(fa, Ta),
    tl = ml(fa, "matches") || ml(fa, ab),
    ul = ll(ia, "nodeName"),
    vl = ll(ia, "nodeType"),
    wl = ll(ia, "parentNode");
  ll(ia, "childNodes");
  var xl = ll("HTMLElement", kb) || ll(fa, kb),
    yl = ll("HTMLStyleElement", "sheet"),
    zl = ml(ca, Ua),
    Al = ml(ca, "setProperty"),
    Bl = ll(fa, bb) || ll(ia, bb);
  function Cl(a, b, c, d) {
    if (a) return a.apply(b);
    a = b[c];
    if (!d(a)) throw Error(da);
    return a;
  }
  function Dl(a, b, c, d) {
    if (a) return a.apply(b, d);
    if (I && 10 > document.documentMode) {
      if (!b[c].call) throw Error("IE Clobbering detected");
    } else if (typeof b[c] != m) throw Error(da);
    return b[c].apply(b, d);
  }
  function El(a) {
    return Cl(nl, a, sa, function (b) {
      return b instanceof NamedNodeMap;
    });
  }
  function Fl(a, b, c) {
    try {
      Dl(ql, a, hb, [b, c]);
    } catch (d) {
      if (-1 == d.message.indexOf("A security problem occurred")) throw d;
    }
  }
  function Gl(a) {
    return Cl(xl, a, kb, function (b) {
      return b instanceof CSSStyleDeclaration;
    });
  }
  function Hl(a) {
    return Cl(yl, a, "sheet", function (b) {
      return b instanceof CSSStyleSheet;
    });
  }
  function Il(a) {
    return Cl(ul, a, "nodeName", function (b) {
      return typeof b == r;
    });
  }
  function Jl(a) {
    return Cl(vl, a, "nodeType", function (b) {
      return typeof b == cb;
    });
  }
  function Kl(a) {
    return Cl(wl, a, "parentNode", function (b) {
      return !(
        b &&
        typeof b.name == r &&
        b.name &&
        "parentnode" == b.name.toLowerCase()
      );
    });
  }
  function Ll(a, b) {
    return Dl(zl, a, a.getPropertyValue ? Ua : Sa, [b]) || "";
  }
  function Ml(a, b, c) {
    Dl(Al, a, a.setProperty ? "setProperty" : hb, [b, c]);
  }
  function Nl(a) {
    return Cl(Bl, a, bb, function (b) {
      return typeof b == r;
    });
  }
  var Ol =
      I && 10 > document.documentMode
        ? null
        : RegExp(
            "\\s*([^\\s'\",]+[^'\",]*(('([^'\\r\\n\\f\\\\]|\\\\[^])*')|(\"([^\"\\r\\n\\f\\\\]|\\\\[^])*\")|[^'\",])*)",
            "g"
          ),
    Pl = {
      "-webkit-border-horizontal-spacing": !0,
      "-webkit-border-vertical-spacing": !0,
    };
  function Ql(a, b, c) {
    var d = [];
    Rl(nc(a.cssRules)).forEach(function (e) {
      if (b && !/[a-zA-Z][\w-:\.]*/.test(b))
        throw Error("Invalid container id");
      if (
        !(
          b &&
          I &&
          10 == document.documentMode &&
          /\\['"]/.test(e.selectorText)
        )
      ) {
        var f = b
            ? e.selectorText.replace(Ol, "#" + b + " $1")
            : e.selectorText,
          g = d.push;
        e = Sl(e.style, c);
        if (-1 != f.indexOf("<"))
          throw Error("Selector does not allow '<', got: " + f);
        var h = f.replace(/('|")((?!\1)[^\r\n\f\\]|\\[\s\S])*\1/g, "");
        if (!/^[-_a-zA-Z0-9#.:* ,>+~[\]()=^$|]+$/.test(h))
          throw Error(
            "Selector allows only [-_a-zA-Z0-9#.:* ,>+~[\\]()=^$|] and strings, got: " +
              f
          );
        a: {
          for (
            var k = { "(": ")", "[": "]" }, n = [], u = 0;
            u < h.length;
            u++
          ) {
            var w = h[u];
            if (k[w]) n.push(k[w]);
            else if (tc(k, w) && n.pop() != w) {
              h = !1;
              break a;
            }
          }
          h = 0 == n.length;
        }
        if (!h)
          throw Error("() and [] in selector must be balanced, got: " + f);
        e instanceof dd || (e = fd(e));
        f = f + "{" + ed(e).replace(/</g, "\\3C ") + "}";
        g.call(d, new pd(f, od));
      }
    });
    return qd(d);
  }
  function Rl(a) {
    return a.filter(function (b) {
      return b instanceof CSSStyleRule || b.type == CSSRule.STYLE_RULE;
    });
  }
  function Tl(a, b, c) {
    a = Ul("<style>" + a + "</style>");
    return null == a || null == a.sheet
      ? sd
      : Ql(a.sheet, void 0 != b ? b : null, c);
  }
  function Ul(a) {
    if ((I && !Ie(10)) || typeof x.DOMParser != m) return null;
    a = F("<html><head></head><body>" + a + "</body></html>");
    return new DOMParser().parseFromString(Bd(a), "text/html").body.children[0];
  }
  function Sl(a, b) {
    if (!a) return hd;
    var c = document.createElement(l).style;
    Vl(a).forEach(function (d) {
      var e =
        Be && d in Pl
          ? d
          : d.replace(
              /^-(?:apple|css|epub|khtml|moz|mso?|o|rim|wap|webkit|xv)-(?=[a-z])/i,
              ""
            );
      Nc(e, "--") ||
        Nc(e, "var") ||
        ((d = Ll(a, d)), (d = kl(e, d, b)), null != d && Ml(c, e, d));
    });
    return new dd(c.cssText || "", cd);
  }
  function Wl(a) {
    var b = Array.from(Dl(sl, a, Ta, [ka])),
      c = pc(b, function (g) {
        return nc(Hl(g).cssRules);
      });
    c = Rl(c);
    for (var d = [], e = 0; e < c.length; e++) d[e] = { index: e, Fb: c[e] };
    d.sort(function (g, h) {
      var k = bl(g.Fb.selectorText),
        n = bl(h.Fb.selectorText);
      a: {
        for (var u = Math.min(k.length, n.length), w = 0; w < u; w++) {
          var G = k[w],
            D = n[w];
          G = G > D ? 1 : G < D ? -1 : 0;
          if (0 != G) {
            n = G;
            break a;
          }
        }
        k = k.length;
        n = n.length;
        n = k > n ? 1 : k < n ? -1 : 0;
      }
      return n || g.index - h.index;
    });
    for (e = 0; e < d.length; e++) c[e] = d[e].Fb;
    c.reverse();
    a = document.createTreeWalker(a, NodeFilter.SHOW_ELEMENT, null, !1);
    for (var f; (f = a.nextNode()); )
      c.forEach(function (g) {
        Dl(tl, f, f.matches ? "matches" : ab, [g.selectorText]) &&
          g.style &&
          Xl(f, g.style);
      });
    b.forEach(kf);
  }
  function Xl(a, b) {
    var c = Vl(a.style);
    Vl(b).forEach(function (d) {
      if (!(0 <= c.indexOf(d))) {
        var e = Ll(b, d);
        Ml(a.style, d, e);
      }
    });
  }
  function Vl(a) {
    Tb(a) ? (a = nc(a)) : ((a = sc(a)), lc(a, "cssText"));
    return a;
  }
  var Yl =
      "undefined" != typeof WeakMap &&
      -1 != WeakMap.toString().indexOf("[native code]"),
    Zl = 0;
  function $l() {
    this.F = [];
    this.D = [];
    this.C = "data-elementweakmap-index-" + Zl++;
  }
  $l.prototype.set = function (a, b) {
    if (Dl(ol, a, Va, [this.C])) {
      var c = parseInt(Dl(pl, a, Sa, [this.C]) || null, 10);
      this.D[c] = b;
    } else
      (c = this.D.push(b) - 1), Fl(a, this.C, c.toString()), this.F.push(a);
    return this;
  };
  $l.prototype.get = function (a) {
    if (Dl(ol, a, Va, [this.C]))
      return (a = parseInt(Dl(pl, a, Sa, [this.C]) || null, 10)), this.D[a];
  };
  $l.prototype.clear = function () {
    this.F.forEach(function (a) {
      Dl(rl, a, fb, [this.C]);
    }, this);
    this.F = [];
    this.D = [];
  };
  var am;
  (am = !I) || (am = 10 <= Number(Le));
  var bm = am,
    cm = !I || null == document.documentMode;
  function dm() {}
  var em = {
    APPLET: !0,
    AUDIO: !0,
    BASE: !0,
    BGSOUND: !0,
    EMBED: !0,
    FORM: !0,
    IFRAME: !0,
    ISINDEX: !0,
    KEYGEN: !0,
    LAYER: !0,
    LINK: !0,
    META: !0,
    OBJECT: !0,
    SCRIPT: !0,
    SVG: !0,
    STYLE: !0,
    TEMPLATE: !0,
    VIDEO: !0,
  };
  var fm = {
    A: !0,
    ABBR: !0,
    ACRONYM: !0,
    ADDRESS: !0,
    AREA: !0,
    ARTICLE: !0,
    ASIDE: !0,
    B: !0,
    BDI: !0,
    BDO: !0,
    BIG: !0,
    BLOCKQUOTE: !0,
    BR: !0,
    BUTTON: !0,
    CAPTION: !0,
    CENTER: !0,
    CITE: !0,
    CODE: !0,
    COL: !0,
    COLGROUP: !0,
    DATA: !0,
    DATALIST: !0,
    DD: !0,
    DEL: !0,
    DETAILS: !0,
    DFN: !0,
    DIALOG: !0,
    DIR: !0,
    DIV: !0,
    DL: !0,
    DT: !0,
    EM: !0,
    FIELDSET: !0,
    FIGCAPTION: !0,
    FIGURE: !0,
    FONT: !0,
    FOOTER: !0,
    FORM: !0,
    H1: !0,
    H2: !0,
    H3: !0,
    H4: !0,
    H5: !0,
    H6: !0,
    HEADER: !0,
    HGROUP: !0,
    HR: !0,
    I: !0,
    IMG: !0,
    INPUT: !0,
    INS: !0,
    KBD: !0,
    LABEL: !0,
    LEGEND: !0,
    LI: !0,
    MAIN: !0,
    MAP: !0,
    MARK: !0,
    MENU: !0,
    METER: !0,
    NAV: !0,
    NOSCRIPT: !0,
    OL: !0,
    OPTGROUP: !0,
    OPTION: !0,
    OUTPUT: !0,
    P: !0,
    PRE: !0,
    PROGRESS: !0,
    Q: !0,
    S: !0,
    SAMP: !0,
    SECTION: !0,
    SELECT: !0,
    SMALL: !0,
    SOURCE: !0,
    SPAN: !0,
    STRIKE: !0,
    STRONG: !0,
    STYLE: !0,
    SUB: !0,
    SUMMARY: !0,
    SUP: !0,
    TABLE: !0,
    TBODY: !0,
    TD: !0,
    TEXTAREA: !0,
    TFOOT: !0,
    TH: !0,
    THEAD: !0,
    TIME: !0,
    TR: !0,
    TT: !0,
    U: !0,
    UL: !0,
    VAR: !0,
    WBR: !0,
  };
  var gm = {
    "ANNOTATION-XML": !0,
    "COLOR-PROFILE": !0,
    "FONT-FACE": !0,
    "FONT-FACE-SRC": !0,
    "FONT-FACE-URI": !0,
    "FONT-FACE-FORMAT": !0,
    "FONT-FACE-NAME": !0,
    "MISSING-GLYPH": !0,
  };
  function hm(a) {
    a = a || new im();
    jm(a);
    this.D = vc(a.C);
    this.K = vc(a.Z);
    this.F = vc(a.G);
    this.R = a.ha;
    a.sa.forEach(function (b) {
      if (!Nc(b, "data-"))
        throw new dc('Only "data-" attributes allowed, got: %s.', [b]);
      if (Nc(b, Ja))
        throw new dc('Attributes with "%s" prefix are not allowed, got: %s.', [
          Ja,
          b,
        ]);
      this.D["* " + b.toUpperCase()] = km;
    }, this);
    a.da.forEach(function (b) {
      b = b.toUpperCase();
      if (-1 == b.indexOf("-") || gm[b])
        throw new dc("Only valid custom element tag names allowed, got: %s.", [
          b,
        ]);
      this.F[b] = !0;
    }, this);
    this.L = a.F;
    this.J = a.Y;
    this.G = null;
    this.M = a.T;
  }
  A(hm, dm);
  function lm(a) {
    return function (b, c) {
      return (b = a(B(b), c)) && Yc(b) != qa ? Yc(b) : null;
    };
  }
  function im() {
    this.C = {};
    fc(
      [el, fl],
      function (a) {
        sc(a).forEach(function (b) {
          this.C[b] = km;
        }, this);
      },
      this
    );
    this.D = {};
    this.sa = [];
    this.da = [];
    this.Z = vc(em);
    this.G = vc(fm);
    this.ha = !1;
    this.R = ad;
    this.L = this.J = this.K = this.F = Oe;
    this.Y = null;
    this.M = this.T = !1;
  }
  function mm() {
    var a = new im();
    a.G = { SPAN: !0 };
    "a b br em i strong".split(" ").forEach(function (b) {
      b = b.toUpperCase();
      if (fm[b]) this.G[b] = !0;
      else
        throw Error(
          "Only whitelisted tags can be allowed. See goog.html.sanitizer.TagWhitelist."
        );
    }, a);
    return a;
  }
  function nm(a, b) {
    return function (c, d, e, f) {
      c = a(c, d, e, f);
      return null == c ? null : b(c, d, e, f);
    };
  }
  function om(a, b, c, d) {
    a[c] && !b[c] && (a[c] = nm(a[c], d));
  }
  function jm(a) {
    if (a.M)
      throw Error("HtmlSanitizer.Builder.build() can only be used once.");
    om(a.C, a.D, "* USEMAP", pm);
    var b = lm(a.R);
    ["* ACTION", "* CITE", "* HREF"].forEach(function (d) {
      om(this.C, this.D, d, b);
    }, a);
    var c = lm(a.F);
    ["* LONGDESC", "* SRC", "LINK HREF"].forEach(function (d) {
      om(this.C, this.D, d, c);
    }, a);
    ["* FOR", "* HEADERS", "* NAME"].forEach(function (d) {
      om(this.C, this.D, d, Zb(qm, this.K));
    }, a);
    om(a.C, a.D, "A TARGET", Zb(rm, [pa, "_self"]));
    om(a.C, a.D, "* CLASS", Zb(sm, a.J));
    om(a.C, a.D, "* ID", Zb(tm, a.J));
    om(a.C, a.D, "* STYLE", Zb(a.L, c));
    a.M = !0;
  }
  function um(a, b) {
    a || (a = "*");
    return (a + " " + b).toUpperCase();
  }
  function vm(a, b, c, d) {
    if (!d.Bb) return null;
    b = ed(
      Sl(d.Bb, function (e, f) {
        c.od = f;
        e = a(e, c);
        var g;
        null == e ? (g = null) : (g = new C(e, Xc));
        return g;
      })
    );
    return "" == b ? null : b;
  }
  function km(a) {
    return B(a);
  }
  function rm(a, b) {
    b = B(b);
    return jc(a, b.toLowerCase()) ? b : null;
  }
  function pm(a) {
    return (a = B(a)) && "#" == a.charAt(0) ? a : null;
  }
  function qm(a, b, c) {
    return a(B(b), c);
  }
  function sm(a, b, c) {
    b = b.split(/(?:\s+)/);
    for (var d = [], e = 0; e < b.length; e++) {
      var f = a(b[e], c);
      f && d.push(f);
    }
    return 0 == d.length ? null : d.join(" ");
  }
  function tm(a, b, c) {
    return a(B(b), c);
  }
  hm.prototype.C = function (a) {
    var b = !(ka in this.K) && ka in this.F;
    this.G =
      "*" == this.J && b
        ? "sanitizer-" +
          (Math.floor(2147483648 * Math.random()).toString(36) +
            Math.abs(
              Math.floor(2147483648 * Math.random()) ^ Date.now()
            ).toString(36))
        : this.J;
    if (bm) {
      b = a;
      if (bm) {
        a = gf(document, ja);
        this.G && "*" == this.J && (a.id = this.G);
        this.M && ((b = Ul("<div>" + b + "</div>")), Wl(b), (b = b.innerHTML));
        b = F(b);
        var c = document.createElement("template");
        if (cm && "content" in c) Se(c, b), (c = c.content);
        else {
          var d = document.implementation.createHTMLDocument("x");
          c = d.body;
          Se(d.body, b);
        }
        b = document.createTreeWalker(
          c,
          NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT,
          null,
          !1
        );
        for (c = Yl ? new WeakMap() : new $l(); (d = b.nextNode()); ) {
          c: {
            var e = d;
            switch (Jl(e)) {
              case 3:
                e = wm(this, e);
                break c;
              case 1:
                if ("TEMPLATE" == Il(e).toUpperCase()) e = null;
                else {
                  var f = Il(e).toUpperCase();
                  if (f in this.K || "http://www.w3.org/1999/xhtml" != Nl(e))
                    var g = null;
                  else
                    this.F[f]
                      ? (g = document.createElement(f))
                      : ((g = gf(document, ja)),
                        this.R &&
                          Fl(
                            g,
                            "data-sanitizer-original-tag",
                            f.toLowerCase()
                          ));
                  if (g) {
                    var h = g,
                      k = El(e);
                    if (null != k)
                      for (var n = 0; (f = k[n]); n++)
                        if (f.specified) {
                          var u = e;
                          var w = f;
                          var G = w.name;
                          if (Nc(G, Ja)) w = null;
                          else {
                            var D = Il(u);
                            w = w.value;
                            var P = {
                                tagName: B(D).toLowerCase(),
                                attributeName: B(G).toLowerCase(),
                              },
                              Of = { Bb: void 0 };
                            P.attributeName == kb && (Of.Bb = Gl(u));
                            u = um(D, G);
                            u in this.D
                              ? ((G = this.D[u]), (w = G(w, P, Of)))
                              : ((G = um(null, G)),
                                G in this.D
                                  ? ((G = this.D[G]), (w = G(w, P, Of)))
                                  : (w = null));
                          }
                          null !== w && Fl(h, f.name, w);
                        }
                    e = g;
                  } else e = null;
                }
                break c;
              default:
                e = null;
            }
          }
          if (e) {
            if ((1 == Jl(e) && c.set(d, e), (d = Kl(d)), (f = !1), d))
              (g = Jl(d)),
                (h = Il(d).toLowerCase()),
                (k = Kl(d)),
                11 != g || k
                  ? "body" == h && k && (g = Kl(k)) && !Kl(g) && (f = !0)
                  : (f = !0),
                (g = null),
                f || !d ? (g = a) : 1 == Jl(d) && (g = c.get(d)),
                g.content && (g = g.content),
                g.appendChild(e);
          } else jf(d);
        }
        c.clear && c.clear();
      } else a = gf(document, ja);
      0 < El(a).length && ((b = gf(document, ja)), b.appendChild(a), (a = b));
      a = new XMLSerializer().serializeToString(a);
      a = a.slice(a.indexOf(">") + 1, a.lastIndexOf("</"));
    } else a = "";
    return F(a);
  };
  function wm(a, b) {
    var c = b.data;
    (b = Kl(b)) &&
      Il(b).toLowerCase() == kb &&
      !(ka in a.K) &&
      ka in a.F &&
      (c = rd(
        Tl(
          c,
          a.G,
          y(function (d, e) {
            return this.L(d, { od: e });
          }, a)
        )
      ));
    return document.createTextNode(c);
  }
  function xm(a) {
    Q.call(this, "Blog", a);
    this.C = a.N;
    this.J = new hm(mm());
    if (this.C.data) {
      a = new ei();
      this.K = gi(a, "blog.canonicalUrl");
      if (this.C.data.lightboxEnabled) {
        var b = this.C.data.lightboxModuleUrl,
          c = this.C.data.lightboxCssUrl;
        Tk().init(b, c);
        b = bf(document, "DIV", "post-body", this.C.C);
        for (c = 0; c < b.length; c++) {
          for (
            var d = "fakeId" + ym++,
              e = Tk(),
              f = bf(document, "IMG", void 0, b[c]),
              g = f.length,
              h = [],
              k = 0;
            k < g;
            k++
          ) {
            var n = f[k].src,
              u = null,
              w = qf(f[k], "A");
            if (w) {
              w = w.href;
              var G = w;
              var D = n;
              if (Zj(G) && Zj(D)) {
                var P = new Fk();
                G = P.parse(G ? rk(Jk(new Hk(G, !1))).ra() : "");
                D = P.parse(D ? rk(Jk(new Hk(D, !1))).ra() : "");
                D = G.D.D == D.D.D;
              } else D = !1;
              D ||
                ((D = w), (P = n), (D = Qk(D) && Qk(P) ? Rk(D) === Rk(P) : !1));
              if (D) {
                if (
                  (w != n && (u = n),
                  (n = w),
                  !Qk(n) && (w = Ek(Kk.parse(n, !1))))
                )
                  (w = new gk().parse(w)),
                    (w = new Y(w)),
                    (D = ((D = void 0), void 0)),
                    (P = w.D.C),
                    D != U(P, 4) && S(P, 4, D),
                    (D = ((D = void 0), void 0)),
                    (P = w.D.C),
                    D != U(P, 6) && S(P, 6, D),
                    (w = w.ra()),
                    (n = new Hk(n, !1)),
                    pk(n, w),
                    (n = n.ra());
              } else if (w != n) continue;
              h.push({ imageUrl: n, thumbnailUrl: u });
              L(f[k], ua, y(e.J, e, d, h.length - 1));
            }
          }
          0 < h.length &&
            ((e.C[d] = h), e.F || (e.F = L(window, "load", e.K, !1, e)));
        }
      }
      this.C.data.mobile && (this.F = new Uj(gi(a, "blog.pageTitle"), this.K));
      this.G = this.D = null;
    }
  }
  v(xm, Q);
  t = xm.prototype;
  t.ka = function (a, b) {
    if ("getComments" == a) {
      if (b.comments && b.messages) {
        a = b.comments;
        for (var c = b.config, d = 0; d < a.length; d++)
          a: {
            var e = b,
              f = a[d];
            if (!document.getElementById("c" + f.id)) {
              f.author = this.J.C(f.author);
              f.body = this.J.C(f.body);
              var g = 1;
              if (f.inReplyTo) {
                var h = document.getElementById("c" + f.inReplyTo);
                if (h) {
                  var k;
                  g = h;
                  for (k = []; g; ) ue(g, "comment") && k.push(g), (g = lf(g));
                  g = k.length + 1;
                  k.length + 1 > e.config.maxDepth &&
                    ((h = qf(h.parentNode, null, "comment"))
                      ? (g--, (f.inReplyTo = h.id.slice(1)))
                      : (g = 1));
                }
              }
              h = document.getElementById("c" + f.inReplyTo + "-ra");
              if (!h && ((h = document.getElementById("top-ra")), !h)) break a;
              g = { config: e.config, xd: e.messages, ld: f, depth: g };
              k = Kj;
              e = cc || (cc = new sf());
              g = k(g || Jj, void 0);
              if (Ub(g))
                if (g instanceof jj) {
                  if (g.Yb !== gj)
                    throw Error("Sanitized content was not of kind HTML.");
                  g = F(g.toString());
                } else g = Cd("zSoyz");
              else g = Cd(String(g));
              e = e.D;
              k = g;
              g = gf(e, "DIV");
              I
                ? ((k = Hd(Ld, k)), Se(g, k), g.removeChild(g.firstChild))
                : Se(g, k);
              if (1 == g.childNodes.length) e = g.removeChild(g.firstChild);
              else
                for (e = e.createDocumentFragment(); g.firstChild; )
                  e.appendChild(g.firstChild);
              zm(this, e);
              h.appendChild(e);
              f.inReplyTo &&
                (f = document.getElementById("c" + f.inReplyTo + "-rt")) &&
                re(f, Wa);
            }
          }
        a.length < c.commentsPerPage
          ? ((this.D = null), pe(K("loadmore", this.C.C), Wa))
          : (this.D = a[a.length - 1].timestampAbs + 1);
      }
    } else Q.prototype.ka.call(this, a, b);
  };
  t.Yc = function (a) {
    var b = null,
      c = null;
    a = qf(a.currentTarget, null, "thread-toggle");
    ue(a, ob) ? ((b = nb), (c = ob)) : ((b = ob), (c = nb));
    fc(af(c, lf(a)), function (d) {
      te(d, c, b);
    });
  };
  t.Nc = function (a) {
    a = $k(a.currentTarget);
    Am(this, a || void 0);
  };
  function Am(a, b) {
    var c = document.getElementById(xa);
    if (c) {
      var d = Zi(c.src),
        e = b ? "c" + b : "top",
        f = document.getElementById(e + "-ce");
      f &&
        f !== lf(c) &&
        ((c.height = "250px"),
        (c.style.display = ta),
        (c.src = ""),
        f.appendChild(c),
        b ? d.C.set("parentID", b) : ej(d.C, "parentID"),
        (c.src = d.toString()));
      fc(af("continue", a.C.C), function (g) {
        re(g, Wa);
      });
      (a = document.getElementById(e + "-continue")) && pe(a, Wa);
    }
  }
  t.Gc = function () {
    this.G &&
      this.D &&
      this.H.Da(
        "getComments",
        { postId: this.G, publishedMin: this.D },
        function (a) {
          return 500 > ai(a);
        },
        ha
      );
  };
  t.ia = function () {
    if (this.C.data.mobile) {
      var a = J(xa),
        b = window.location.href.split("#");
      b[b.length - 1] && "comment-form" == b[b.length - 1]
        ? a && (a.style.display = ta)
        : a && (a.style.display = p);
      a = N(this.H, "comment-editor-toggle-link");
      null != a && (a.onclick = this.Xc);
      (a = J("mobile-share-button")) &&
        this.F &&
        (a.onclick = y(this.zd, this));
    }
    this.M = new Wk();
    this.M.init();
    zm(this, this.C.C);
    if ((a = K("loadmore", this.C.C))) {
      a.onclick = this.Gc.bind(this);
      if (Zk && a.dataset) b = a.dataset;
      else {
        b = {};
        for (var c = a.attributes, d = 0; d < c.length; ++d) {
          var e = c[d];
          if (Nc(e.name, "data-")) {
            var f = Ye(e.name.slice(5));
            b[f] = e.value;
          }
        }
      }
      b.publishedMin &&
        b.postId &&
        ((this.D = parseInt(b.publishedMin, 10) + 1),
        (this.G = b.postId),
        re(a, Wa));
    }
    Am(this);
  };
  function zm(a, b) {
    fc(
      af("thread-toggle", b),
      function (c) {
        c.onclick = this.Yc.bind(this);
        fc((c || document).getElementsByTagName("A"), function (d) {
          d.href = "javascript:;";
        });
      },
      a
    );
    fc(
      af("comment-reply", b),
      function (c) {
        c.onclick = this.Nc.bind(this);
        c.href = "javascript:;";
      },
      a
    );
  }
  t.zd = function () {
    this.F.ua ? this.F.show(!0) : this.F.render();
  };
  t.Xc = function () {
    var a = J(xa);
    a && (a.style.display = a.style.display == p ? ta : p);
    return !1;
  };
  var ym = 0;
  z("_BlogView", xm);
  function Bm(a) {
    Q.call(this, "BlogList", a);
  }
  v(Bm, Q);
  t = Bm.prototype;
  t.ia = function () {
    var a = this.H.N.data;
    this.Gb = a.totalItems;
    this.fb = a.numItemsToShow;
    0 != this.fb &&
      this.Gb > this.fb &&
      (($h(this.H, "show-all").onclick = this.oc.bind(this)),
      ($h(this.H, "show-n").onclick = this.oc.bind(this)));
    L(window, "load", this.Fc);
  };
  t.oc = function () {
    var a = N(this.H, "blogs");
    if (null != a) {
      a = a.getElementsByTagName("li");
      for (var b = this.fb; b < this.Gb; b++) {
        var c = a[b];
        c.style.display = c.style.display == p ? ta : p;
      }
      a = $h(this.H, "show-all");
      a.style.display = a.style.display == p ? "inline" : p;
      a = $h(this.H, "show-n");
      a.style.display = a.style.display == p ? "inline" : p;
    }
  };
  t.Fc = function () {
    for (var a = document.images.length, b = 0; b < a; b++) {
      var c = document.images[b],
        d = null;
      if ((d = c.getAttribute("data-lateloadsrc")))
        L(c, Pa, function () {
          this.style.visibility = Wa;
        }),
          (c.src = d);
    }
  };
  t.Gb = null;
  t.fb = null;
  z("_BlogListView", Bm);
  function Cm(a) {
    Q.call(this, "BlogSearch", a);
  }
  v(Cm, Q);
  z("_BlogSearchView", Cm);
  var Dm = RegExp(
    "^[+a-zA-Z0-9_.!#$%&'*\\/=?^`{|}~-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z0-9]{2,63}$"
  );
  function Em(a) {
    Q.call(this, "ContactForm", a);
    this.C = a.N;
    this.D = this.C.data;
  }
  A(Em, Q);
  z("_ContactFormView", Em);
  Em.prototype.ia = function () {
    var a = J(N(this.H, Fa));
    if (a) {
      var b = this;
      a.onclick = function () {
        Fm(b) && Gm(b);
      };
    }
  };
  function Fm(a) {
    J(N(a.H, Ca)).className = Ca;
    J(N(a.H, Ca)).textContent = "";
    J(N(a.H, Ga)).className = Ga;
    J(N(a.H, Ga)).textContent = "";
    var b = gf(document, "IMG");
    b.src =
      "https://resources.blogblog.com/img/widgets/icon_contactform_cross.gif";
    b.className = "contact-form-cross";
    b.onclick = function () {
      J(N(a.H, Ca)).className = Ca;
      J(N(a.H, Ca)).textContent = "";
    };
    var c = B(J(N(a.H, Aa)).value);
    if (!Dm.test(c))
      return (
        (J(N(a.H, Ca)).className = Da),
        (J(N(a.H, Ca)).innerHTML = a.D.contactFormInvalidEmailMsg),
        J(N(a.H, Ca)).appendChild(b),
        !1
      );
    c = J(N(a.H, Ba)).value;
    return null == c || "" == B(c)
      ? ((J(N(a.H, Ca)).className = Da),
        (J(N(a.H, Ca)).innerHTML = a.D.contactFormEmptyMessageMsg),
        J(N(a.H, Ca)).appendChild(b),
        !1)
      : !0;
  }
  function Gm(a) {
    J(N(a.H, Fa)).className =
      "contact-form-button contact-form-button-submit disabled";
    J(N(a.H, Fa)).disabled = !0;
    J(N(a.H, Ga)).className = Ha;
    J(N(a.H, Ga)).innerHTML = a.D.contactFormMessageSendingMsg;
    var b = encodeURIComponent(B(J(N(a.H, Ea)).value)),
      c = encodeURIComponent(B(J(N(a.H, Aa)).value)),
      d = encodeURIComponent(B(J(N(a.H, Ba)).value)),
      e = encodeURIComponent(a.D.blogId),
      f = encodeURIComponent(a.D.contactFormToken);
    b = [
      "name=" + b,
      "email=" + c,
      "message=" + d,
      "blogID=" + e,
      "token=" + f,
    ];
    c = a.D.submitUrl;
    if (window.XDomainRequest && 9 >= yd()) {
      var g = new XDomainRequest();
      g.onload = function () {
        var h = eval("(" + g.responseText + ")");
        h = eval(h.details.emailSentStatus);
        Hm(a, h);
      };
      g.open("post", c, !0);
      g.send(b.join("&"));
    } else gh(c, a.qd.bind(a), "POST", b.join("&"));
  }
  Em.prototype.qd = function (a) {
    a = a.target;
    var b = eval("(" + qh(a) + ")");
    b = eval(b.details.emailSentStatus);
    Hm(this, ph(a) && b);
  };
  function Hm(a, b) {
    J(N(a.H, Ga)).className = Ha;
    b
      ? ((J(N(a.H, Ea)).value = ""),
        (J(N(a.H, Aa)).value = ""),
        (J(N(a.H, Ba)).value = ""),
        (J(N(a.H, Ga)).innerHTML = a.D.contactFormMessageSentMsg))
      : (J(N(a.H, Ga)).innerHTML = a.D.contactFormMessageNotSentMsg);
    setTimeout(function () {
      J(N(a.H, Ga)).className = Ga;
      J(N(a.H, Ga)).textContent = "";
      J(N(a.H, Fa)).className =
        "contact-form-button contact-form-button-submit";
      J(N(a.H, Fa)).removeAttribute("disabled");
    }, 3e3);
  }
  function Im(a) {
    Q.call(this, "Example", a);
  }
  v(Im, Q);
  z("_ExampleView", Im);
  function Jm(a) {
    Q.call(this, "FeaturedPost", a);
  }
  v(Jm, Q);
  z("_FeaturedPostView", Jm);
  function Km() {} /*

 Copyright 2005, 2007 Bob Ippolito. All Rights Reserved.
 Copyright The Closure Library Authors.
 SPDX-License-Identifier: MIT
*/
  function Lm(a, b) {
    this.J = [];
    this.Y = a;
    this.ha = b || null;
    this.G = this.F = !1;
    this.D = void 0;
    this.R = this.Z = this.M = !1;
    this.K = 0;
    this.C = null;
    this.L = 0;
  }
  A(Lm, Km);
  Lm.prototype.cancel = function (a) {
    if (this.F) this.D instanceof Lm && this.D.cancel();
    else {
      if (this.C) {
        var b = this.C;
        delete this.C;
        a ? b.cancel(a) : (b.L--, 0 >= b.L && b.cancel());
      }
      this.Y ? this.Y.call(this.ha, this) : (this.R = !0);
      this.F || ((a = new Mm(this)), Nm(this), Om(this, !1, a));
    }
  };
  Lm.prototype.T = function (a, b) {
    this.M = !1;
    Om(this, a, b);
  };
  function Om(a, b, c) {
    a.F = !0;
    a.D = c;
    a.G = !b;
    Pm(a);
  }
  function Nm(a) {
    if (a.F) {
      if (!a.R) throw new Qm(a);
      a.R = !1;
    }
  }
  Lm.prototype.callback = function (a) {
    Nm(this);
    Om(this, !0, a);
  };
  function Rm(a, b, c, d) {
    a.J.push([b, c, d]);
    a.F && Pm(a);
  }
  Lm.prototype.then = function (a, b, c) {
    var d,
      e,
      f = new ug(function (g, h) {
        e = g;
        d = h;
      });
    Rm(
      this,
      e,
      function (g) {
        g instanceof Mm ? f.cancel() : d(g);
        return Sm;
      },
      this
    );
    return f.then(a, b, c);
  };
  Lm.prototype.$goog_Thenable = !0;
  function Tm(a) {
    return hc(a.J, function (b) {
      return typeof b[1] === m;
    });
  }
  var Sm = {};
  function Pm(a) {
    if (a.K && a.F && Tm(a)) {
      var b = a.K,
        c = Um[b];
      c && (x.clearTimeout(c.ga), delete Um[b]);
      a.K = 0;
    }
    a.C && (a.C.L--, delete a.C);
    b = a.D;
    for (var d = (c = !1); a.J.length && !a.M; ) {
      var e = a.J.shift(),
        f = e[0],
        g = e[1];
      e = e[2];
      if ((f = a.G ? g : f))
        try {
          var h = f.call(e || a.ha, b);
          h === Sm && (h = void 0);
          void 0 !== h &&
            ((a.G = a.G && (h == b || h instanceof Error)), (a.D = b = h));
          if (tg(b) || (typeof x.Promise === m && b instanceof x.Promise))
            (d = !0), (a.M = !0);
        } catch (k) {
          (b = k), (a.G = !0), Tm(a) || (c = !0);
        }
    }
    a.D = b;
    d &&
      ((h = y(a.T, a, !0)),
      (d = y(a.T, a, !1)),
      b instanceof Lm ? (Rm(b, h, d), (b.Z = !0)) : b.then(h, d));
    c && ((b = new Vm(b)), (Um[b.ga] = b), (a.K = b.ga));
  }
  function Qm() {
    bc.call(this);
  }
  A(Qm, bc);
  Qm.prototype.message = "Deferred has already fired";
  Qm.prototype.name = "AlreadyCalledError";
  function Mm() {
    bc.call(this);
  }
  A(Mm, bc);
  Mm.prototype.message = "Deferred was canceled";
  Mm.prototype.name = "CanceledError";
  function Vm(a) {
    this.ga = x.setTimeout(y(this.D, this), 0);
    this.C = a;
  }
  Vm.prototype.D = function () {
    delete Um[this.ga];
    throw this.C;
  };
  var Um = {};
  function Wm(a, b) {
    var c = b || {};
    b = c.document || document;
    var d = Jc(a).toString(),
      e = tf(new sf(b), "SCRIPT"),
      f = { mc: e, va: void 0 },
      g = new Lm(Xm, f),
      h = null,
      k = null != c.timeout ? c.timeout : 5e3;
    0 < k &&
      ((h = window.setTimeout(function () {
        Ym(e, !0);
        var n = new Zm(1, "Timeout reached for loading script " + d);
        Nm(g);
        Om(g, !1, n);
      }, k)),
      (f.va = h));
    e.onload = e.onreadystatechange = function () {
      (e.readyState && "loaded" != e.readyState && e.readyState != za) ||
        (Ym(e, c.kd || !1, h), g.callback(null));
    };
    e.onerror = function () {
      Ym(e, !0, h);
      var n = new Zm(0, "Error while loading script " + d);
      Nm(g);
      Om(g, !1, n);
    };
    f = c.attributes || {};
    xc(f, { type: mb, charset: "UTF-8" });
    cf(e, f);
    Te(e, a);
    $m(b).appendChild(e);
    return g;
  }
  function $m(a) {
    var b = (a || document).getElementsByTagName("HEAD");
    return b && 0 !== b.length ? b[0] : a.documentElement;
  }
  function Xm() {
    if (this && this.mc) {
      var a = this.mc;
      a && "SCRIPT" == a.tagName && Ym(a, !0, this.va);
    }
  }
  function Ym(a, b, c) {
    null != c && x.clearTimeout(c);
    a.onload = function () {};
    a.onerror = function () {};
    a.onreadystatechange = function () {};
    b &&
      window.setTimeout(function () {
        kf(a);
      }, 0);
  }
  function Zm(a, b) {
    var c = "Jsloader error (code #" + a + ")";
    b && (c += ": " + b);
    bc.call(this, c);
    this.code = a;
  }
  A(Zm, bc);
  function an() {
    this.C = bn;
    this.va = 5e3;
  }
  var cn = 0;
  an.prototype.cancel = function (a) {
    a && (a.rd && a.rd.cancel(), a.ga && dn(a.ga, !1));
  };
  function en(a) {
    return function () {
      dn(a, !1);
    };
  }
  function fn(a, b) {
    return function (c) {
      dn(a, !0);
      b.apply(void 0, arguments);
    };
  }
  function dn(a, b) {
    a = "_callbacks___" + a;
    if (x[a])
      if (b)
        try {
          delete x[a];
        } catch (c) {
          x[a] = void 0;
        }
      else x[a] = Pe;
  }
  function gn(a) {
    Q.call(this, "Feed", a);
  }
  v(gn, Q);
  gn.prototype.ka = function (a, b) {
    "getFeed" == a
      ? ((this.C.F = b), hn(this.C))
      : Q.prototype.ka.call(this, a, b);
  };
  gn.prototype.ia = function () {
    if ((this.D = N(this.H, "feedItemListDisplay"))) {
      var a = this.H.N.data;
      this.C = new jn(a.feedUrl, this.D, {
        numItemsShow: a.numItemsShow,
        showItemAuthor: a.showItemAuthor,
        showItemDate: a.showItemDate,
        linkTarget: a.openLinksInNewWindow ? pa : "_self",
        useFeedWidgetServ: "true" === a.useFeedWidgetServ,
      });
      "true" === a.useFeedWidgetServ
        ? this.H.Da("getFeed", null, null, ha)
        : hn(this.C);
    }
  };
  function jn(a, b, c) {
    this.M = a;
    this.D = b;
    this.C = c;
  }
  function hn(a) {
    if (a.C.useFeedWidgetServ) "ok" == a.F.status ? kn(a, a.F.feed) : ln(a);
    else {
      var b = new an();
      b.va = -1;
      var c = { q: a.M, num: a.C.numItemsShow, output: "json", v: "1.0" },
        d = y(a.G, a);
      a = c ? vc(c) : {};
      c = "_" + (cn++).toString(36) + Date.now().toString(36);
      var e = "_callbacks___" + c;
      d && ((x[e] = fn(c, d)), (a.callback = e));
      d = { timeout: b.va, kd: !0 };
      b = Kc.exec(Jc(b.C).toString());
      e = b[3] || "";
      b = Lc(b[1] + Mc("?", b[2] || "", a) + Mc("#", e));
      b = Wm(b, d);
      Rm(b, null, en(c));
    }
  }
  jn.prototype.G = function (a) {
    200 == a.responseStatus ? kn(this, a.responseData.feed) : ln(this);
  };
  function kn(a, b) {
    jf(a.D);
    var c = gf(document, "ul");
    a.D.appendChild(c);
    for (
      var d = Math.min(b.entries.length, a.C.numItemsShow), e = 0;
      e < d;
      e++
    ) {
      var f = b.entries[e],
        g = gf(document, "li");
      c.appendChild(g);
      var h;
      (h = a.C.previewMode) ||
        ((h = new Ji(f.link).G),
        (h = !("" == h || "http" == h || "https" == h)));
      h = h
        ? ef("A", { href: "javascript:void(0);" }, f.title)
        : ef("A", { href: f.link }, f.title);
      h.target = a.C.linkTarget;
      g.appendChild(ef(ja, { class: "item-title" }, h));
      a.C.showItemDate &&
        ((h = ef(
          ja,
          { class: "item-date" },
          "\u00a0-\u00a0" + new Date(f.publishedDate).toLocaleDateString()
        )),
        g.appendChild(h));
      a.C.showItemAuthor &&
        ((f = ef(ja, { class: "item-author" }, "\u00a0-\u00a0" + f.author)),
        g.appendChild(f));
    }
    a.J && a.J(b);
  }
  function ln(a) {
    jf(a.D);
    a.D.appendChild(ef(ja, null, "Error loading feed."));
    a.K && a.K();
  }
  var bn = Lc(Ec(new Bc(Cc, "//ajax.googleapis.com/ajax/services/feed/load")));
  z("_FeedView", gn);
  function mn(a) {
    Q.call(this, "Followers", a);
    this.C = a.N;
  }
  v(mn, Q);
  mn.prototype.ka = function (a, b) {
    "getFacepile" == a
      ? (nn(this, b), on(this), pn(this, b))
      : Q.prototype.ka.call(this, a, b);
  };
  mn.prototype.ia = function () {
    uc(this.C.data) || (on(this), pn(this, this.C.data));
  };
  function nn(a, b) {
    a = oc(b.followers, bf(document, "a", "follower-link", K(Ra, a.C.C)));
    for (b = 0; b < a.length; b++) {
      var c = a[b][0],
        d = a[b][1];
      d.setAttribute(Ka, c.viewUrl);
      d.onclick = function () {
        return !1;
      };
      d = K("follower-thumbnail", d);
      d.setAttribute("src", c.thumbnailUrl);
      d.setAttribute(pb, c.displayName);
    }
  }
  function on(a) {
    var b = K(Ra, a.C.C);
    if (b) {
      b = bf(document, "a", "follower-link", b);
      for (var c = 0; c < b.length; c++) {
        var d = b[c];
        d.getAttribute(Ka) && (d.onclick = y(qn, a, d.getAttribute(Ka)));
      }
    }
  }
  function pn(a, b) {
    var c = K("followers-next-link", a.C.C);
    c &&
      (b.nextTimestamp
        ? ((c.style.display = "inline"),
          (c = K("next-page-link", c)),
          (c.href = "#"),
          (c.onclick = function () {
            return !1;
          }),
          Wf(c),
          L(c, ua, y(mn.prototype.D, a, b.nextTimestamp)))
        : (c.style.display = p));
  }
  mn.prototype.D = function (a) {
    this.H.Da("getFacepile", { fcMT: a }, null, ha);
  };
  function qn(a) {
    window.open(
      a,
      pa,
      "height=600, width=640, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no"
    );
  }
  z("_FollowersView", mn);
  function rn(a) {
    Q.call(this, rn.ea, a);
  }
  A(rn, Q);
  rn.ea = "Header";
  z("_HeaderView", rn);
  function sn(a, b) {
    Q.call(this, b, a);
  }
  v(sn, Q);
  function tn(a) {
    Q.call(this, "Text", a);
  }
  v(tn, sn);
  function un(a) {
    Q.call(this, "HTML", a);
  }
  v(un, sn);
  z("_TextView", tn);
  z("_HTMLView", un);
  function vn(a) {
    Q.call(this, "Image", a);
    this.C = a.N;
  }
  v(vn, Q);
  vn.prototype.ia = function () {
    if (1 == this.C.data.resize) {
      var a = N(this.H, "img"),
        b = this.C.C;
      if (a && b) {
        if (document.defaultView)
          b = parseInt(
            document.defaultView.getComputedStyle(b, null).width,
            10
          );
        else if (b.currentStyle)
          (a.style.display = p), (b = b.offsetWidth), (a.style.display = "");
        else return;
        a.width > b &&
          ((a.height = Math.round((b / a.width) * a.height)), (a.width = b));
        a.style.visibility = rb;
      }
    }
  };
  z("_ImageView", vn);
  function wn(a) {
    Q.call(this, "Label", a);
  }
  v(wn, Q);
  z("_LabelView", wn);
  function xn(a) {
    Q.call(this, xn.ea, a);
  }
  A(xn, Q);
  xn.ea = "TextList";
  z("_TextListView", xn);
  function yn(a) {
    Q.call(this, yn.ea, a);
  }
  A(yn, Q);
  yn.ea = "LinkList";
  z("_LinkListView", yn);
  function zn(a) {
    Q.call(this, "BloggerButton", a);
  }
  v(zn, Q);
  z("_BloggerButtonView", zn);
  function An(a) {
    Q.call(this, "Navbar", a);
  }
  v(An, Q);
  z("_NavbarView", An);
  function Bn(a) {
    Q.call(this, "PageList", a);
  }
  v(Bn, Q);
  Bn.prototype.Qa = function () {
    return "PageList";
  };
  Bn.prototype.ia = function () {
    if (0 != this.H.N.data.mobile) {
      var a = N(this.H, "select");
      a &&
        (a.onchange = function (b) {
          b = b || window.event;
          b = b.target || b.srcElement;
          if ((b = b.options[b.selectedIndex].value)) window.location = b;
        });
    }
  };
  var _PageListView = Bn;
  z("_PageListView", Bn);
  function Cn(a) {
    Q.call(this, "Poll", a);
    this.F = this.D = this.C = null;
    if ((a = this.H.N.data))
      (this.C = "poll-widget" + a.pollid),
        (this.D = a.iframeurl),
        (this.F = L(window, "message", this.G, !1, this)),
        (a = document.getElementsByName(this.C)[0]),
        void 0 != a && (a.src.src = Jc(this.D).toString());
  }
  v(Cn, Q);
  Cn.prototype.G = function (a) {
    var b = document.getElementsByName(this.C)[0];
    void 0 != b &&
      ((a = a.C),
      a.source === b.contentWindow &&
        Nc(this.D, a.origin) &&
        ((a = a.data),
        typeof a !== cb || 0 > a || ((b.height = a + "px"), Vf(this.F))));
  };
  z("_PollView", Cn);
  function Dn(a) {
    Q.call(this, "PopularPosts", a);
  }
  v(Dn, Q);
  z("_PopularPostsView", Dn);
  function En(a) {
    Q.call(this, "Profile", a);
    this.C = a.N;
  }
  v(En, Q);
  En.prototype.ia = function () {
    this.C &&
      this.C.C &&
      0 == this.H.N.data.isDisplayable &&
      (this.C.C.style.display = p);
  };
  z("_ProfileView", En);
  function Fn(a) {
    Q.call(this, "RecentPosts", a);
  }
  v(Fn, Q);
  z("_RecentPostsView", Fn);
  function Gn(a) {
    Q.call(this, "ReportAbuse", a);
  }
  v(Gn, Q);
  z("_ReportAbuseView", Gn);
  function Hn(a) {
    Q.call(this, Hn.ea, a);
  }
  A(Hn, Q);
  Hn.ea = "Sharing";
  z("_SharingView", Hn);
  function In(a) {
    Q.call(this, "Stats", a);
  }
  v(In, Q);
  In.prototype.ia = function () {
    null != N(this.H, "totalCount") &&
      gh(this.H.N.data.statsUrl, y(this.G, this));
  };
  In.prototype.G = function (a) {
    a = a.target;
    if (ph(a)) {
      if (a.C)
        b: {
          a = a.C.responseText;
          if (x.JSON)
            try {
              var b = x.JSON.parse(a);
              break b;
            } catch (h) {}
          b = Ug(a);
        }
      else b = void 0;
      a = this.H.N.data;
      var c = N(this.H, "totalCount");
      if (null != c) {
        if (a.showGraphicalCounter) {
          this.F = b.total;
          for (var d = "" + b.total, e = 0; e < d.length; e++)
            c.appendChild(
              ef(
                ja,
                { class: "digit stage-0" },
                ef(
                  "STRONG",
                  null,
                  document.createTextNode(String(d.charAt(e)))
                ),
                ef(ja, { class: "blind-plate" })
              )
            );
          a.showAnimatedCounter &&
            ((this.D = new Mg(b.nextTickMs)),
            L(this.D, "tick", y(this.J, this, c)),
            this.D.start());
        } else {
          d = b.total;
          if (isNaN(d) || 0 > d) d = "NaN";
          else {
            d = d.toString();
            e = [];
            for (var f = d.length, g = 0; g < f; g++)
              0 < g && 0 == g % 3 && e.push(","), e.push(d.charAt(f - 1 - g));
            d = e.reverse().join("");
          }
          mf(c, d);
        }
        a.showSparkline &&
          ((a = $h(this.H, "sparklinespan")),
          (c = b.sparklineData),
          (b = b.sparklineOptions),
          a && c && b ? Jn(a, c, b) : a && a.parentNode.removeChild(a));
        $h(this.H, "content").style.display = "";
      }
    }
  };
  function Jn(a, b, c) {
    google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(function () {
      new google.visualization.AreaChart(a).draw(
        google.visualization.arrayToDataTable(b, !0),
        Object.assign(
          {
            enableInteractivity: !1,
            chartArea: { top: 0, left: 0, width: 75, height: 30 },
            hAxis: { textPosition: p, gridlines: { color: "transparent" } },
            vAxis: { textPosition: p, gridlines: { color: "transparent" } },
            legend: { position: p },
          },
          c
        )
      );
    });
  }
  In.prototype.J = function (a) {
    if (Kn(this.F + 1) > Kn(this.F)) Wf(this.D), Ng(this.D);
    else {
      this.F++;
      for (var b = "" + this.F, c = 0; c < b.length; c++) {
        var d = a.childNodes[c],
          e = b.charAt(c);
        var f = [];
        pf(d.firstChild, f, !0);
        f = f.join("");
        f = f.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
        f = f.replace(/\u200B/g, "");
        f = f.replace(/ +/g, " ");
        " " != f && (f = f.replace(/^\s*/, ""));
        f != e &&
          (mf(d.firstChild, e),
          Og(y(this.C, this, d, 1), 50),
          Og(y(this.C, this, d, 2), 100),
          Og(y(this.C, this, d, 3), 150),
          Og(y(this.C, this, d, 0), 200));
      }
    }
  };
  function Kn(a) {
    return 0 == a ? 1 : Math.floor(Math.log(a) / Math.LN10) + 1;
  }
  In.prototype.C = function (a, b) {
    var c = "stage-" + (0 != b ? b - 1 : 3);
    b = "stage-" + b;
    var d = oe(a);
    typeof c === r ? lc(d, c) : Array.isArray(c) && (d = se(d, c));
    typeof b !== r || jc(d, b) ? Array.isArray(b) && qe(d, b) : d.push(b);
    a.className = d.join(" ");
  };
  z("_StatsView", In);
  function Ln(a) {
    Q.call(this, "Subscribe", a);
  }
  v(Ln, Q);
  function Mn(a, b) {
    a.style.zIndex = 1 == b ? "20" : "";
  }
  function Nn(a, b) {
    return a
      ? a.className && -1 != a.className.search(b)
        ? a
        : Nn(a.parentNode, b)
      : null;
  }
  function On(a, b) {
    Mn(a.parentNode, b);
    if (I) {
      var c = Nn(a, "section");
      c &&
        (c.parentNode.className &&
          -1 != c.parentNode.className.search("columns-cell") &&
          Mn(c.parentNode.parentNode.parentNode.parentNode, b),
        Mn(c, b));
      (a = Nn(a, "widget Subscribe")) && Mn(a.parentNode.parentNode, b);
    }
  }
  var Pn = null,
    Qn = null;
  z("_SubscribeView", Ln);
  z("_SW_toggleReaderList", function (a, b) {
    var c = document.getElementById(la + b),
      d = document.getElementById(ma + b);
    a || (a = window.event);
    a.cancelBubble = !0;
    a.stopPropagation && a.stopPropagation();
    var e = document.onclick;
    null != Pn &&
      Pn != c &&
      (On(Pn, !1), (Pn.style.display = p), (Qn.style.visibility = rb));
    c.style.display == p
      ? (On(c, !0),
        (c.style.display = ""),
        (Pn = c),
        (Qn = d),
        (d.style.visibility = Wa),
        (document.onclick = function () {
          c.style.display = p;
          On(c, !1);
          d.style.visibility = rb;
          e && (document.onclick = e);
        }))
      : ((c.style.display = p),
        On(c, !1),
        (d.style.visibility = rb),
        e && (document.onclick = e));
    return !1;
  });
  z("_SW_hideReaderList", function (a) {
    var b = document.getElementById(la + a);
    a = document.getElementById(ma + a);
    b.style.display = p;
    On(b, !1);
    a.style.visibility = rb;
  });
  function Rn(a) {
    Q.call(this, Rn.ea, a);
  }
  A(Rn, Q);
  Rn.ea = "Translate";
  z("_TranslateView", Rn);
  function Sn(a) {
    Hi.call(this, a);
  }
  v(Sn, Hi);
  function Tn() {
    var a = JSON.parse(
      '[null,null,null,null,null,"(function(){/*\\n\\n Copyright The Closure Library Authors.\\n SPDX-License-Identifier: Apache-2.0\\n*/\\n\'use strict\';var e\\u003dthis||self;function f(a){return a};/*\\n\\n SPDX-License-Identifier: Apache-2.0\\n*/\\nvar h;function k(a,c){this.g\\u003dc\\u003d\\u003d\\u003dl?a:\\"\\"}k.prototype.toString\\u003dfunction(){return this.g+\\"\\"};var l\\u003d{};function m(a){if(void 0\\u003d\\u003d\\u003dh){var c\\u003dnull;var b\\u003de.trustedTypes;if(b\\u0026\\u0026b.createPolicy){try{c\\u003db.createPolicy(\\"goog#html\\",{createHTML:f,createScript:f,createScriptURL:f})}catch(d){e.console\\u0026\\u0026e.console.error(d.message)}h\\u003dc}else h\\u003dc}a\\u003d(c\\u003dh)?c.createScriptURL(a):a;return new k(a,l)};if(!function(){if(self.origin)return\\"null\\"\\u003d\\u003d\\u003dself.origin;if(\\"\\"!\\u003d\\u003dlocation.host)return!1;try{return window.parent.escape(\\"\\"),!1}catch(a){return!0}}())throw Error(\\"sandboxing error\\");\\nwindow.addEventListener(\\"message\\",function(a){var c\\u003da.ports[0];a\\u003da.data;var b\\u003da.callbackName.split(\\".\\"),d\\u003dwindow;\\"window\\"\\u003d\\u003d\\u003db[0]\\u0026\\u0026b.shift();for(var g\\u003d0;g\\u003cb.length-1;g++)d[b[g]]\\u003d{},d\\u003dd[b[g]];d[b[b.length-1]]\\u003dfunction(n){c.postMessage(JSON.stringify(n))};b\\u003ddocument.createElement(\\"script\\");a\\u003dm(a.url);b.src\\u003da instanceof k\\u0026\\u0026a.constructor\\u003d\\u003d\\u003dk?a.g:\\"type_error:TrustedResourceUrl\\";document.body.appendChild(b)},!0);}).call(this);\\n"]'
    );
    if (!Array.isArray(a)) throw Error(void 0);
    vi(a, 16);
    Ii = a;
    a = new Sn(a);
    Ii = null;
    if (!a) return null;
    a = R(a, 6);
    if (null === a || void 0 === a) a = null;
    else {
      var b = Ac();
      a = b ? b.createScript(a) : a;
      a = new Gc(a, Fc);
    }
    return a;
  }
  function Un(a) {
    this.url = a;
    this.timeout = 5e3;
    this.G = "callback";
    this.C = this.D = null;
  }
  function Vn(a) {
    var b = { callback: "?" };
    b = void 0 === b ? {} : b;
    a.C = zg();
    var c = new Ji(a.url),
      d = new Map();
    d.set("callback", a.G);
    c.C.Dc(bj(b), d);
    Wn(a)
      .then(function () {
        Xn(a, c.toString());
      })
      .then(function () {
        return a.C.promise;
      })
      .then(
        function () {
          Yn(a);
        },
        function () {
          Yn(a);
        }
      );
    0 < a.timeout &&
      (a.F = setTimeout(function () {
        a.C.reject("Timeout!");
      }, a.timeout));
    return a.C.promise;
  }
  function Xn(a, b) {
    var c = new MessageChannel();
    a.D.contentWindow.postMessage({ url: b, callbackName: a.G }, "*", [
      c.port2,
    ]);
    c.port1.onmessage = function (d) {
      var e = {};
      void 0 !== a.F && (clearTimeout(a.F), (a.F = void 0));
      void 0 === d.data && a.C.reject("Callback called, but no data received");
      typeof d.data !== r &&
        a.C.reject("Exploitation attempt! Data is not a string!");
      try {
        e = JSON.parse(d.data);
      } catch (f) {
        a.C.reject("Invalid Data received: " + f.message);
      }
      a.C.resolve(e);
    };
  }
  function Wn(a) {
    var b = zg(),
      c = gf(document, "IFRAME");
    if (!c.sandbox) throw Error("iframe sandboxes not supported");
    c.sandbox.value = "allow-scripts";
    c.style.display = p;
    a.D = c;
    a = Tn();
    a = Hd(Kd, Dd(F(Bd(Md(a)).toString())));
    c.srcdoc = Bd(a);
    a = Lc("data:text/html;charset=UTF-8;base64," + btoa(Bd(a).toString()));
    c.src = Jc(a).toString();
    c.addEventListener(
      "load",
      function () {
        return b.resolve(c);
      },
      !1
    );
    c.addEventListener(
      Pa,
      function (d) {
        b.reject(d);
      },
      !1
    );
    document.documentElement.appendChild(c);
    return b.promise;
  }
  function Yn(a) {
    null !== a.D && (document.documentElement.removeChild(a.D), (a.D = null));
  }
  function Z(a) {
    Q.call(this, Z.ea, a);
  }
  A(Z, Q);
  Z.ea = "Wikipedia";
  z("_WikipediaView", Z);
  Z.Nb = 5;
  Z.La = "";
  Z.jb = "en";
  t = Z.prototype;
  t.Oa = !1;
  t.Ia = !1;
  t.ia = function () {
    var a = N(this.H, "wikipedia-search-form");
    if (a) {
      Z.La = this.H.N.data.language || "en";
      var b = this;
      L(a, "submit", function (c) {
        Z.prototype.Ia || ((Z.prototype.Ia = !0), Zn(b));
        c.preventDefault();
      });
    }
  };
  function Zn(a) {
    jf(J(N(a.H, ub)));
    jf(J(N(a.H, tb)));
    var b = B(J(N(a.H, sb)).value);
    b
      ? ((b = Yi(
          Yi(
            Yi(
              Mi(
                new Ji("https://" + ((a.Oa && Z.jb) || Z.La) + ba),
                "/w/api.php"
              ),
              "action",
              "opensearch"
            ),
            "search",
            b
          ),
          "format",
          "json"
        )),
        (b = new Un(b)),
        N(a.H, vb),
        N(a.H, ub),
        Vn(b).then(y(a.Hd, a), y(a.Gd, a)))
      : ((J(N(a.H, vb)).style.display = p),
        ($h(a.H, ub).textContent = a.H.N.data.enterTextMsg),
        (Z.prototype.Ia = !1));
  }
  t.Hd = function (a) {
    var b = N(this.H, vb),
      c = N(this.H, ub),
      d = B(J(N(this.H, sb)).value),
      e = [],
      f = a[1];
    a = f.length;
    if (0 == a)
      (J(b).style.display = ta),
        Pd(
          c,
          ee(this.H.N.data.noResultsFoundMsg, {
            Ha: "0d97e0f4-c366-459f-8731-70b177eeffb9",
          })
        ),
        (Z.prototype.Ia = !1);
    else {
      for (var g = 0; g < a; g++)
        e.push(
          '<div id="wikipedia-search-result-link"><a target="_blank" href=https://' +
            (((this.Oa && Z.jb) || Z.La) +
              ".wikipedia.org/wiki/" +
              f[g].replace(/ /g, "_")) +
            ">" +
            f[g] +
            "</a></div>"
        );
      if (a > Z.Nb) {
        for (a = 0; a < Z.Nb; a++) J(c).innerHTML += e[a];
        J(N(this.H, tb)).style.display = ta;
        e =
          '<a target="_blank" href=' +
          Yi(
            Yi(
              Yi(
                Yi(
                  Mi(
                    new Ji("https://" + ((this.Oa && Z.jb) || Z.La) + ba),
                    "/w/index.php"
                  ),
                  pb,
                  "Special:Search"
                ),
                "profile",
                "default"
              ),
              "search",
              d
            ),
            "fulltext",
            "Search"
          ) +
          ">" +
          this.H.N.data.moreMsg +
          "</a>";
        c = J(N(this.H, tb));
        d = new im();
        d.L = vm;
        d.K = Qe;
        d.J = Qe;
        d.F = ad;
        d.R = ad;
        e = new hm(d).C(e);
        Pd(c, e);
      } else for (d = 0; d < a; d++) J(c).innerHTML += e[d];
      J(b).style.display = ta;
      this.Oa = Z.prototype.Ia = !1;
    }
  };
  t.Gd = function () {
    "en" != Z.La
      ? ((this.Oa = !0), Zn(this))
      : ((J(N(this.H, vb)).style.display = p),
        Pd(
          $h(this.H, ub),
          ee(this.H.N.data.fetchingErrorMsg, {
            Ha: "04c93402-2dfe-49dd-a885-5fc05d08b8d5",
          })
        ),
        (Z.prototype.Ia = !1));
  };
  if (window.jstiming) {
    window.jstiming.Sb = {};
    window.jstiming.Id = 1;
    var $n = function (a, b, c) {
        var d = a.t[b],
          e = a.t.start;
        if (d && (e || c))
          return (
            (d = a.t[b][0]),
            void 0 != c ? (e = c) : (e = e[0]),
            Math.round(d - e)
          );
      },
      ao = function (a, b, c) {
        var d = "";
        window.jstiming.srt &&
          ((d += "&srt=" + window.jstiming.srt), delete window.jstiming.srt);
        window.jstiming.pt &&
          ((d += "&tbsrt=" + window.jstiming.pt), delete window.jstiming.pt);
        try {
          window.external && window.external.tran
            ? (d += "&tran=" + window.external.tran)
            : window.gtbExternal && window.gtbExternal.tran
            ? (d += "&tran=" + window.gtbExternal.tran())
            : window.chrome &&
              window.chrome.csi &&
              (d += "&tran=" + window.chrome.csi().tran);
        } catch (w) {}
        var e = window.chrome;
        if (e && (e = e.loadTimes)) {
          e().wasFetchedViaSpdy && (d += "&p=s");
          if (e().wasNpnNegotiated) {
            d += "&npn=1";
            var f = e().npnNegotiatedProtocol;
            f && (d += "&npnv=" + (encodeURIComponent || escape)(f));
          }
          e().wasAlternateProtocolAvailable && (d += "&apa=1");
        }
        var g = a.t,
          h = g.start;
        e = [];
        f = [];
        for (var k in g)
          if ("start" != k && 0 != k.indexOf("_")) {
            var n = g[k][1];
            n
              ? g[n] && f.push(k + "." + $n(a, k, g[n][0]))
              : h && e.push(k + "." + $n(a, k));
          }
        delete g.start;
        if (b) for (var u in b) d += "&" + u + "=" + b[u];
        (b = c) ||
          (b =
            Xa == document.location.protocol
              ? "https://csi.gstatic.com/csi"
              : "http://csi.gstatic.com/csi");
        return [
          b,
          "?v=3",
          "&s=" + (window.jstiming.sn || "blogger") + aa,
          a.name,
          f.length ? "&it=" + f.join(",") : "",
          d,
          "&rt=",
          e.join(","),
        ].join("");
      },
      bo = function (a, b, c) {
        a = ao(a, b, c);
        if (!a) return "";
        b = new Image();
        var d = window.jstiming.Id++;
        window.jstiming.Sb[d] = b;
        b.onload = b.onerror = function () {
          window.jstiming && delete window.jstiming.Sb[d];
        };
        b.src = a;
        b = null;
        return a;
      };
    window.jstiming.report = function (a, b, c) {
      var d = document.visibilityState,
        e = "visibilitychange";
      d ||
        ((d = document.webkitVisibilityState), (e = "webkitvisibilitychange"));
      if (d == db) {
        var f = !1,
          g = function () {
            if (!f) {
              b ? (b.prerender = "1") : (b = { prerender: "1" });
              if (
                (document.visibilityState || document.webkitVisibilityState) ==
                db
              )
                var h = !1;
              else bo(a, b, c), (h = !0);
              h && ((f = !0), document.removeEventListener(e, g, !1));
            }
          };
        document.addEventListener(e, g, !1);
        return "";
      }
      return bo(a, b, c);
    };
  }
}.call(this));
